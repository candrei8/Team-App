import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { History, Eye, RotateCcw, Clock, User } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function VersionHistoryPanel({ 
  versions = [],
  onRestore,
  onPreview
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedVersion, setSelectedVersion] = useState(null);
  const [showRestoreDialog, setShowRestoreDialog] = useState(false);

  const handleRestore = () => {
    if (selectedVersion) {
      onRestore(selectedVersion);
      setShowRestoreDialog(false);
      setIsOpen(false);
    }
  };

  return (
    <>
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="h-9 w-9">
            <History className="w-4 h-4" />
          </Button>
        </SheetTrigger>
        <SheetContent className="w-96">
          <SheetHeader>
            <SheetTitle>Historial de versiones</SheetTitle>
            <SheetDescription>
              Últimas {versions.length} versiones guardadas
            </SheetDescription>
          </SheetHeader>

          <ScrollArea className="h-[calc(100vh-150px)] mt-6 pr-4">
            {versions.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <History className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p className="text-sm">No hay versiones guardadas</p>
              </div>
            ) : (
              <div className="space-y-3">
                {versions.map((version, index) => (
                  <div
                    key={version.version}
                    className="border rounded-lg p-4 hover:border-[#0073EA] transition-colors"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Badge variant={index === 0 ? "default" : "secondary"}>
                          v{version.version}
                        </Badge>
                        {index === 0 && (
                          <Badge variant="outline" className="text-green-600 border-green-300">
                            Actual
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-gray-600">
                        <Clock className="w-3.5 h-3.5" />
                        <span>
                          {format(new Date(version.saved_at), "d 'de' MMMM, HH:mm", { locale: es })}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-gray-600">
                        <User className="w-3.5 h-3.5" />
                        <span>{version.saved_by}</span>
                      </div>

                      {version.changes_summary && (
                        <p className="text-gray-700 text-xs mt-2 italic">
                          "{version.changes_summary}"
                        </p>
                      )}

                      {version.snapshot_data?.elements && (
                        <p className="text-gray-500 text-xs">
                          {version.snapshot_data.elements.length} elementos
                        </p>
                      )}
                    </div>

                    {index !== 0 && (
                      <div className="flex gap-2 mt-3">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1"
                          onClick={() => onPreview(version)}
                        >
                          <Eye className="w-3.5 h-3.5 mr-1.5" />
                          Vista previa
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 text-[#0073EA] hover:text-[#0056B3]"
                          onClick={() => {
                            setSelectedVersion(version);
                            setShowRestoreDialog(true);
                          }}
                        >
                          <RotateCcw className="w-3.5 h-3.5 mr-1.5" />
                          Restaurar
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </SheetContent>
      </Sheet>

      {/* Diálogo de confirmación de restauración */}
      <AlertDialog open={showRestoreDialog} onOpenChange={setShowRestoreDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Restaurar esta versión?</AlertDialogTitle>
            <AlertDialogDescription>
              Se restaurará la versión {selectedVersion?.version} del{' '}
              {selectedVersion && format(new Date(selectedVersion.saved_at), "d 'de' MMMM", { locale: es })}.
              Los cambios actuales se guardarán automáticamente como una nueva versión.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleRestore}
              className="bg-[#0073EA] hover:bg-[#0056B3]"
            >
              Restaurar versión
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
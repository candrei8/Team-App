
import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { 
  LayoutGrid, 
  Bell, 
  Settings, 
  Folder,
  Users,
  Menu as MenuIcon,
  TrendingUp,
  LogOut,
  User as UserIcon,
  Pen,
  Calendar,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  Shield
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sidebar, SidebarBody, SidebarLink } from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";

import NotificationsPanel from "./components/layout/NotificationsPanel";
import LumaSpin from "@/components/ui/luma-spin";
import { registerServiceWorker } from "@/components/utils/pushNotifications";
import GuestLayout from "@/components/layout/GuestLayout";

const navigationItems = [
  {
    title: "Panel Principal",
    url: createPageUrl("Dashboard"),
    icon: LayoutGrid,
  },
  {
    title: "Proyectos",
    url: createPageUrl("Boards"),
    icon: Folder,
  },
  {
    title: "Calendario",
    url: createPageUrl("CalendarView"),
    icon: Calendar,
  },
  {
    title: "Mensajes",
    url: createPageUrl("Messages"),
    icon: MessageSquare,
  },
  {
    title: "Pizarras",
    url: createPageUrl("Whiteboards"),
    icon: Pen,
  },
  {
    title: "Analítica",
    url: createPageUrl("Analytics"),
    icon: TrendingUp,
  },
  {
    title: "Docs",
    url: createPageUrl("Documents"),
    icon: Folder,
  },
  {
    title: "Usuarios",
    url: createPageUrl("Users"),
    icon: Users,
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [user, setUser] = useState(null);
  const [isCheckingAccess, setIsCheckingAccess] = useState(true);
  const [isNavigating, setIsNavigating] = useState(false);

  const isAccessBlockedPage = location.pathname === createPageUrl("AccessBlocked");

  // Rastreo de vistas de página (SPA) para Google Analytics
  useEffect(() => {
    if (typeof window.gtag === 'function') {
      window.gtag('config', 'G-XGVW3D8N9N', {
        page_path: location.pathname + location.search
      });
    }
  }, [location]);

  // Logic to switch layouts based on role or path
  const isGuestPath = location.pathname.startsWith("/invitado") || location.pathname.startsWith("/Invitado");
  const isGuestUser = user?.custom_role === "guest" || user?.role === "guest";

  // Redirect guests to their portal if they land on main dashboard
  useEffect(() => {
    if (user && !isCheckingAccess) {
      if (isGuestUser && !isGuestPath && location.pathname !== createPageUrl("AccessBlocked")) {
        navigate(createPageUrl("InvitadoDashboard"));
      }
    }
  }, [user, isCheckingAccess, location.pathname, isGuestUser, isGuestPath, navigate]);

  // Solo cargar usuario una vez al iniciar
  useEffect(() => {
    if (!isAccessBlockedPage) {
      loadUser();
    } else {
      setIsCheckingAccess(false);
    }

    // Registrar Service Worker y configurar PWA
    registerServiceWorker().catch(err => console.log('SW Registration failed (expected in dev):', err));

    // Inject PWA Meta Tags
    const metaTags = [
      { name: 'google-site-verification', content: 'o7hVc5zPCfGFwqnAny5ucwPPMu3mIcAEKLN_2-fptYo' },
      { name: 'theme-color', content: '#0073EA' },
      { name: 'description', content: 'Gestión de Proyectos - E&D Company' },
      { name: 'apple-mobile-web-app-capable', content: 'yes' },
      { name: 'apple-mobile-web-app-status-bar-style', content: 'black-translucent' }
    ];

    metaTags.forEach(tag => {
      if (!document.querySelector(`meta[name="${tag.name}"]`)) {
        const meta = document.createElement('meta');
        meta.name = tag.name;
        meta.content = tag.content;
        document.head.appendChild(meta);
      }
    });

    // Google Analytics Injection
    if (!document.querySelector('script[src^="https://www.googletagmanager.com/gtag/js"]')) {
      const script = document.createElement('script');
      script.async = true;
      script.src = 'https://www.googletagmanager.com/gtag/js?id=G-XGVW3D8N9N';
      document.head.appendChild(script);

      const inlineScript = document.createElement('script');
      inlineScript.innerHTML = `
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-XGVW3D8N9N');
      `;
      document.head.appendChild(inlineScript);
    }

    // Inject Manifest (Data URI workaround since we can't serve files at root)
    if (!document.querySelector('link[rel="manifest"]')) {
      const manifest = {
        "name": "E&D Company",
        "short_name": "E&D",
        "display": "standalone",
        "theme_color": "#0073EA",
        "background_color": "#0D1117",
        "icons": [
          { "src": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691331048c912041d25cea34/d90f3652c_E-DLOGOAZUL-640w.png", "sizes": "192x192", "type": "image/png" }
        ],
        "gcm_sender_id": "103953800507"
      };
      const link = document.createElement('link');
      link.rel = 'manifest';
      link.href = 'data:application/manifest+json;base64,' + btoa(JSON.stringify(manifest));
      document.head.appendChild(link);
    }
    
    // Inject Apple Touch Icon
    if (!document.querySelector('link[rel="apple-touch-icon"]')) {
      const link = document.createElement('link');
      link.rel = 'apple-touch-icon';
      link.href = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691331048c912041d25cea34/d90f3652c_E-DLOGOAZUL-640w.png";
      document.head.appendChild(link);
    }

  }, []);

  // Mostrar indicador de carga al cambiar de página
  useEffect(() => {
    // Solo mostrar si ya pasó la verificación inicial
    if (!isCheckingAccess && user) {
      setIsNavigating(true);
      const timer = setTimeout(() => setIsNavigating(false), 300);
      return () => clearTimeout(timer);
    }
  }, [location.pathname]);

  const loadUser = async () => {
    setIsCheckingAccess(true);
    try {
      const userData = await base44.auth.me();
      
// ... remove guest redirect ...

      setUser(userData);
      
      if (userData.role === "admin") {
        if (!userData.status || userData.status === "pending") {
          try {
            await base44.auth.updateMe({ status: "active" });
          } catch (error) {
            console.error("Error al actualizar status del admin:", error);
          }
        }
      } else {
        const userStatus = userData.status || "pending";
        
        // Permitir acceso a usuarios activos (admin, user, guest)
        if (userStatus !== "active" && userData.role !== "admin") {
          navigate(createPageUrl("AccessBlocked"), { replace: true });
          return;
        }
      }
    } catch (error) {
      console.error("Error al cargar usuario:", error);
      // Manejo básico de error de carga de usuario para evitar pantalla blanca eterna
      if (error.message?.includes("Rate limit")) {
         // Si hay rate limit en Layout, esperamos un poco
         setTimeout(() => setIsCheckingAccess(false), 2000);
         return;
      }
    }
    setIsCheckingAccess(false);
  };

  const handleLogout = async () => {
    try {
      await base44.auth.logout();
    } catch (error) {
      console.error("Error al cerrar sesión:", error);
    }
  };

  const handleGoToProfile = () => {
    navigate(createPageUrl("Profile"));
    setMobileMenuOpen(false);
  };

  const handleGoToSettings = () => {
    navigate(createPageUrl("Settings"));
    setMobileMenuOpen(false);
  };

  const handleGoToAdminPanel = () => {
    navigate(createPageUrl("AdminPanel"));
    setMobileMenuOpen(false);
  };

  const getUserInitials = () => {
    if (!user?.full_name) return "U";
    const names = user.full_name.split(" ");
    if (names.length >= 2) {
      return `${names[0][0]}${names[1][0]}`.toUpperCase();
    }
    return names[0][0].toUpperCase();
  };



  if (isAccessBlockedPage) {
    return <>{children}</>;
  }

  if (isCheckingAccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0D1117] via-[#0A0E1A] to-[#0D1117]">
        <div className="text-center">
          <div className="flex justify-center">
            <LumaSpin size={100} />
          </div>
        </div>
      </div>
    );
    }

    if (!user) {
    return null;
    }

// Render Guest Layout
    if (user && isGuestUser && isGuestPath) {
      return (
        <GuestLayout user={user}>
          {children}
        </GuestLayout>
      );
    }

    return (
  <div className="min-h-screen flex bg-[#F5F6F8] relative">
      {/* Sidebar with hover animation - Hidden on mobile */}
      <div className="hidden lg:block">
        <Sidebar open={!sidebarCollapsed} setOpen={(val) => setSidebarCollapsed(!val)}>
          <SidebarBody>
          <div className="flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
            {/* Logo */}
            {!sidebarCollapsed ? (
              <Link to={createPageUrl("Dashboard")} className="flex items-center gap-2.5 group mb-6">
                <div className="relative flex-shrink-0">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-blue-600 rounded-lg blur opacity-25 group-hover:opacity-40 transition-opacity"></div>
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691331048c912041d25cea34/d90f3652c_E-DLOGOAZUL-640w.png" 
                    alt="E&D Company" 
                    className="relative h-8 w-auto rounded-lg shadow-lg p-1 bg-white border border-blue-100 group-hover:shadow-xl transition-all duration-300"
                  />
                </div>
                <div className="min-w-0">
                  <h1 className="text-base font-bold bg-gradient-to-r from-sky-400 to-blue-700 bg-clip-text text-transparent truncate">
                    E&D Company
                  </h1>
                  <p className="text-[10px] text-gray-500 -mt-0.5 truncate">Gestión de Proyectos</p>
                </div>
              </Link>
            ) : (
              <Link to={createPageUrl("Dashboard")} className="flex justify-center mb-6">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691331048c912041d25cea34/d90f3652c_E-DLOGOAZUL-640w.png" 
                  alt="E&D" 
                  className="h-8 w-auto rounded-lg shadow-lg p-1 bg-white border border-blue-100"
                />
              </Link>
            )}

            {/* Navigation Links */}
            <div className="flex flex-col gap-1">
              {navigationItems
                .filter(item => {
                  // Ocultar "Usuarios" si no es admin
                  const isAdmin = user?.role === "admin" || user?.custom_role === "admin";
                  if (item.title === "Usuarios" && !isAdmin) {
                    return false;
                  }
                  return true;
                })
                .map((item) => (
                  <SidebarLink
                    key={item.title}
                    link={{
                      label: item.title,
                      href: item.url,
                      icon: <item.icon className="w-5 h-5 flex-shrink-0" />,
                    }}
                    isActive={location.pathname === item.url}
                  />
                ))}
            </div>
          </div>
        </SidebarBody>
      </Sidebar>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="h-14 bg-white border-b border-[#E1E5F3] shadow-sm flex items-center justify-between px-4 lg:px-6 sticky top-0 z-40">
          {/* Left Side - Mobile Menu Only */}
          <div className="flex items-center gap-3">
            {/* Mobile Menu Button */}
            <div className="lg:hidden">
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-10 w-10 rounded-lg hover:bg-gray-100 active:bg-gray-200 transition-colors"
                    aria-label="Abrir menú"
                  >
                    <MenuIcon className="w-5 h-5 text-gray-700" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80 p-0">
                  <div className="flex flex-col h-full">
                    {/* Mobile Logo */}
                    <div className="p-4 border-b">
                      <Link 
                        to={createPageUrl("Dashboard")} 
                        className="flex items-center gap-3 group"
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        <div className="relative">
                          <img 
                            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691331048c912041d25cea34/d90f3652c_E-DLOGOAZUL-640w.png" 
                            alt="E&D Company" 
                            className="h-10 w-auto rounded-xl shadow-lg p-1.5 bg-white border border-blue-100"
                          />
                        </div>
                        <div>
                          <h1 className="text-lg font-bold bg-gradient-to-r from-sky-400 to-blue-700 bg-clip-text text-transparent">
                            E&D Company
                          </h1>
                          <p className="text-xs text-gray-500 -mt-0.5">Gestión de Proyectos</p>
                        </div>
                      </Link>
                    </div>

                    {/* Mobile User Info */}
                    <div className="p-4 border-b">
                      <div className="flex items-center gap-3">
                        {user?.avatar_url ? (
                          <img 
                            src={user.avatar_url} 
                            alt="Avatar" 
                            className="w-12 h-12 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-12 h-12 bg-gradient-to-r from-[#0073EA] to-[#00C875] rounded-full flex items-center justify-center">
                            <span className="text-white font-bold text-base">{getUserInitials()}</span>
                          </div>
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-gray-800 truncate">{user?.full_name || 'Usuario'}</div>
                          <div className="text-xs text-gray-500 truncate">{user?.email}</div>
                        </div>
                      </div>
                    </div>

                    {/* Mobile Navigation */}
                    <nav className="flex-1 overflow-y-auto p-4">
                      <div className="space-y-1">
                        {navigationItems
                          .filter(item => {
                            // Ocultar "Usuarios" si no es admin
                            const isAdmin = user?.role === "admin" || user?.custom_role === "admin";
                            if (item.title === "Usuarios" && !isAdmin) {
                              return false;
                            }
                            return true;
                          })
                          .map((item) => (
                            <Link
                              key={item.title}
                              to={item.url}
                              className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                                location.pathname === item.url
                                  ? 'bg-gradient-to-r from-[#0073EA] to-[#0056B3] text-white shadow-md'
                                  : 'text-[#323338] hover:bg-[#F5F6F8] hover:text-[#0073EA] active:bg-gray-200'
                              }`}
                              onClick={() => setMobileMenuOpen(false)}
                            >
                              <item.icon className="w-5 h-5 flex-shrink-0" />
                              <span className="truncate">{item.title}</span>
                            </Link>
                          ))}
                      </div>
                    </nav>

                    {/* Mobile Footer Actions */}
                    <div className="p-4 border-t space-y-1">
                      <Button
                        variant="ghost"
                        className="w-full justify-start h-11"
                        onClick={handleGoToProfile}
                      >
                        <UserIcon className="w-4 h-4 mr-2" />
                        Tu Perfil
                      </Button>
                      {(user?.role === "admin" || user?.custom_role === "admin") && (
                        <Button
                          variant="ghost"
                          className="w-full justify-start h-11"
                          onClick={handleGoToAdminPanel}
                        >
                          <Shield className="w-4 h-4 mr-2" />
                          Panel de Admin
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        className="w-full justify-start h-11"
                        onClick={handleGoToSettings}
                      >
                        <Settings className="w-4 h-4 mr-2" />
                        Ajustes
                      </Button>
                      <Link to="/Privacy" onClick={() => setMobileMenuOpen(false)}>
                        <Button
                          variant="ghost"
                          className="w-full justify-start h-11 text-gray-600"
                        >
                          <Shield className="w-4 h-4 mr-2" />
                          Privacidad
                        </Button>
                      </Link>
                      <Button
                        variant="ghost"
                        className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50 h-11"
                        onClick={() => {
                          handleLogout();
                          setMobileMenuOpen(false);
                        }}
                      >
                        <LogOut className="w-4 h-4 mr-2" />
                        Cerrar Sesión
                      </Button>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>

          {/* Right Side - Notifications, Settings, User Profile */}
          <div className="flex items-center gap-1.5">
            <NotificationsPanel />
            <Button 
              variant="ghost" 
              size="icon" 
              className="hover:bg-[#E1E5F3] rounded-lg h-10 w-10"
              onClick={handleGoToSettings}
            >
              <Settings className="w-5 h-5 text-[#676879]" />
            </Button>
            
            {/* User Profile Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full h-10 w-10 p-0 hover:opacity-80 transition-opacity"
                >
                  {user?.avatar_url ? (
                    <img 
                      src={user.avatar_url} 
                      alt="Avatar" 
                      className="w-9 h-9 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-9 h-9 bg-gradient-to-r from-[#0073EA] to-[#00C875] rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-xs">{getUserInitials()}</span>
                    </div>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium">{user?.full_name || 'Usuario'}</p>
                    <p className="text-xs text-gray-500 truncate">{user?.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleGoToProfile} className="cursor-pointer">
                  <UserIcon className="w-4 h-4 mr-2" />
                  <span>Tu Perfil</span>
                </DropdownMenuItem>
                {(user?.role === "admin" || user?.custom_role === "admin") && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleGoToAdminPanel} className="cursor-pointer">
                      <Shield className="w-4 h-4 mr-2 text-purple-600" />
                      <span className="text-purple-600 font-medium">Panel de Admin</span>
                    </DropdownMenuItem>
                  </>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/Privacy" className="cursor-pointer w-full flex items-center">
                    <Shield className="w-4 h-4 mr-2" />
                    <span>Privacidad</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-red-600">
                  <LogOut className="w-4 h-4 mr-2" />
                  <span>Cerrar Sesión</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto overflow-x-hidden relative">
          {/* Indicador de carga flotante */}
          {isNavigating && (
            <div className="absolute inset-0 bg-white/60 backdrop-blur-sm z-50 flex items-center justify-center transition-opacity duration-200">
              <div className="bg-white rounded-2xl shadow-2xl p-6 flex flex-col items-center gap-3">
                <LumaSpin size={60} />
                <p className="text-sm text-gray-600 font-medium">Cargando...</p>
              </div>
            </div>
          )}
          {/* Contenido de la página con transición */}
          <div className={`transition-opacity duration-200 ${isNavigating ? 'opacity-0' : 'opacity-100'}`}>
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

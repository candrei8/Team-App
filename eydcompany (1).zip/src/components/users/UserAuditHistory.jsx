import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Shield,
  Briefcase,
  UserCheck,
  Ban,
  CheckCircle,
  User,
  Calendar,
  ArrowRight,
  History,
  Loader2
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

export default function UserAuditHistory({ isOpen, onClose, user }) {
  const [auditLogs, setAuditLogs] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen && user) {
      loadAuditLogs();
    }
  }, [isOpen, user]);

  const loadAuditLogs = async () => {
    setIsLoading(true);
    try {
      // Obtener logs donde este usuario es el afectado (target)
      const logs = await base44.entities.UserAuditLog.filter(
        { target_id: user.id },
        "-created_date"
      );
      setAuditLogs(logs);
    } catch (error) {
      console.error("Error al cargar historial de auditoría:", error);
    }
    setIsLoading(false);
  };

  const getActionIcon = (actionType) => {
    switch (actionType) {
      case "role_change":
        return <Shield className="w-4 h-4" />;
      case "department_change":
        return <Briefcase className="w-4 h-4" />;
      case "status_change":
        return <UserCheck className="w-4 h-4" />;
      case "activation":
        return <CheckCircle className="w-4 h-4" />;
      case "suspension":
        return <Ban className="w-4 h-4" />;
      case "profile_update":
        return <User className="w-4 h-4" />;
      default:
        return <History className="w-4 h-4" />;
    }
  };

  const getActionBadge = (actionType) => {
    const config = {
      role_change: { bg: "bg-purple-100", text: "text-purple-700", label: "Cambio de Rol" },
      department_change: { bg: "bg-blue-100", text: "text-blue-700", label: "Cambio de Depto." },
      status_change: { bg: "bg-amber-100", text: "text-amber-700", label: "Cambio de Estado" },
      activation: { bg: "bg-green-100", text: "text-green-700", label: "Activación" },
      suspension: { bg: "bg-red-100", text: "text-red-700", label: "Suspensión" },
      profile_update: { bg: "bg-gray-100", text: "text-gray-700", label: "Actualización" },
      account_created: { bg: "bg-indigo-100", text: "text-indigo-700", label: "Cuenta Creada" },
    };

    const style = config[actionType] || config.profile_update;

    return (
      <Badge className={`${style.bg} ${style.text} border-0`}>
        {getActionIcon(actionType)}
        <span className="ml-1.5">{style.label}</span>
      </Badge>
    );
  };

  const formatValue = (value) => {
    if (!value) return "N/A";
    
    // Formatear roles
    const roleMap = {
      admin: "Administrador",
      user: "Equipo",
      guest: "Invitado"
    };
    if (roleMap[value]) return roleMap[value];

    // Formatear estados
    const statusMap = {
      pending: "Pendiente",
      active: "Activo",
      suspended: "Suspendido"
    };
    if (statusMap[value]) return statusMap[value];

    return value;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="w-5 h-5 text-[#0073EA]" />
            Historial de Auditoría
          </DialogTitle>
          <DialogDescription>
            Registro completo de cambios para {user?.full_name || user?.email}
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-[#0073EA]" />
          </div>
        ) : auditLogs.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <History className="w-12 h-12 mx-auto mb-3 text-gray-400" />
            <p className="text-sm">No hay registros de auditoría para este usuario</p>
          </div>
        ) : (
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-3">
              {auditLogs.map((log, index) => (
                <Card key={log.id} className="border-l-4 border-l-[#0073EA] hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          {getActionBadge(log.action_type)}
                          <span className="text-xs text-gray-500">•</span>
                          <span className="text-xs text-gray-500">
                            {log.field_changed && `Campo: ${log.field_changed}`}
                          </span>
                        </div>

                        {log.old_value && log.new_value && (
                          <div className="flex items-center gap-2 text-sm">
                            <span className="px-2 py-1 bg-red-50 text-red-700 rounded">
                              {formatValue(log.old_value)}
                            </span>
                            <ArrowRight className="w-4 h-4 text-gray-400" />
                            <span className="px-2 py-1 bg-green-50 text-green-700 rounded">
                              {formatValue(log.new_value)}
                            </span>
                          </div>
                        )}

                        <p className="text-sm text-gray-700">{log.action_description}</p>

                        <div className="flex items-center gap-4 text-xs text-gray-600">
                          <div className="flex items-center gap-1">
                            <User className="w-3 h-3" />
                            <span>Por: {log.user_name}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            <span>
                              {format(new Date(log.created_date), "dd MMM yyyy, HH:mm", { locale: es })}
                            </span>
                          </div>
                        </div>

                        {log.metadata?.reason && (
                          <div className="mt-2 p-2 bg-gray-50 rounded text-xs text-gray-600">
                            <span className="font-medium">Motivo:</span> {log.metadata.reason}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        )}
      </DialogContent>
    </Dialog>
  );
}
import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X, Plus } from "lucide-react";

const columnTypes = [
  { value: "text", label: "Texto" },
  { value: "status", label: "Estado" },
  { value: "date", label: "Fecha" },
  { value: "people", label: "Personas" },
  { value: "number", label: "Número" },
  { value: "budget", label: "Presupuesto" },
  { value: "priority", label: "Prioridad" },
  { value: "checkbox", label: "Casilla de Verificación" },
  { value: "dropdown", label: "Lista Desplegable" },
];

export default function NewColumnModal({ isOpen, onClose, onSubmit }) {
  const [columnData, setColumnData] = useState({
    title: '',
    type: 'text',
  });
  const [dropdownOptions, setDropdownOptions] = useState([
    { value: 'opcion1', label: 'Opción 1', color: '#787D80' },
    { value: 'opcion2', label: 'Opción 2', color: '#0073EA' },
  ]);
  const [newOptionLabel, setNewOptionLabel] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const colorOptions = [
    '#787D80', '#0073EA', '#00C875', '#FFCB00', '#E2445C', '#A25DDC', '#00D9FF'
  ];

  const handleAddOption = () => {
    if (newOptionLabel.trim()) {
      const newOption = {
        value: newOptionLabel.toLowerCase().replace(/\s+/g, '_'),
        label: newOptionLabel.trim(),
        color: colorOptions[dropdownOptions.length % colorOptions.length]
      };
      setDropdownOptions([...dropdownOptions, newOption]);
      setNewOptionLabel('');
    }
  };

  const handleRemoveOption = (indexToRemove) => {
    setDropdownOptions(dropdownOptions.filter((_, index) => index !== indexToRemove));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!columnData.title.trim()) return;

    setIsSubmitting(true);
    try {
      const dataToSubmit = {
        title: columnData.title,
        type: columnData.type,
      };

      // Add default options based on column type
      if (columnData.type === 'status') {
        dataToSubmit.options = {
          choices: [
            { label: 'Sin Iniciar', color: '#C4C4C4' },
            { label: 'Trabajando en ello', color: '#FFCB00' },
            { label: 'Hecho', color: '#00C875' },
            { label: 'Bloqueado', color: '#E2445C' }
          ]
        };
      } else if (columnData.type === 'dropdown') {
        dataToSubmit.options = {
          choices: dropdownOptions
        };
      } else if (columnData.type === 'budget') {
        dataToSubmit.options = {
          currency: 'USD'
        };
      } else if (columnData.type === 'priority') {
        dataToSubmit.options = {
          choices: [
            { value: 'bajo', label: 'Bajo', color: '#787D80' },
            { value: 'medio', label: 'Medio', color: '#FFCB00' },
            { value: 'alto', label: 'Alto', color: '#FDAB3D' },
            { value: 'critico', label: 'Crítico', color: '#E2445C' }
          ]
        };
      }

      await onSubmit(dataToSubmit);
      // Reset form
      setColumnData({ title: '', type: 'text' });
      setDropdownOptions([
        { value: 'opcion1', label: 'Opción 1', color: '#787D80' },
        { value: 'opcion2', label: 'Opción 2', color: '#0073EA' },
      ]);
      setNewOptionLabel('');
    } catch (error) {
      console.error('Error al crear columna:', error);
    }
    setIsSubmitting(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-[#323338]">
            Añadir Nueva Columna
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
          <div className="space-y-2">
            <Label htmlFor="column-title" className="text-[#323338] font-medium">
              Título de la Columna *
            </Label>
            <Input
              id="column-title"
              value={columnData.title}
              onChange={(e) => setColumnData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="ej., Prioridad, Presupuesto"
              className="rounded-xl border-[#E1E5F3] h-12 focus:ring-2 focus:ring-[#0073EA]/20"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="column-type" className="text-[#323338] font-medium">Tipo de Columna</Label>
            <Select
              value={columnData.type}
              onValueChange={(value) => setColumnData(prev => ({ ...prev, type: value }))}
            >
              <SelectTrigger id="column-type" className="rounded-xl border-[#E1E5F3] h-12">
                <SelectValue placeholder="Selecciona el tipo de columna" />
              </SelectTrigger>
              <SelectContent>
                {columnTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Dropdown Options Configuration */}
          {columnData.type === 'dropdown' && (
            <div className="space-y-3">
              <Label className="text-[#323338] font-medium">Opciones del Menú</Label>
              
              {/* Existing Options */}
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {dropdownOptions.map((option, index) => (
                  <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                    <div 
                      className="w-3 h-3 rounded-full flex-shrink-0"
                      style={{ backgroundColor: option.color }}
                    />
                    <span className="flex-1 text-sm">{option.label}</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-red-500 hover:text-red-700"
                      onClick={() => handleRemoveOption(index)}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>

              {/* Add New Option */}
              <div className="flex gap-2">
                <Input
                  value={newOptionLabel}
                  onChange={(e) => setNewOptionLabel(e.target.value)}
                  placeholder="Añadir opción..."
                  className="flex-1 h-9 rounded-lg border-[#E1E5F3]"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddOption();
                    }
                  }}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="h-9 w-9 rounded-lg border-[#E1E5F3]"
                  onClick={handleAddOption}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}

          <DialogFooter className="pt-6">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="rounded-xl h-12 px-6"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={!columnData.title.trim() || isSubmitting}
              className="bg-[#0073EA] hover:bg-[#0056B3] text-white rounded-xl h-12 px-6 font-medium"
            >
              {isSubmitting ? 'Añadiendo...' : 'Añadir Columna'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
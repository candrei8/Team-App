import React, { useState, useEffect } from 'react';
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  ChevronDown, 
  ChevronRight, 
  Plus, 
  Trash2, 
  GripVertical,
  CheckCircle2,
  Circle
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

export default function SubtasksList({ 
  parentItem, 
  allItems,
  onItemsChange,
  board 
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isAddingSubtask, setIsAddingSubtask] = useState(false);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState("");
  const [subtasks, setSubtasks] = useState([]);

  useEffect(() => {
    // Filter subtasks for this parent
    const parentSubtasks = allItems.filter(item => item.parent_item_id === parentItem.id);
    setSubtasks(parentSubtasks.sort((a, b) => (a.order_index || 0) - (b.order_index || 0)));
  }, [allItems, parentItem.id]);

  const completedCount = subtasks.filter(st => st.is_completed).length;
  const totalCount = subtasks.length;
  const completionPercentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const handleAddSubtask = async () => {
    if (!newSubtaskTitle.trim()) return;

    try {
      const newSubtask = await base44.entities.Item.create({
        board_id: parentItem.board_id,
        group_id: parentItem.group_id,
        parent_item_id: parentItem.id,
        title: newSubtaskTitle,
        order_index: subtasks.length,
        is_completed: false,
        priority: parentItem.priority || 'medium',
        data: {
          // Inherit assigned people from parent if exists
          ...(parentItem.data?.people && { people: parentItem.data.people })
        }
      });

      onItemsChange([...allItems, newSubtask]);
      setNewSubtaskTitle("");
      setIsAddingSubtask(false);
    } catch (error) {
      console.error("Error creating subtask:", error);
      alert("Error al crear subtarea. Intenta de nuevo.");
    }
  };

  const handleToggleSubtask = async (subtask) => {
    try {
      const newCompletedState = !subtask.is_completed;
      await base44.entities.Item.update(subtask.id, { 
        is_completed: newCompletedState 
      });

      const updatedItems = allItems.map(item => 
        item.id === subtask.id 
          ? { ...item, is_completed: newCompletedState }
          : item
      );
      onItemsChange(updatedItems);

      // Check if all subtasks are completed
      const allCompleted = subtasks.every(st => 
        st.id === subtask.id ? newCompletedState : st.is_completed
      );

      if (allCompleted && !parentItem.is_completed) {
        // Suggest marking parent as completed
        if (confirm(`¡Todas las subtareas están completadas! ¿Marcar "${parentItem.title}" como completada también?`)) {
          await base44.entities.Item.update(parentItem.id, { is_completed: true });
          onItemsChange(updatedItems.map(item => 
            item.id === parentItem.id 
              ? { ...item, is_completed: true }
              : item
          ));
        }
      }
    } catch (error) {
      console.error("Error updating subtask:", error);
    }
  };

  const handleDeleteSubtask = async (subtaskId) => {
    if (!confirm("¿Eliminar esta subtarea?")) return;

    try {
      await base44.entities.Item.delete(subtaskId);
      onItemsChange(allItems.filter(item => item.id !== subtaskId));
    } catch (error) {
      console.error("Error deleting subtask:", error);
    }
  };

  const handleDragEnd = async (result) => {
    if (!result.destination) return;

    const reorderedSubtasks = Array.from(subtasks);
    const [movedSubtask] = reorderedSubtasks.splice(result.source.index, 1);
    reorderedSubtasks.splice(result.destination.index, 0, movedSubtask);

    // Update order_index for all affected subtasks
    const updates = reorderedSubtasks.map((subtask, index) => ({
      id: subtask.id,
      order_index: index
    }));

    setSubtasks(reorderedSubtasks);

    try {
      await Promise.all(
        updates.map(update => 
          base44.entities.Item.update(update.id, { order_index: update.order_index })
        )
      );

      const updatedItems = allItems.map(item => {
        const update = updates.find(u => u.id === item.id);
        return update ? { ...item, order_index: update.order_index } : item;
      });
      onItemsChange(updatedItems);
    } catch (error) {
      console.error("Error reordering subtasks:", error);
    }
  };

  if (totalCount === 0 && !isAddingSubtask) {
    return (
      <div className="ml-12 mt-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsAddingSubtask(true)}
          className="text-[#676879] hover:text-[#0073EA] hover:bg-[#E1E5F3] h-7 text-xs"
        >
          <Plus className="w-3 h-3 mr-1" />
          Añadir subtarea
        </Button>
      </div>
    );
  }

  return (
    <div className="ml-8 mt-2 mb-2">
      {/* Header */}
      <div className="flex items-center gap-2 mb-2">
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded ? (
            <ChevronDown className="w-4 h-4 text-[#676879]" />
          ) : (
            <ChevronRight className="w-4 h-4 text-[#676879]" />
          )}
        </Button>

        <div className="flex items-center gap-2 flex-1">
          <span className="text-xs font-medium text-[#676879]">
            Subtareas
          </span>
          <Badge variant="outline" className="h-5 text-xs">
            {completedCount}/{totalCount}
          </Badge>
          {totalCount > 0 && (
            <div className="flex-1 max-w-[120px]">
              <Progress 
                value={completionPercentage} 
                className="h-1.5"
              />
            </div>
          )}
          <span className="text-xs text-[#676879]">{completionPercentage}%</span>
        </div>

        {isExpanded && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsAddingSubtask(true)}
            className="text-[#676879] hover:text-[#0073EA] hover:bg-[#E1E5F3] h-7 text-xs"
          >
            <Plus className="w-3 h-3 mr-1" />
            Añadir
          </Button>
        )}
      </div>

      {/* Subtasks List */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="space-y-1 pl-4 border-l-2 border-[#E1E5F3] ml-3">
              <DragDropContext onDragEnd={handleDragEnd}>
                <Droppable droppableId={`subtasks-${parentItem.id}`}>
                  {(provided) => (
                    <div
                      {...provided.droppableProps}
                      ref={provided.innerRef}
                    >
                      {subtasks.map((subtask, index) => (
                        <Draggable 
                          key={subtask.id} 
                          draggableId={subtask.id} 
                          index={index}
                        >
                          {(provided, snapshot) => (
                            <motion.div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: index * 0.05 }}
                              className={`group flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-[#F5F6F8] transition-colors ${
                                snapshot.isDragging ? 'bg-white shadow-lg' : ''
                              }`}
                            >
                              <div
                                {...provided.dragHandleProps}
                                className="cursor-grab hover:cursor-grabbing opacity-0 group-hover:opacity-100"
                              >
                                <GripVertical className="w-3 h-3 text-[#676879]" />
                              </div>

                              <button
                                onClick={() => handleToggleSubtask(subtask)}
                                className="flex-shrink-0"
                              >
                                {subtask.is_completed ? (
                                  <CheckCircle2 className="w-4 h-4 text-[#00C875]" />
                                ) : (
                                  <Circle className="w-4 h-4 text-[#676879]" />
                                )}
                              </button>

                              <span 
                                className={`flex-1 text-sm ${
                                  subtask.is_completed 
                                    ? 'line-through text-[#676879]' 
                                    : 'text-[#323338]'
                                }`}
                              >
                                {subtask.title}
                              </span>

                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 opacity-0 group-hover:opacity-100 hover:bg-red-50"
                                onClick={() => handleDeleteSubtask(subtask.id)}
                              >
                                <Trash2 className="w-3 h-3 text-red-500" />
                              </Button>
                            </motion.div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </DragDropContext>

              {/* Add Subtask Input */}
              {isAddingSubtask && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 py-2 px-3"
                >
                  <Circle className="w-4 h-4 text-[#676879] flex-shrink-0" />
                  <Input
                    value={newSubtaskTitle}
                    onChange={(e) => setNewSubtaskTitle(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleAddSubtask();
                      if (e.key === 'Escape') {
                        setIsAddingSubtask(false);
                        setNewSubtaskTitle("");
                      }
                    }}
                    placeholder="Escribe el nombre de la subtarea..."
                    autoFocus
                    className="h-7 text-sm border-[#E1E5F3] focus:border-[#0073EA]"
                  />
                  <Button
                    size="sm"
                    onClick={handleAddSubtask}
                    disabled={!newSubtaskTitle.trim()}
                    className="h-7 px-3 bg-[#0073EA] hover:bg-[#0056B3]"
                  >
                    Añadir
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setIsAddingSubtask(false);
                      setNewSubtaskTitle("");
                    }}
                    className="h-7 px-3"
                  >
                    Cancelar
                  </Button>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
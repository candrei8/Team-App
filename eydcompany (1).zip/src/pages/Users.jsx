import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Users as UsersIcon,
  Shield,
  Search,
  Briefcase,
  Mail,
  Calendar,
  UserX,
  UserCheck,
  AlertCircle,
  Clock,
  Ban,
  CheckCircle,
  Eye,
  Brain,
  Megaphone,
  Globe,
  Crown,
  Palette,
  Cog,
  DollarSign,
  Heart,
  Code,
  TrendingUp,
  History
} from "lucide-react";
import UserAuditHistory from "../components/users/UserAuditHistory";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { useToast } from "@/components/ui/use-toast";

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [userToActivate, setUserToActivate] = useState(null);
  const [userToSuspend, setUserToSuspend] = useState(null);
  const [suspensionReason, setSuspensionReason] = useState("");
  const [auditHistoryUser, setAuditHistoryUser] = useState(null);

  const { toast } = useToast();
  const isAdmin = currentUser?.role === "admin" || currentUser?.custom_role === "admin";

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    filterUsers();
  }, [searchQuery, users]);

  const loadUsers = async () => {
    setIsLoading(true);
    try {
      const [currentUserData, allUsers] = await Promise.all([
        base44.auth.me(),
        base44.entities.User.list("-created_date")
      ]);
      setCurrentUser(currentUserData);
      setUsers(allUsers);
      
      // Notificar a admins sobre usuarios pendientes
      const pendingCount = allUsers.filter(u => u.status === "pending").length;
      const userIsAdmin = currentUserData.role === "admin" || currentUserData.custom_role === "admin";
      if (userIsAdmin && pendingCount > 0) {
        console.log(`📢 ${pendingCount} usuario(s) pendiente(s) de aprobación`);
      }
    } catch (error) {
      console.error("Error al cargar usuarios:", error);
    }
    setIsLoading(false);
  };

  const filterUsers = () => {
    if (!searchQuery) {
      setFilteredUsers(users);
      return;
    }

    const lowercased = searchQuery.toLowerCase();
    const filtered = users.filter(user =>
      user.full_name?.toLowerCase().includes(lowercased) ||
      user.email?.toLowerCase().includes(lowercased) ||
      user.department?.toLowerCase().includes(lowercased) ||
      user.job_title?.toLowerCase().includes(lowercased)
    );
    setFilteredUsers(filtered);
  };

  const handleActivateUser = async (userId) => {
    if (!isAdmin) {
      alert("Solo los administradores pueden activar usuarios");
      return;
    }

    try {
      const user = users.find(u => u.id === userId);
      const oldStatus = user.status;
      
      await base44.entities.User.update(userId, { 
        status: "active",
        suspension_reason: null 
      });
      
      // Registrar en auditoría - quien realizó la acción es el admin
      await base44.entities.UserAuditLog.create({
        user_email: currentUser.email,
        user_id: currentUser.id,
        user_name: currentUser.full_name || currentUser.email,
        action_type: "activation",
        action_description: `Activó al usuario "${user.full_name || user.email}"`,
        target_type: "user",
        target_id: userId,
        target_name: user.full_name || user.email,
        old_value: oldStatus || "pending",
        new_value: "active"
      });
      
      // Crear notificación para el usuario
      if (user) {
        await base44.entities.Notification.create({
          user_email: user.email,
          title: "¡Cuenta Activada!",
          message: "Tu cuenta ha sido aprobada. Ya puedes acceder a todas las funciones de la aplicación.",
          type: "system",
          priority: "high",
          is_read: false
        });
      }
      
      setUsers(prevUsers =>
        prevUsers.map(u => u.id === userId ? { ...u, status: "active", suspension_reason: null } : u)
      );
      
      setUserToActivate(null);
    } catch (error) {
      console.error("Error al activar usuario:", error);
      alert("Error al activar el usuario");
    }
  };

  const handleSuspendUser = async () => {
    if (!isAdmin || !userToSuspend) {
      return;
    }

    if (!suspensionReason.trim()) {
      alert("Por favor, indica el motivo de la suspensión");
      return;
    }

    try {
      const oldStatus = userToSuspend.status;
      
      await base44.entities.User.update(userToSuspend.id, { 
        status: "suspended",
        suspension_reason: suspensionReason 
      });
      
      // Registrar en auditoría - quien realizó la acción es el admin
      await base44.entities.UserAuditLog.create({
        user_email: currentUser.email,
        user_id: currentUser.id,
        user_name: currentUser.full_name || currentUser.email,
        action_type: "suspension",
        action_description: `Suspendió al usuario "${userToSuspend.full_name || userToSuspend.email}"`,
        target_type: "user",
        target_id: userToSuspend.id,
        target_name: userToSuspend.full_name || userToSuspend.email,
        old_value: oldStatus || "active",
        new_value: "suspended",
        metadata: { reason: suspensionReason }
      });
      
      // Crear notificación para el usuario
      await base44.entities.Notification.create({
        user_email: userToSuspend.email,
        title: "Cuenta Suspendida",
        message: `Tu cuenta ha sido suspendida. Motivo: ${suspensionReason}`,
        type: "system",
        priority: "urgent",
        is_read: false
      });
      
      setUsers(prevUsers =>
        prevUsers.map(u => u.id === userToSuspend.id ? { ...u, status: "suspended", suspension_reason: suspensionReason } : u)
      );
      
      setUserToSuspend(null);
      setSuspensionReason("");
    } catch (error) {
      console.error("Error al suspender usuario:", error);
      alert("Error al suspender el usuario");
    }
  };

  const handleRoleChange = async (userId, newRole) => {
    if (!isAdmin) {
      alert("Solo los administradores pueden cambiar roles");
      return;
    }

    const user = users.find(u => u.id === userId);
    const oldRole = user.custom_role || user.role;

    // Determinar rol del sistema (para permisos reales de backend)
    const systemRole = newRole === 'admin' ? 'admin' : 'user';

    // Actualización optimista - actualizar UI inmediatamente
    setUsers(prevUsers =>
      prevUsers.map(u => u.id === userId ? { ...u, custom_role: newRole, role: systemRole } : u)
    );

    try {
      // Actualizamos tanto custom_role como role del sistema para asegurar permisos completos
      await base44.entities.User.update(userId, { 
        custom_role: newRole, 
        role: systemRole 
      });

      // Registrar en auditoría - quien realizó la acción es el admin
      await base44.entities.UserAuditLog.create({
        user_email: currentUser.email,
        user_id: currentUser.id,
        user_name: currentUser.full_name || currentUser.email,
        action_type: "role_change",
        action_description: `Cambió el rol de "${user.full_name || user.email}" de ${oldRole} a ${newRole}`,
        target_type: "user",
        target_id: userId,
        target_name: user.full_name || user.email,
        old_value: oldRole,
        new_value: newRole
      });

      toast({
        title: "Rol actualizado",
        description: `El usuario ahora es ${newRole === 'admin' ? 'Administrador' : newRole === 'guest' ? 'Invitado' : 'Equipo'}.`,
      });
    } catch (error) {
      console.error("Error al cambiar rol:", error);
      toast({
        title: "Error",
        description: "No se pudo cambiar el rol del usuario.",
        variant: "destructive",
      });
      // Revertir cambio en caso de error
      loadUsers();
    }
  };

  const handleDepartmentChange = async (userId, newDepartment) => {
    if (!isAdmin) {
      alert("Solo los administradores pueden cambiar departamentos");
      return;
    }

    const user = users.find(u => u.id === userId);
    const oldDepartment = user.department;

    // Actualización optimista - actualizar UI inmediatamente
    setUsers(prevUsers =>
      prevUsers.map(u => u.id === userId ? { ...u, department: newDepartment } : u)
    );

    try {
      await base44.entities.User.update(userId, { department: newDepartment });
      
      // Registrar en auditoría - quien realizó la acción es el admin
      await base44.entities.UserAuditLog.create({
        user_email: currentUser.email,
        user_id: currentUser.id,
        user_name: currentUser.full_name || currentUser.email,
        action_type: "department_change",
        action_description: `Cambió el departamento de "${user.full_name || user.email}" de ${oldDepartment || "Sin departamento"} a ${newDepartment}`,
        target_type: "user",
        target_id: userId,
        target_name: user.full_name || user.email,
        old_value: oldDepartment || "Sin departamento",
        new_value: newDepartment
      });
    } catch (error) {
      console.error("Error al cambiar departamento:", error);
      alert("Error al cambiar el departamento");
      // Revertir cambio en caso de error
      loadUsers();
    }
  };

  const getRoleBadge = (user) => {
    const role = user.custom_role || user.role || "user";
    if (role === "admin") {
      return (
        <Badge className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0">
          <Shield className="w-3 h-3 mr-1" />
          Administrador
        </Badge>
      );
    }
    if (role === "guest") {
      return (
        <Badge variant="outline" className="border-blue-300 text-blue-600 bg-blue-50">
          <Eye className="w-3 h-3 mr-1" />
          Invitado
        </Badge>
      );
    }
    return (
      <Badge variant="secondary" className="bg-gray-100 text-gray-700">
        <UsersIcon className="w-3 h-3 mr-1" />
        Equipo
      </Badge>
    );
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "pending":
        return (
          <Badge className="bg-amber-100 text-amber-700 border-amber-200">
            <Clock className="w-3 h-3 mr-1" />
            Pendiente
          </Badge>
        );
      case "suspended":
        return (
          <Badge variant="destructive" className="bg-red-100 text-red-700 border-red-200">
            <Ban className="w-3 h-3 mr-1" />
            Suspendido
          </Badge>
        );
      default:
        return (
          <Badge className="bg-green-100 text-green-700 border-green-200">
            <UserCheck className="w-3 h-3 mr-1" />
            Activo
          </Badge>
        );
    }
  };

  const getDepartmentBadge = (department) => {
    if (!department) {
      return (
        <Badge variant="outline" className="text-gray-500 text-xs">
          <Briefcase className="w-3 h-3 mr-1" />
          Sin departamento
        </Badge>
      );
    }

    const departmentConfig = {
      "IA": {
        gradient: "from-purple-500 to-indigo-600",
        icon: Brain,
        label: "IA"
      },
      "Marketing": {
        gradient: "from-pink-500 to-rose-600",
        icon: Megaphone,
        label: "Marketing"
      },
      "Relaciones Internacionales": {
        gradient: "from-blue-500 to-cyan-600",
        icon: Globe,
        label: "Rel. Internacionales"
      },
      "Dirección": {
        gradient: "from-indigo-500 to-purple-600",
        icon: Crown,
        label: "Dirección"
      },
      "Diseñador": {
        gradient: "from-orange-500 to-amber-600",
        icon: Palette,
        label: "Diseñador"
      },
      "Operaciones": {
        gradient: "from-green-500 to-emerald-600",
        icon: Cog,
        label: "Operaciones"
      },
      "Finanzas": {
        gradient: "from-emerald-500 to-teal-600",
        icon: DollarSign,
        label: "Finanzas"
      },
      "Recursos Humanos": {
        gradient: "from-amber-500 to-orange-600",
        icon: Heart,
        label: "RRHH"
      },
      "Tecnología": {
        gradient: "from-cyan-500 to-blue-600",
        icon: Code,
        label: "Tecnología"
      },
      "Ventas": {
        gradient: "from-red-500 to-pink-600",
        icon: TrendingUp,
        label: "Ventas"
      },
      "Otro": {
        gradient: "from-gray-500 to-gray-600",
        icon: Briefcase,
        label: "Otro"
      }
    };

    const config = departmentConfig[department] || departmentConfig["Otro"];
    const Icon = config.icon;

    return (
      <Badge className={`bg-gradient-to-r ${config.gradient} text-white border-0 shadow-sm text-xs`}>
        <Icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  const getUserInitials = (name) => {
    if (!name) return "U";
    const names = name.split(" ");
    if (names.length >= 2) {
      return `${names[0][0]}${names[1][0]}`.toUpperCase();
    }
    return names[0][0].toUpperCase();
  };

  const activeUsers = users.filter(u => u.status === "active");
  const pendingUsers = users.filter(u => u.status === "pending" || !u.status);
  const suspendedUsers = users.filter(u => u.status === "suspended");
  const adminCount = users.filter(u => (u.custom_role || u.role) === "admin").length;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F6F8]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0073EA] mx-auto mb-4"></div>
          <p className="text-[#676879]">Cargando usuarios...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 bg-[#F5F6F8] min-h-screen">
      <div className="max-w-7xl mx-auto space-y-4 sm:space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-3 sm:gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-[#323338] flex items-center gap-2 sm:gap-3">
              <UsersIcon className="w-6 h-6 sm:w-8 sm:h-8 text-[#0073EA]" />
              <span className="truncate">{isAdmin ? "Gestión de Usuarios" : "Directorio de Usuarios"}</span>
            </h1>
            <p className="text-sm text-[#676879] mt-1 flex flex-wrap items-center gap-2">
              <span>{users.length} usuario{users.length !== 1 ? "s" : ""} registrado{users.length !== 1 ? "s" : ""} en total</span>
            </p>
          </div>
          {isAdmin && pendingUsers.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 sm:px-4 sm:py-3 animate-pulse">
              <div className="flex items-start gap-2">
                <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs sm:text-sm font-medium text-amber-900">
                    {pendingUsers.length} usuario{pendingUsers.length !== 1 ? "s" : ""} pendiente{pendingUsers.length !== 1 ? "s" : ""} de aprobación
                  </p>
                  <p className="text-xs text-amber-700 hidden sm:block">Requieren tu aprobación para acceder</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-[#676879]" />
          <Input
            placeholder="Buscar usuarios..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-white border-[#E1E5F3] rounded-lg h-10 text-sm"
          />
        </div>

        {/* Stats Cards - Responsive Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4 lg:gap-6">
          <Card>
            <CardContent className="p-3 sm:p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-xs sm:text-sm text-gray-500 mb-1">Total</p>
                  <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-[#323338] truncate">{users.length}</p>
                </div>
                <div className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 bg-blue-100 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                  <UsersIcon className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-3 sm:p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-xs sm:text-sm text-gray-500 mb-1">Pendientes</p>
                  <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-amber-600 truncate">{pendingUsers.length}</p>
                </div>
                <div className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 bg-amber-100 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                  <Clock className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-3 sm:p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-xs sm:text-sm text-gray-500 mb-1">Activos</p>
                  <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-green-600 truncate">{activeUsers.length}</p>
                </div>
                <div className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 bg-green-100 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                  <UserCheck className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-3 sm:p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-xs sm:text-sm text-gray-500 mb-1">Suspendidos</p>
                  <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-red-600 truncate">{suspendedUsers.length}</p>
                </div>
                <div className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 bg-red-100 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                  <Ban className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="col-span-2 sm:col-span-1">
            <CardContent className="p-3 sm:p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-xs sm:text-sm text-gray-500 mb-1">Admins</p>
                  <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-purple-600 truncate">{adminCount}</p>
                </div>
                <div className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 bg-purple-100 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                  <Shield className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Users Table - Desktop */}
        <Card className="hidden md:block">
          <CardHeader>
            <CardTitle>Lista de Usuarios</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Usuario</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Cargo</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Departamento</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Rol</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Estado</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Registro</th>
                    {isAdmin && (
                      <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Acciones</th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((user) => (
                    <tr key={user.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-3">
                          {user.avatar_url ? (
                            <img 
                              src={user.avatar_url} 
                              alt={user.full_name} 
                              className="w-10 h-10 rounded-full object-cover flex-shrink-0"
                            />
                          ) : (
                            <div className="w-10 h-10 bg-gradient-to-br from-[#0073EA] to-[#00C875] rounded-full flex items-center justify-center flex-shrink-0">
                              <span className="text-white font-semibold text-sm">
                                {getUserInitials(user.full_name)}
                              </span>
                            </div>
                          )}
                          <div className="min-w-0">
                            <p className="font-medium text-gray-900 truncate">{user.full_name || "Sin nombre"}</p>
                            <p className="text-sm text-gray-500 flex items-center gap-1 truncate">
                              <Mail className="w-3 h-3 flex-shrink-0" />
                              <span className="truncate">{user.email}</span>
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <p className="text-sm text-gray-700 truncate">{user.job_title || "No especificado"}</p>
                      </td>
                      <td className="py-4 px-4">
                        {isAdmin ? (
                          <Select
                            value={user.department || ""}
                            onValueChange={(value) => handleDepartmentChange(user.id, value)}
                          >
                            <SelectTrigger className="w-[180px] h-8 text-sm">
                              <SelectValue placeholder="Seleccionar" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="IA">IA</SelectItem>
                              <SelectItem value="Marketing">Marketing</SelectItem>
                              <SelectItem value="Relaciones Internacionales">Relaciones Internacionales</SelectItem>
                              <SelectItem value="Dirección">Dirección</SelectItem>
                              <SelectItem value="Diseñador">Diseñador</SelectItem>
                              <SelectItem value="Operaciones">Operaciones</SelectItem>
                              <SelectItem value="Finanzas">Finanzas</SelectItem>
                              <SelectItem value="Recursos Humanos">Recursos Humanos</SelectItem>
                              <SelectItem value="Tecnología">Tecnología</SelectItem>
                              <SelectItem value="Ventas">Ventas</SelectItem>
                              <SelectItem value="Otro">Otro</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          getDepartmentBadge(user.department)
                        )}
                      </td>
                      <td className="py-4 px-4">
                        {isAdmin && user.id !== currentUser.id ? (
                          <Select
                            value={user.custom_role || user.role}
                            onValueChange={(value) => handleRoleChange(user.id, value)}
                          >
                            <SelectTrigger className="w-[140px] h-8 text-sm">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="admin">Administrador</SelectItem>
                              <SelectItem value="user">Equipo</SelectItem>
                              <SelectItem value="guest">Invitado</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          getRoleBadge(user)
                        )}
                      </td>
                      <td className="py-4 px-4">
                        {getStatusBadge(user.status || "pending")}
                      </td>
                      <td className="py-4 px-4">
                        <p className="text-sm text-gray-500 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(user.created_date), "d MMM yyyy", { locale: es })}
                        </p>
                      </td>
                      {isAdmin && (
                        <td className="py-4 px-4">
                          {user.id !== currentUser.id && (
                            <div className="flex gap-2">
                              {(user.status === "pending" || user.status === "suspended" || !user.status) && (
                                <Button
                                  variant="default"
                                  size="sm"
                                  onClick={() => setUserToActivate(user)}
                                  className="text-xs bg-green-600 hover:bg-green-700"
                                >
                                  <CheckCircle className="w-3 h-3 mr-1" />
                                  Activar
                                </Button>
                              )}
                              {user.status === "active" && (
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => setUserToSuspend(user)}
                                  className="text-xs"
                                >
                                  <Ban className="w-3 h-3 mr-1" />
                                  Suspender
                                </Button>
                              )}
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setAuditHistoryUser(user)}
                                className="text-xs"
                              >
                                <History className="w-3 h-3 mr-1" />
                                Historial
                              </Button>
                            </div>
                          )}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Users Cards - Mobile */}
        <div className="md:hidden space-y-3">
          {filteredUsers.map((user) => (
            <Card key={user.id}>
              <CardContent className="p-4">
                <div className="space-y-3">
                  {/* User Info */}
                  <div className="flex items-start gap-3">
                    {user.avatar_url ? (
                      <img 
                        src={user.avatar_url} 
                        alt={user.full_name} 
                        className="w-12 h-12 rounded-full object-cover flex-shrink-0"
                      />
                    ) : (
                      <div className="w-12 h-12 bg-gradient-to-br from-[#0073EA] to-[#00C875] rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-white font-semibold">
                          {getUserInitials(user.full_name)}
                        </span>
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 truncate">{user.full_name || "Sin nombre"}</p>
                      <p className="text-sm text-gray-500 truncate">{user.email}</p>
                      <p className="text-xs text-gray-400 mt-1">{user.job_title || "No especificado"}</p>
                    </div>
                  </div>

                  {/* Badges */}
                  <div className="flex flex-wrap gap-2">
                    {getDepartmentBadge(user.department)}
                    {getRoleBadge(user)}
                    {getStatusBadge(user.status || "pending")}
                  </div>

                  {/* Mobile Admin Controls */}
                  {isAdmin && user.id !== currentUser.id && (
                    <div className="grid grid-cols-2 gap-3 pt-2">
                      <div className="space-y-1">
                        <p className="text-xs text-gray-500 font-medium">Departamento</p>
                        <Select
                          value={user.department || ""}
                          onValueChange={(value) => handleDepartmentChange(user.id, value)}
                        >
                          <SelectTrigger className="h-8 text-xs w-full">
                            <SelectValue placeholder="Seleccionar" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="IA">IA</SelectItem>
                            <SelectItem value="Marketing">Marketing</SelectItem>
                            <SelectItem value="Relaciones Internacionales">Rel. Int.</SelectItem>
                            <SelectItem value="Dirección">Dirección</SelectItem>
                            <SelectItem value="Diseñador">Diseñador</SelectItem>
                            <SelectItem value="Operaciones">Operaciones</SelectItem>
                            <SelectItem value="Finanzas">Finanzas</SelectItem>
                            <SelectItem value="Recursos Humanos">RRHH</SelectItem>
                            <SelectItem value="Tecnología">Tecnología</SelectItem>
                            <SelectItem value="Ventas">Ventas</SelectItem>
                            <SelectItem value="Otro">Otro</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-gray-500 font-medium">Rol</p>
                        <Select
                          value={user.custom_role || user.role}
                          onValueChange={(value) => handleRoleChange(user.id, value)}
                        >
                          <SelectTrigger className="h-8 text-xs w-full">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="admin">Administrador</SelectItem>
                            <SelectItem value="user">Equipo</SelectItem>
                            <SelectItem value="guest">Invitado</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  {isAdmin && user.id !== currentUser.id && (
                    <div className="flex gap-2 pt-2 border-t">
                      {(user.status === "pending" || user.status === "suspended" || !user.status) && (
                        <Button
                          size="sm"
                          onClick={() => setUserToActivate(user)}
                          className="flex-1 text-xs bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Activar
                        </Button>
                      )}
                      {user.status === "active" && (
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => setUserToSuspend(user)}
                          className="flex-1 text-xs"
                        >
                          <Ban className="w-3 h-3 mr-1" />
                          Suspender
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setAuditHistoryUser(user)}
                        className="flex-1 text-xs"
                      >
                        <History className="w-3 h-3 mr-1" />
                        Historial
                      </Button>
                      </div>
                      )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Activate User Dialog */}
        {isAdmin && (
          <AlertDialog open={!!userToActivate} onOpenChange={() => setUserToActivate(null)}>
            <AlertDialogContent className="max-w-md mx-4">
              <AlertDialogHeader>
                <AlertDialogTitle>Activar Usuario</AlertDialogTitle>
                <AlertDialogDescription>
                  ¿Estás seguro de que quieres <strong>activar</strong> a{" "}
                  <strong>{userToActivate?.full_name}</strong> ({userToActivate?.email})?
                  <br /><br />
                  El usuario podrá acceder a la aplicación y recibirá una notificación.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => handleActivateUser(userToActivate.id)}
                  className="bg-green-600 hover:bg-green-700"
                >
                  Sí, activar
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}

        {/* Suspend User Dialog */}
        {isAdmin && (
          <Dialog open={!!userToSuspend} onOpenChange={(open) => {
            if (!open) {
              setUserToSuspend(null);
              setSuspensionReason("");
            }
          }}>
            <DialogContent className="max-w-md mx-4">
              <DialogHeader>
                <DialogTitle>Suspender Usuario</DialogTitle>
                <DialogDescription>
                  Vas a suspender a <strong>{userToSuspend?.full_name}</strong> ({userToSuspend?.email}).
                  <br />
                  El usuario NO podrá acceder a la aplicación.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="reason">Motivo de la Suspensión *</Label>
                  <Textarea
                    id="reason"
                    placeholder="Ejemplo: Violación de las políticas de uso, comportamiento inapropiado, etc."
                    value={suspensionReason}
                    onChange={(e) => setSuspensionReason(e.target.value)}
                    className="min-h-[100px]"
                    maxLength={500}
                  />
                  <p className="text-xs text-gray-500">
                    Este motivo se mostrará al usuario cuando intente acceder.
                  </p>
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => {
                    setUserToSuspend(null);
                    setSuspensionReason("");
                  }}
                >
                  Cancelar
                </Button>
                <Button
                  variant="destructive"
                  onClick={handleSuspendUser}
                  disabled={!suspensionReason.trim()}
                >
                  Suspender Usuario
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {/* Audit History Modal */}
        <UserAuditHistory
          isOpen={!!auditHistoryUser}
          onClose={() => setAuditHistoryUser(null)}
          user={auditHistoryUser}
        />
      </div>
    </div>
  );
}
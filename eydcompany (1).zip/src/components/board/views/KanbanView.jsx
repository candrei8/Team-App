import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, CalendarDays, MoreHorizontal, Users, List, Sparkles, AlertCircle } from "lucide-react";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { format, isPast, isToday } from "date-fns";
import { es } from "date-fns/locale";

import TaskEditModal from "../TaskEditModal";

// Colores estándar para estados
const STATUS_COLORS = {
  'No iniciado': '#C4C4C4',
  'Sin Iniciar': '#C4C4C4',
  'Not Started': '#C4C4C4',
  'Trabajando en ello': '#FFCB00',
  'Trabajando': '#FFCB00',
  'Working on it': '#FFCB00',
  'En progreso': '#FFCB00',
  'In Progress': '#FFCB00',
  'Hecho': '#00C875',
  'Done': '#00C875',
  'Completado': '#00C875',
  'Completed': '#00C875',
  'Bloqueado': '#E2445C',
  'Stuck': '#E2445C'
};

// Paleta de colores para personas
const PEOPLE_COLORS = [
  '#6366F1', '#8B5CF6', '#EC4899', '#F59E0B', 
  '#10B981', '#3B82F6', '#6366F1', '#F59E0B'
];

const getStatusColor = (status) => {
  return STATUS_COLORS[status] || '#9CA3AF';
};

const getPersonColor = (index) => {
  return PEOPLE_COLORS[index % PEOPLE_COLORS.length];
};

// Componente de tarjeta Kanban
const KanbanCard = ({ item, index, board, groupingType, onEdit }) => {
  const [isHovered, setIsHovered] = useState(false);

  // Obtener columnas relevantes
  const statusColumn = board?.columns?.find(col => col.type === 'status');
  const priorityColumn = board?.columns?.find(col => col.type === 'priority');
  const peopleColumn = board?.columns?.find(col => col.type === 'people');
  const dateColumn = board?.columns?.find(col => col.type === 'date');

  // Obtener valores
  const statusValue = item.data?.[statusColumn?.id];
  const priorityValue = item.data?.[priorityColumn?.id];
  const peopleValue = item.data?.[peopleColumn?.id];
  const dateValue = item.data?.[dateColumn?.id];

  // Obtener opciones de prioridad
  const priorityOption = priorityColumn?.options?.choices?.find(c => c.value === priorityValue);
  const statusOption = statusColumn?.options?.choices?.find(c => c.label === statusValue);

  // Determinar color de borde
  const getBorderColor = () => {
    if (groupingType === 'status' && priorityOption) {
      return priorityOption.color;
    } else if (groupingType === 'people' && statusOption) {
      return statusOption.color || getStatusColor(statusValue);
    }
    return '#E5E7EB';
  };

  // Verificar fecha
  const isOverdue = dateValue && isPast(new Date(dateValue)) && !isToday(new Date(dateValue));
  const isDueToday = dateValue && isToday(new Date(dateValue));

  return (
    <Draggable draggableId={item.id} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          onClick={() => !snapshot.isDragging && onEdit(item)}
          className="mb-3 group"
          style={{
            ...provided.draggableProps.style,
            transform: snapshot.isDragging
              ? provided.draggableProps.style?.transform
              : 'translate(0px, 0px)'
          }}
        >
          <Card 
            className={`
              cursor-pointer transition-all duration-200 border-l-4
              ${snapshot.isDragging 
                ? 'shadow-2xl ring-4 ring-blue-200 rotate-2 scale-105 bg-blue-50' 
                : 'shadow-sm hover:shadow-lg'
              }
            `}
            style={{ 
              borderLeftColor: getBorderColor(),
              userSelect: 'none'
            }}
          >
            <CardContent className="p-4">
              {/* Header con título */}
              <div className="flex justify-between items-start mb-3">
                <h4 className="font-semibold text-sm text-gray-900 leading-snug pr-2 line-clamp-2">
                  {item.title}
                </h4>
                {(isHovered || snapshot.isDragging) && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => {
                      e.stopPropagation();
                      onEdit(item);
                    }}
                  >
                    <MoreHorizontal className="w-4 h-4 text-gray-400" />
                  </Button>
                )}
              </div>

              {/* Badges - Solo mostrar lo relevante según agrupación */}
              <div className="flex flex-wrap gap-2 mb-3">
                {/* Mostrar prioridad si agrupamos por estado */}
                {groupingType === 'status' && priorityOption && (
                  <Badge
                    variant="outline"
                    className="text-xs font-medium border-2"
                    style={{
                      backgroundColor: `${priorityOption.color}15`,
                      borderColor: priorityOption.color,
                      color: priorityOption.color
                    }}
                  >
                    {priorityOption.label}
                  </Badge>
                )}

                {/* Mostrar estado si agrupamos por persona */}
                {groupingType === 'people' && statusValue && (
                  <Badge
                    variant="outline"
                    className="text-xs font-medium border-2"
                    style={{
                      backgroundColor: `${getStatusColor(statusValue)}15`,
                      borderColor: getStatusColor(statusValue),
                      color: getStatusColor(statusValue)
                    }}
                  >
                    {statusValue}
                  </Badge>
                )}
              </div>

              {/* Footer con fecha y persona */}
              <div className="flex items-center justify-between text-xs">
                {/* Fecha */}
                {dateValue && (
                  <div 
                    className={`flex items-center gap-1.5 px-2 py-1 rounded-md ${
                      isOverdue 
                        ? 'bg-red-50 text-red-700' 
                        : isDueToday 
                          ? 'bg-amber-50 text-amber-700' 
                          : 'bg-gray-50 text-gray-600'
                    }`}
                  >
                    {isOverdue && <AlertCircle className="w-3 h-3" />}
                    <CalendarDays className="w-3 h-3" />
                    <span className="font-medium">
                      {format(new Date(dateValue), 'MMM d', { locale: es })}
                    </span>
                  </div>
                )}

                {/* Avatar persona (solo si agrupamos por estado) */}
                {groupingType === 'status' && peopleValue && (
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-sm"
                    style={{ backgroundColor: getPersonColor(peopleValue.charCodeAt(0)) }}
                    title={peopleValue}
                  >
                    {peopleValue.substring(0, 2).toUpperCase()}
                  </div>
                )}
              </div>

              {/* Indicador de arrastre */}
              {snapshot.isDragging && (
                <div className="absolute -top-1 -right-1">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center animate-pulse">
                    <Sparkles className="w-3 h-3 text-white" />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </Draggable>
  );
};

// Componente de columna Kanban
const KanbanColumn = ({ column, groupingType, board, onEdit }) => {
  return (
    <Droppable droppableId={column.id}>
      {(provided, snapshot) => (
        <div
          className={`
            flex flex-col w-80 flex-shrink-0 rounded-2xl
            transition-all duration-300
            ${snapshot.isDraggingOver 
              ? 'bg-blue-50 shadow-xl ring-2 ring-blue-300' 
              : 'bg-gray-50'
            }
          `}
        >
          {/* Header de columna */}
          <div className="p-4 border-b border-gray-200 bg-white rounded-t-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div
                  className="w-3 h-3 rounded-full shadow-sm"
                  style={{ backgroundColor: column.color }}
                />
                <h3 className="font-bold text-gray-900">
                  {column.title}
                </h3>
                <Badge variant="secondary" className="ml-1 bg-gray-200 text-gray-700">
                  {column.items.length}
                </Badge>
              </div>
            </div>
          </div>

          {/* Área de drop */}
          <div
            ref={provided.innerRef}
            {...provided.droppableProps}
            className="flex-1 p-4 overflow-y-auto max-h-[calc(100vh-320px)] custom-scrollbar"
            style={{
              minHeight: '200px'
            }}
          >
            {/* Área vacía con placeholder */}
            {column.items.length === 0 && !snapshot.isDraggingOver && (
              <div className="flex items-center justify-center h-40 border-2 border-dashed border-gray-300 rounded-xl bg-white">
                <div className="text-center">
                  <div
                    className="w-12 h-12 rounded-full mx-auto mb-2 flex items-center justify-center"
                    style={{ backgroundColor: `${column.color}20` }}
                  >
                    <Plus className="w-6 h-6" style={{ color: column.color }} />
                  </div>
                  <p className="text-sm text-gray-500 font-medium">
                    Arrastra tareas aquí
                  </p>
                </div>
              </div>
            )}

            {/* Placeholder cuando está sobre la columna vacía */}
            {column.items.length === 0 && snapshot.isDraggingOver && (
              <div className="h-40 border-2 border-dashed border-blue-400 rounded-xl bg-blue-50 flex items-center justify-center">
                <p className="text-blue-600 font-medium">Suelta aquí para cambiar {groupingType === 'status' ? 'el estado' : 'la asignación'}</p>
              </div>
            )}

            {/* Tarjetas */}
            {column.items.map((item, index) => (
              <KanbanCard
                key={item.id}
                item={item}
                index={index}
                board={board}
                groupingType={groupingType}
                onEdit={onEdit}
              />
            ))}
            {provided.placeholder}
          </div>
        </div>
      )}
    </Droppable>
  );
};

// Componente principal KanbanView
export default function KanbanView({ board, items, onUpdateItem, onDeleteItem }) {
  const [groupBy, setGroupBy] = useState('status');
  const [editingTask, setEditingTask] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [localItems, setLocalItems] = useState(items);

  // Sincronizar con items externos
  useEffect(() => {
    setLocalItems(items);
  }, [items]);

  if (!board) {
    return (
      <div className="p-8 text-center">
        <p className="text-gray-500">Cargando tablero...</p>
      </div>
    );
  }

  // Obtener definiciones de columnas
  const statusColumn = board.columns?.find(col => col.type === 'status');
  const peopleColumn = board.columns?.find(col => col.type === 'people');

  const canGroupByStatus = statusColumn && statusColumn.options?.choices?.length > 0;
  const canGroupByPeople = peopleColumn !== undefined;

  // Validar que hay opciones de agrupación
  if (!canGroupByStatus && !canGroupByPeople) {
    return (
      <div className="p-8 text-center">
        <div className="max-w-md mx-auto bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <AlertCircle className="w-12 h-12 text-yellow-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Vista Kanban no disponible
          </h3>
          <p className="text-sm text-gray-600">
            Para usar la vista Kanban, añade una columna de tipo "Estado" o "Personas" a tu tablero.
          </p>
        </div>
      </div>
    );
  }

  // Construir columnas según agrupación
  let columns = [];

  if (groupBy === 'status' && canGroupByStatus) {
    columns = statusColumn.options.choices.map(choice => ({
      id: `status-${choice.label}`,
      title: choice.label,
      color: getStatusColor(choice.label),
      items: localItems
        .filter(item => item.data?.[statusColumn.id] === choice.label)
        .sort((a, b) => (a.order_index || 0) - (b.order_index || 0))
    }));
  } else if (groupBy === 'people' && canGroupByPeople) {
    // Obtener personas únicas
    const uniquePeople = [...new Set(
      localItems
        .map(item => item.data?.[peopleColumn.id])
        .filter(Boolean)
    )];

    // Columna de no asignados
    const unassignedItems = localItems
      .filter(item => !item.data?.[peopleColumn.id])
      .sort((a, b) => (a.order_index || 0) - (b.order_index || 0));

    if (unassignedItems.length > 0) {
      columns.push({
        id: 'people-unassigned',
        title: 'Sin asignar',
        color: '#9CA3AF',
        items: unassignedItems
      });
    }

    // Columnas de personas
    uniquePeople.forEach((person, index) => {
      columns.push({
        id: `people-${person}`,
        title: person,
        color: getPersonColor(index),
        items: localItems
          .filter(item => item.data?.[peopleColumn.id] === person)
          .sort((a, b) => (a.order_index || 0) - (b.order_index || 0))
      });
    });
  }

  // Manejar fin de drag & drop
  const handleDragEnd = async (result) => {
    const { source, destination, draggableId } = result;

    // No hay destino o mismo lugar
    if (!destination || (
      source.droppableId === destination.droppableId &&
      source.index === destination.index
    )) {
      return;
    }

    const itemToMove = localItems.find(item => item.id === draggableId);
    if (!itemToMove) return;

    // Determinar la columna activa (status o people)
    const activeColumn = groupBy === 'status' ? statusColumn : peopleColumn;

    // Movimiento dentro de la misma columna - solo reordenar
    if (source.droppableId === destination.droppableId) {
      const column = columns.find(col => col.id === source.droppableId);
      if (!column) return;

      // Actualización optimista local
      const newLocalItems = [...localItems];
      const itemIndex = newLocalItems.findIndex(item => item.id === draggableId);
      newLocalItems[itemIndex] = { ...newLocalItems[itemIndex], order_index: destination.index };
      setLocalItems(newLocalItems);

      // Actualizar en servidor
      try {
        await onUpdateItem(draggableId, { order_index: destination.index });
      } catch (error) {
        console.error("Error al reordenar tarea:", error);
        // Revertir en caso de error
        setLocalItems(items);
      }

      return;
    }

    // Movimiento entre columnas - cambiar estado/persona
    const destColumn = columns.find(col => col.id === destination.droppableId);
    if (!destColumn) return;

    // Extraer nuevo valor del ID de la columna
    let newValue;
    if (destination.droppableId.startsWith('status-')) {
      newValue = destination.droppableId.replace('status-', '');
    } else if (destination.droppableId === 'people-unassigned') {
      newValue = null;
    } else if (destination.droppableId.startsWith('people-')) {
      newValue = destination.droppableId.replace('people-', '');
    }

    // Actualizar dato del item
    const updatedData = { ...itemToMove.data };
    updatedData[activeColumn.id] = newValue;

    // Actualización optimista local
    const newLocalItems = localItems.map(item => {
      if (item.id === draggableId) {
        return { ...item, data: updatedData, order_index: destination.index };
      }
      return item;
    });
    setLocalItems(newLocalItems);

    // Actualizar en servidor
    try {
      await onUpdateItem(draggableId, {
        data: updatedData,
        order_index: destination.index
      });

      console.log(`✅ Tarea "${itemToMove.title}" movida a "${destColumn.title}"`);
    } catch (error) {
      console.error("Error al mover tarea:", error);
      // Revertir en caso de error
      setLocalItems(items);
    }
  };

  const handleEditTask = (task) => {
    setEditingTask(task);
    setShowEditModal(true);
  };

  const handleUpdateTask = async (taskId, updates) => {
    await onUpdateItem(taskId, updates);
    setShowEditModal(false);
    setEditingTask(null);
  };

  const handleDeleteTask = async (taskId) => {
    await onDeleteItem(taskId);
    setShowEditModal(false);
    setEditingTask(null);
  };

  return (
    <div className="h-full">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-6 mb-6 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="text-white">
            <h2 className="text-2xl font-bold mb-1">Tablero Kanban</h2>
            <p className="text-blue-100 text-sm">
              Arrastra y suelta para organizar tus tareas • {localItems.length} tarea{localItems.length !== 1 ? 's' : ''} en total
            </p>
          </div>

          <div className="flex items-center gap-3 bg-white rounded-xl px-4 py-2.5 shadow-md">
            <span className="text-sm font-medium text-gray-700">Agrupar por:</span>
            <Select value={groupBy} onValueChange={setGroupBy}>
              <SelectTrigger className="w-36 border-0 focus:ring-0">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {canGroupByStatus && (
                  <SelectItem value="status">
                    <div className="flex items-center gap-2">
                      <List className="w-4 h-4" />
                      Estado
                    </div>
                  </SelectItem>
                )}
                {canGroupByPeople && (
                  <SelectItem value="people">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      Personas
                    </div>
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Tablero Kanban */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="flex gap-4 overflow-x-auto pb-6 px-1">
          {columns.map((column) => (
            <KanbanColumn
              key={column.id}
              column={column}
              groupingType={groupBy}
              board={board}
              onEdit={handleEditTask}
            />
          ))}
        </div>
      </DragDropContext>

      {/* Modal de edición */}
      {editingTask && (
        <TaskEditModal
          isOpen={showEditModal}
          onClose={() => {
            setShowEditModal(false);
            setEditingTask(null);
          }}
          task={editingTask}
          board={board}
          onUpdate={handleUpdateTask}
          onDelete={handleDeleteTask}
        />
      )}

      {/* Estilos personalizados */}
      <style jsx global>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #CBD5E1;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #94A3B8;
        }
      `}</style>
    </div>
  );
}
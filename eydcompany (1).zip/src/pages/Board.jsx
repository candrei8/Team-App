import React, { useState, useEffect } from "react";
import { Board } from "@/api/entities";
import { Item } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  Search, 
  Filter, 
  Users, 
  ArrowLeft,
  Table2,
  Columns,
  Calendar as CalendarIcon,
  BarChart3,
  X,
  Menu,
  ChevronDown
} from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import BoardHeader from "../components/board/BoardHeader";
import NewTaskModal from "../components/board/NewTaskModal";
import FilterPanel from "../components/board/FilterPanel";
import PersonFilter from "../components/board/PersonFilter";
import NewColumnModal from "../components/board/NewColumnModal";
import KanbanView from "../components/board/views/KanbanView";
import CalendarView from "../components/board/views/CalendarView";
import WrikeTableView from "../components/board/views/WrikeTableView";

import AnalyticsPanel from "../components/board/analytics/AnalyticsPanel";
import IntegrationsPanel from "../components/board/integrations/IntegrationsPanel";
import AutomationsPanel from "../components/board/automations/AutomationsPanel";

const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export default function BoardPage() {
  const [searchParams] = useSearchParams();
  const boardId = searchParams.get('id');
  
  const [board, setBoard] = useState(null);
  const [items, setItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedItems, setSelectedItems] = useState(new Set());
  const [currentView, setCurrentView] = useState('table');
  
  const [showNewTaskModal, setShowNewTaskModal] = useState(false);
  const [showFilterPanel, setShowFilterPanel] = useState(false);
  const [showPersonFilter, setShowPersonFilter] = useState(false);
  const [showNewColumnModal, setShowNewColumnModal] = useState(false);

  const [showAnalytics, setShowAnalytics] = useState(false);
  const [showIntegrations, setShowIntegrations] = useState(false);
  const [showAutomations, setShowAutomations] = useState(false);
  
  const [filters, setFilters] = useState({
    status: [],
    people: [],
    priority: []
  });

  useEffect(() => {
    if (boardId) {
      loadBoardAndItems();
    }
  }, [boardId]);

  const loadBoardAndItems = async () => {
    setIsLoading(true);
    try {
      const boardDataPromise = Board.filter({ id: boardId });
      const itemsDataPromise = Item.filter({ board_id: boardId }, "order_index");
      
      const [boardResponse, itemsData] = await Promise.all([boardDataPromise, itemsDataPromise]);
      
      if (boardResponse.length > 0) {
        setBoard(boardResponse[0]);
      } else {
        setBoard(null);
      }
      setItems(itemsData);
    } catch (error) {
      console.error("Error al cargar proyecto y tareas:", error);
      setBoard(null);
    }
    setIsLoading(false);
  };

  const handleAddItem = async (groupId, title) => {
    if (!boardId || !board) return;

    const maxOrder = Math.max(
      0,
      ...items.map(item => item.order_index || 0)
    );

    const newItemData = {};
    if (board.columns) {
      board.columns.forEach(column => {
        if (column.id === 'task') return;

        switch (column.type) {
          case 'text':
            newItemData[column.id] = "";
            break;
          case 'status':
            newItemData[column.id] = column.options?.choices?.[0]?.label || null;
            break;
          case 'date':
            newItemData[column.id] = null;
            break;
          case 'people':
            newItemData[column.id] = null;
            break;
          case 'number':
            newItemData[column.id] = null;
            break;
          case 'tags':
            newItemData[column.id] = [];
            break;
          case 'checkbox':
            newItemData[column.id] = false;
            break;
          case 'dropdown':
            newItemData[column.id] = column.options?.choices?.[0]?.value || null;
            break;
          case 'priority':
             newItemData[column.id] = column.options?.choices?.[0]?.value || null;
            break;
          default:
            newItemData[column.id] = null;
        }
      });
    }
    
    try {
      const newItem = await Item.create({
        board_id: boardId,
        group_id: groupId || 'default',
        title: title,
        order_index: maxOrder + 1,
        data: newItemData
      });
      setItems(prev => [...prev, newItem].sort((a, b) => (a.order_index || 0) - (b.order_index || 0)));
    } catch (error) {
      console.error("Error al añadir tarea:", error);
    }
  };

  const handleUpdateItem = async (itemId, updates) => {
    try {
      await Item.update(itemId, updates);
      setItems(prev => prev.map(item => 
        item.id === itemId ? { ...item, ...updates } : item
      ));
      if (showAnalytics || showIntegrations || showAutomations) {
        loadBoardAndItems();
      }
    } catch (error) {
      console.error("Error al actualizar tarea:", error);
    }
  };

  const handleDeleteItem = async (itemId) => {
    try {
      await Item.delete(itemId);
      setItems(prev => prev.filter(item => item.id !== itemId));
       if (showAnalytics || showIntegrations || showAutomations) {
        loadBoardAndItems();
      }
    } catch (error) {
      console.error("Error al eliminar tarea:", error);
    }
  };

  const handleAddColumn = async (columnData) => {
    if (!board) return;
    const newColumn = { ...columnData, id: generateId(), width: columnData.width || 150 };
    const updatedColumns = [...(board.columns || []), newColumn];

    try {
      await Board.update(board.id, { 
        columns: updatedColumns
      });
      setBoard(prev => ({ 
        ...prev, 
        columns: updatedColumns
      }));
      setShowNewColumnModal(false);
    } catch (error) {
      console.error("Error al añadir columna:", error);
    }
  };

  const handleUpdateColumn = async (columnId, updatedData) => {
    if (!board) return;
    const updatedColumns = board.columns.map(col => 
      col.id === columnId ? { ...col, ...updatedData } : col
    );
    try {
      await Board.update(board.id, { columns: updatedColumns });
      setBoard(prev => ({ ...prev, columns: updatedColumns }));
    } catch (error) {
      console.error("Error al actualizar columna:", error);
    }
  };

  const handleDeleteColumn = async (columnId) => {
    if (!board) return;
    const updatedColumns = board.columns.filter(col => col.id !== columnId);
    const updatedItems = items.map(item => {
      const newData = { ...item.data };
      delete newData[columnId];
      return { ...item, data: newData };
    });

    try {
      await Board.update(board.id, { columns: updatedColumns });
      setBoard(prev => ({ ...prev, columns: updatedColumns }));
      setItems(updatedItems);
    } catch (error) {
      console.error("Error al eliminar columna:", error);
    }
  };

  const handleViewChange = (newView) => {
    setCurrentView(newView);
  };

  const filteredItems = items.filter(item => {
    if (searchQuery && !item.title.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    if (filters.status.length > 0) {
      const statusColumn = board?.columns?.find(col => col.type === 'status');
      if (!filters.status.includes(item.data?.[statusColumn?.id])) {
        return false;
      }
    }
    if (filters.people.length > 0) {
      const peopleColumn = board?.columns?.find(col => col.type === 'people');
      if (!filters.people.includes(item.data?.[peopleColumn?.id])) {
        return false;
      }
    }
    if (filters.priority.length > 0) {
      const priorityColumn = board?.columns?.find(col => col.type === 'priority');
      if (!filters.priority.includes(item.data?.[priorityColumn?.id])) {
        return false;
      }
    }
    return true;
  });

  if (isLoading && !board) {
    return (
      <div className="p-4 sm:p-8 bg-[#F5F6F8] min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 sm:h-12 sm:w-12 border-b-2 border-[#0073EA] mx-auto mb-4"></div>
          <p className="text-base sm:text-lg text-[#323338]">Cargando proyecto...</p>
        </div>
      </div>
    );
  }
  
  if (!board) {
    return (
      <div className="p-4 sm:p-8 bg-[#F5F6F8] min-h-screen">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-12 sm:py-16">
            <h2 className="text-xl sm:text-2xl font-bold text-[#323338] mb-4">Proyecto no encontrado</h2>
            <Link to={createPageUrl("Boards")}>
              <Button className="bg-[#0073EA] hover:bg-[#0056B3] text-white rounded-xl h-10">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Volver a Proyectos
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Contar filtros activos
  const activeFiltersCount = (filters.status?.length || 0) + (filters.people?.length || 0) + (filters.priority?.length || 0);

  const getViewIcon = (view) => {
    switch(view) {
      case 'table': return <Table2 className="w-4 h-4" />;
      case 'kanban': return <Columns className="w-4 h-4" />;
      case 'calendar': return <CalendarIcon className="w-4 h-4" />;
      default: return <Table2 className="w-4 h-4" />;
    }
  };

  const getViewLabel = (view) => {
    switch(view) {
      case 'table': return 'Tabla';
      case 'kanban': return 'Tablero';
      case 'calendar': return 'Calendario';
      default: return 'Tabla';
    }
  };

  return (
    <div className="bg-[#F5F6F8] min-h-screen">
      <div className="max-w-full">
        {/* Header Mobile-Optimized */}
        <div className="bg-white border-b border-[#E1E5F3] sticky top-0 z-20">
          <div className="px-3 sm:px-4 md:px-6 py-2 sm:py-3">
            {/* Primera fila: Breadcrumb y título */}
            <div className="flex items-center gap-2 sm:gap-3 mb-2 sm:mb-3">
              <Link to={createPageUrl("Boards")}>
                <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0">
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </Link>
              <div className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm text-gray-500 min-w-0 overflow-hidden">
                <span className="hidden sm:inline">Proyectos</span>
                <span className="hidden sm:inline">/</span>
                <span className="text-gray-900 font-medium truncate">{board?.title}</span>
              </div>
            </div>

            {/* Segunda fila: Vistas y acciones - Desktop */}
            <div className="hidden lg:flex items-center justify-between gap-4">
              {/* Tabs de vistas */}
              <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-lg">
                <Button
                  variant={currentView === 'table' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => handleViewChange('table')}
                  className={`h-8 px-3 text-sm transition-all ${
                    currentView === 'table' 
                      ? 'bg-white shadow-sm text-gray-900' 
                      : 'hover:bg-gray-200 text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Table2 className="w-4 h-4 mr-1.5" />
                  Tabla
                </Button>
                <Button
                  variant={currentView === 'kanban' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => handleViewChange('kanban')}
                  className={`h-8 px-3 text-sm transition-all ${
                    currentView === 'kanban' 
                      ? 'bg-white shadow-sm text-gray-900' 
                      : 'hover:bg-gray-200 text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Columns className="w-4 h-4 mr-1.5" />
                  Tablero
                </Button>
                <Button
                  variant={currentView === 'calendar' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => handleViewChange('calendar')}
                  className={`h-8 px-3 text-sm transition-all ${
                    currentView === 'calendar' 
                      ? 'bg-white shadow-sm text-gray-900' 
                      : 'hover:bg-gray-200 text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <CalendarIcon className="w-4 h-4 mr-1.5" />
                  Calendario
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 px-3 text-sm hover:bg-gray-200 text-gray-600 hover:text-gray-900 transition-all"
                  onClick={() => setShowAnalytics(true)}
                >
                  <BarChart3 className="w-4 h-4 mr-1.5" />
                  Analítica
                </Button>
              </div>

              {/* Botones de acción - Desktop */}
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8"
                  onClick={() => setShowPersonFilter(!showPersonFilter)}
                >
                  <Users className="w-4 h-4 mr-1.5" />
                  Persona
                  {filters.people.length > 0 && (
                    <Badge className="ml-1.5 bg-blue-500 text-white rounded-full w-4 h-4 text-xs p-0 flex items-center justify-center">
                      {filters.people.length}
                    </Badge>
                  )}
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  className="h-8"
                  onClick={() => setShowFilterPanel(!showFilterPanel)}
                >
                  <Filter className="w-4 h-4 mr-1.5" />
                  Filtro
                  {activeFiltersCount > 0 && (
                    <Badge className="ml-1.5 bg-blue-500 text-white rounded-full w-4 h-4 text-xs p-0 flex items-center justify-center">
                      {activeFiltersCount}
                    </Badge>
                  )}
                </Button>

                <Button
                  size="sm"
                  className="h-8 bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={() => setShowNewTaskModal(true)}
                >
                  <Plus className="w-4 h-4 mr-1.5" />
                  Nueva tarea
                </Button>
              </div>
            </div>

            {/* Segunda fila: Vistas y acciones - Mobile/Tablet */}
            <div className="lg:hidden flex items-center justify-between gap-2">
              {/* Selector de Vista - Mobile Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-9 px-3 flex-1 max-w-[140px] sm:max-w-[160px]"
                  >
                    {getViewIcon(currentView)}
                    <span className="ml-2 truncate">{getViewLabel(currentView)}</span>
                    <ChevronDown className="w-3 h-3 ml-1 flex-shrink-0" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-40">
                  <DropdownMenuItem onClick={() => handleViewChange('table')}>
                    <Table2 className="w-4 h-4 mr-2" />
                    Tabla
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleViewChange('kanban')}>
                    <Columns className="w-4 h-4 mr-2" />
                    Tablero
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleViewChange('calendar')}>
                    <CalendarIcon className="w-4 h-4 mr-2" />
                    Calendario
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setShowAnalytics(true)}>
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Analítica
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Botones de acción - Mobile */}
              <div className="flex items-center gap-1.5 sm:gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 w-9 p-0 relative"
                  onClick={() => setShowPersonFilter(!showPersonFilter)}
                >
                  <Users className="w-4 h-4" />
                  {filters.people.length > 0 && (
                    <Badge className="absolute -top-1 -right-1 bg-blue-500 text-white rounded-full w-4 h-4 text-[10px] p-0 flex items-center justify-center">
                      {filters.people.length}
                    </Badge>
                  )}
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 w-9 p-0 relative"
                  onClick={() => setShowFilterPanel(!showFilterPanel)}
                >
                  <Filter className="w-4 h-4" />
                  {activeFiltersCount > 0 && (
                    <Badge className="absolute -top-1 -right-1 bg-blue-500 text-white rounded-full w-4 h-4 text-[10px] p-0 flex items-center justify-center">
                      {activeFiltersCount}
                    </Badge>
                  )}
                </Button>

                <Button
                  size="sm"
                  className="h-9 px-3 sm:px-4 bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={() => setShowNewTaskModal(true)}
                >
                  <Plus className="w-4 h-4 sm:mr-1.5" />
                  <span className="hidden sm:inline">Tarea</span>
                </Button>
              </div>
            </div>

            {/* Tercera fila: Filtros activos (solo cuando hay filtros) */}
            {(searchQuery || activeFiltersCount > 0) && (
              <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 mt-2 sm:mt-3 pt-2 sm:pt-3 border-t overflow-x-auto pb-1">
                {searchQuery && (
                  <Badge variant="secondary" className="gap-1.5 text-xs whitespace-nowrap">
                    Búsqueda: {searchQuery}
                    <X className="w-3 h-3 cursor-pointer flex-shrink-0" onClick={() => setSearchQuery("")} />
                  </Badge>
                )}
                {filters.status.map(status => (
                  <Badge key={status} variant="secondary" className="gap-1.5 text-xs whitespace-nowrap">
                    Estado: {status}
                    <X 
                      className="w-3 h-3 cursor-pointer flex-shrink-0" 
                      onClick={() => setFilters(prev => ({ 
                        ...prev, 
                        status: prev.status.filter(s => s !== status) 
                      }))} 
                    />
                  </Badge>
                ))}
                {filters.people.map(person => (
                  <Badge key={person} variant="secondary" className="gap-1.5 text-xs whitespace-nowrap">
                    Persona: {person}
                    <X 
                      className="w-3 h-3 cursor-pointer flex-shrink-0" 
                      onClick={() => setFilters(prev => ({ 
                        ...prev, 
                        people: prev.people.filter(p => p !== person) 
                      }))} 
                    />
                  </Badge>
                ))}
                {filters.priority.map(priority => (
                  <Badge key={priority} variant="secondary" className="gap-1.5 text-xs whitespace-nowrap">
                    Prioridad: {priority}
                    <X 
                      className="w-3 h-3 cursor-pointer flex-shrink-0" 
                      onClick={() => setFilters(prev => ({ 
                        ...prev, 
                        priority: prev.priority.filter(p => p !== priority) 
                      }))} 
                    />
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Contenido principal - Responsive Padding */}
        <div className="p-2 sm:p-4 md:p-6">
          {currentView === 'table' && (
            <WrikeTableView
              board={board}
              items={filteredItems}
              onAddItem={handleAddItem}
              onUpdateItem={handleUpdateItem}
              onDeleteItem={handleDeleteItem}
              onAddColumn={() => setShowNewColumnModal(true)}
              onUpdateColumn={handleUpdateColumn}
              onDeleteColumn={handleDeleteColumn}
              isLoading={isLoading}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
            />
          )}

          {currentView === 'kanban' && (
            <KanbanView
              board={board}
              items={filteredItems}
              onAddItem={handleAddItem}
              onUpdateItem={handleUpdateItem}
              onDeleteItem={handleDeleteItem}
            />
          )}

          {currentView === 'calendar' && (
            <CalendarView
              board={board}
              items={filteredItems}
              onAddItem={handleAddItem}
              onUpdateItem={handleUpdateItem}
              onDeleteItem={handleDeleteItem}
            />
          )}
        </div>

        {/* Modales */}
        <NewTaskModal
          isOpen={showNewTaskModal}
          onClose={() => setShowNewTaskModal(false)}
          board={board}
          onSubmit={handleAddItem}
        />
        <NewColumnModal
          isOpen={showNewColumnModal}
          onClose={() => setShowNewColumnModal(false)}
          onSubmit={handleAddColumn}
        />

        {/* Paneles laterales - Full Screen en Mobile */}
        {showFilterPanel && (
          <div className="fixed inset-0 z-50 bg-black/20" onClick={() => setShowFilterPanel(false)}>
            <div className="absolute right-0 top-0 h-full w-full sm:w-auto" onClick={(e) => e.stopPropagation()}>
              <FilterPanel
                filters={filters}
                onChange={setFilters}
                onClose={() => setShowFilterPanel(false)}
                board={board}
              />
            </div>
          </div>
        )}

        {showPersonFilter && (
          <div className="fixed inset-0 z-50 bg-black/20" onClick={() => setShowPersonFilter(false)}>
            <div className="absolute right-0 top-0 h-full w-full sm:w-auto" onClick={(e) => e.stopPropagation()}>
              <PersonFilter
                items={items}
                selectedPeople={filters.people}
                onChange={(people) => setFilters(prev => ({ ...prev, people }))}
                onClose={() => setShowPersonFilter(false)}
              />
            </div>
          </div>
        )}

        {showAnalytics && (
          <AnalyticsPanel 
            board={board} 
            items={items}
            onClose={() => setShowAnalytics(false)} 
          />
        )}

        {showIntegrations && (
          <IntegrationsPanel board={board} onClose={() => setShowIntegrations(false)} />
        )}

        {showAutomations && (
          <AutomationsPanel 
            board={board} 
            onClose={() => setShowAutomations(false)} 
          />
        )}
      </div>
    </div>
  );
}
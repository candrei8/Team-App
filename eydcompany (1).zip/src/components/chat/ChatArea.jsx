import React, { useState, useEffect, useRef } from 'react';
import { base44 } from "@/api/base44Client";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  Smile, 
  Paperclip, 
  SendHorizontal, 
  MoreHorizontal, 
  MessageSquare, 
  CornerUpLeft,
  Pencil,
  Trash2,
  Loader2,
  Plus
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import ReactMarkdown from 'react-markdown';
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

// Message Item Component
const MessageItem = ({ message, isOwn, showHeader, onReply, onReact, onDelete, currentUser }) => {
  return (
    <div 
      className={cn(
        "group flex gap-3 px-4 py-1 hover:bg-gray-50 transition-colors w-full",
        showHeader ? "mt-4" : "mt-0.5",
        message.isPending && "opacity-70"
      )}
    >
      {/* Avatar Column */}
      <div className="w-10 flex-shrink-0">
        {showHeader ? (
          <Avatar className="w-10 h-10 rounded-md">
            <AvatarImage src={message.user_avatar} />
            <AvatarFallback className="rounded-md bg-[#0073EA] text-white font-bold">
              {message.user_name?.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        ) : (
          <div className="w-10 text-[10px] text-gray-400 text-right opacity-0 group-hover:opacity-100 pt-1 select-none">
            {format(new Date(message.created_date), 'HH:mm')}
          </div>
        )}
      </div>

      {/* Content Column */}
      <div className="flex-1 min-w-0">
        {showHeader && (
          <div className="flex items-baseline gap-2 mb-0.5">
            <span className="font-bold text-gray-900">
              {message.user_name}
            </span>
            <span className="text-xs text-gray-500">
              {format(new Date(message.created_date), "h:mm aa", { locale: es })}
            </span>
          </div>
        )}

        <div className="text-gray-800 leading-relaxed break-words prose prose-sm max-w-none">
            <ReactMarkdown>{message.content}</ReactMarkdown>
        </div>

        {/* Attachments */}
        {message.attachments && message.attachments.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
                {message.attachments.map((file, i) => (
                    <a 
                        key={i} 
                        href={file.url} 
                        target="_blank" 
                        rel="noreferrer"
                        className="flex items-center gap-2 bg-gray-100 border border-gray-200 rounded p-2 text-sm hover:bg-gray-200 transition-colors"
                    >
                        <Paperclip className="w-3 h-3 text-gray-500" />
                        <span className="truncate max-w-[150px]">{file.name}</span>
                    </a>
                ))}
            </div>
        )}

        {/* Reactions */}
        {message.reactions && Object.keys(message.reactions).length > 0 && (
          <div className="flex flex-wrap gap-1 mt-1.5">
            {Object.entries(message.reactions).map(([emoji, users]) => (
              <button
                key={emoji}
                onClick={() => onReact(message.id, emoji)}
                className={cn(
                  "flex items-center gap-1 px-1.5 py-0.5 rounded bg-gray-100 hover:bg-gray-200 border border-transparent text-xs",
                  users.includes(currentUser.email) && "bg-blue-50 border-blue-200 text-blue-600"
                )}
              >
                <span>{emoji}</span>
                <span className="font-semibold">{users.length}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Hover Actions (Floating Menu) */}
      <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute right-4 -mt-4 bg-white shadow-sm border border-gray-200 rounded-md flex items-center overflow-hidden">
        <button onClick={() => onReact(message.id, '👍')} className="p-1.5 hover:bg-gray-100 text-gray-500" title="Me gusta">👍</button>
        <button onClick={() => onReact(message.id, '❤️')} className="p-1.5 hover:bg-gray-100 text-gray-500" title="Me encanta">❤️</button>
        <button onClick={() => onReact(message.id, '😂')} className="p-1.5 hover:bg-gray-100 text-gray-500" title="Me divierte">😂</button>
        <div className="w-[1px] h-4 bg-gray-200 mx-1" />
        <button onClick={() => onReply(message)} className="p-1.5 hover:bg-gray-100 text-gray-600" title="Responder en hilo">
          <MessageSquare className="w-4 h-4" />
        </button>
        {isOwn && (
            <>
                <button onClick={() => onDelete(message.id)} className="p-1.5 hover:bg-red-50 text-red-500" title="Eliminar">
                    <Trash2 className="w-4 h-4" />
                </button>
            </>
        )}
      </div>
    </div>
  );
};

export default function ChatArea({ 
  channel, 
  messages, 
  currentUser, 
  onSendMessage, 
  onReply, 
  onReact,
  onDeleteMessage,
  loading 
}) {
  const [inputText, setInputText] = useState("");
  const [isSending, setIsSending] = useState(false);
  const scrollRef = useRef(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, channel?.id]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    setIsSending(true);
    try {
      await onSendMessage(inputText);
      setInputText("");
    } finally {
      setIsSending(false);
    }
  };

  // Group messages logic
  const groupedMessages = messages.reduce((acc, message, index) => {
    const prevMessage = messages[index - 1];
    const isSameUser = prevMessage && prevMessage.user_email === message.user_email;
    const isTimeClose = prevMessage && (new Date(message.created_date) - new Date(prevMessage.created_date) < 5 * 60 * 1000); // 5 min

    const showHeader = !isSameUser || !isTimeClose;

    acc.push({ ...message, showHeader });
    return acc;
  }, []);

  if (!channel) {
    return (
      <div className="h-full flex items-center justify-center text-gray-400 flex-col gap-4">
        <MessageSquare className="w-16 h-16 opacity-20" />
        <p>Selecciona un canal para comenzar a chatear</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="h-14 border-b border-gray-200 flex items-center px-4 justify-between bg-white flex-shrink-0">
        <div className="flex items-center gap-2 font-bold text-gray-800">
          {channel.type === 'general' && <span className="text-2xl text-gray-400">#</span>}
          {channel.type === 'private' && <span className="text-xl text-gray-400">🔒</span>}
          <span>{channel.name}</span>
        </div>
        <div className="text-xs text-gray-500">
            {/* Channel topic or member count could go here */}
        </div>
      </div>

      {/* Messages List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4" ref={scrollRef}>
        {loading ? (
            <div className="flex justify-center py-10">
                <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
            </div>
        ) : (
            <div className="flex flex-col pb-4">
                {groupedMessages.map((msg) => (
                    <MessageItem
                        key={msg.id}
                        message={msg}
                        isOwn={msg.user_email === currentUser.email}
                        showHeader={msg.showHeader}
                        onReply={onReply}
                        onReact={onReact}
                        onDelete={onDeleteMessage}
                        currentUser={currentUser}
                    />
                ))}
                <div ref={scrollRef} />
            </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-4 pt-2 bg-white">
        <div className="border border-gray-300 rounded-lg shadow-sm bg-white focus-within:ring-1 focus-within:ring-blue-500 focus-within:border-blue-500 transition-all">
            <form onSubmit={handleSend} className="flex flex-col">
                <Input 
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder={`Enviar mensaje a #${channel.name}`}
                    className="border-0 focus-visible:ring-0 bg-transparent px-4 py-3 min-h-[44px]"
                    autoFocus
                />
                <div className="flex items-center justify-between px-2 pb-2 pt-1">
                    <div className="flex items-center gap-1">
                        <Button type="button" variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:bg-gray-100 rounded">
                            <Plus className="w-5 h-5" />
                        </Button>
                        <Button type="button" variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:bg-gray-100 rounded">
                            <Smile className="w-5 h-5" />
                        </Button>
                        <Button type="button" variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:bg-gray-100 rounded">
                            <Paperclip className="w-4 h-4" />
                        </Button>
                    </div>
                    <div className="flex items-center gap-2">
                        <span className={cn("text-xs text-gray-400 transition-opacity", inputText.length > 0 ? "opacity-100" : "opacity-0")}>
                            Enter para enviar
                        </span>
                        <Button 
                            type="submit" 
                            size="icon" 
                            disabled={!inputText.trim() || isSending}
                            className={cn(
                                "h-8 w-8 rounded transition-all",
                                inputText.trim() ? "bg-[#0073EA] hover:bg-[#0060C0]" : "bg-gray-200 text-gray-400"
                            )}
                        >
                            {isSending ? <Loader2 className="w-4 h-4 animate-spin" /> : <SendHorizontal className="w-4 h-4" />}
                        </Button>
                    </div>
                </div>
            </form>
        </div>
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, Filter, Trash2, ChevronDown, ChevronUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function FilterPanel({ filters, onChange, onClose, board }) {
  const [expandedSections, setExpandedSections] = useState({
    status: true,
    priority: true,
    people: true
  });

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  // Status options
  const statusColumn = board?.columns?.find(col => col.type === 'status');
  const statusChoices = statusColumn?.options?.choices || [
    { label: 'Sin Iniciar', color: '#C4C4C4' },
    { label: 'Trabajando en ello', color: '#FFCB00' },
    { label: 'Hecho', color: '#00C875' },
    { label: 'Bloqueado', color: '#E2445C' }
  ];

  // Priority options
  const priorityColumn = board?.columns?.find(col => col.type === 'priority');
  const priorityChoices = priorityColumn?.options?.choices || [
    { label: 'Bajo', value: 'low', color: '#00C875' },
    { label: 'Medio', value: 'medium', color: '#FFCB00' },
    { label: 'Alto', value: 'high', color: '#FF6900' },
    { label: 'Crítico', value: 'critical', color: '#E2445C' }
  ];

  const handleStatusChange = (status, checked) => {
    const newStatuses = checked 
      ? [...filters.status, status]
      : filters.status.filter(s => s !== status);
    onChange({ ...filters, status: newStatuses });
  };

  const handlePriorityChange = (priority, checked) => {
    const newPriorities = checked
      ? [...filters.priority, priority]
      : filters.priority.filter(p => p !== priority);
    onChange({ ...filters, priority: newPriorities });
  };

  const clearAllFilters = () => {
    onChange({ status: [], people: [], priority: [] });
  };

  const totalFilters = (filters.status?.length || 0) + (filters.priority?.length || 0) + (filters.people?.length || 0);

  return (
    <motion.div
      initial={{ x: 400, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 400, opacity: 0 }}
      transition={{ type: "spring", damping: 25, stiffness: 300 }}
      className="w-[380px] h-full bg-white shadow-2xl border-l border-gray-200"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <Filter className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">Filtros</h3>
            {totalFilters > 0 && (
              <p className="text-xs text-gray-600">{totalFilters} filtro{totalFilters !== 1 ? 's' : ''} activo{totalFilters !== 1 ? 's' : ''}</p>
            )}
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="h-8 w-8 hover:bg-gray-200"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>

      {/* Content */}
      <div className="overflow-y-auto h-[calc(100%-140px)]">
        <div className="p-4 space-y-4">
          {/* Status Filter */}
          <Card className="border shadow-sm">
            <CardHeader 
              className="pb-3 cursor-pointer hover:bg-gray-50 transition-colors"
              onClick={() => toggleSection('status')}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CardTitle className="text-base font-semibold text-gray-900">Estado</CardTitle>
                  {filters.status?.length > 0 && (
                    <Badge className="bg-blue-600 text-white text-xs">
                      {filters.status.length}
                    </Badge>
                  )}
                </div>
                {expandedSections.status ? (
                  <ChevronUp className="w-4 h-4 text-gray-500" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-gray-500" />
                )}
              </div>
            </CardHeader>
            <AnimatePresence>
              {expandedSections.status && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <CardContent className="space-y-3 pt-0">
                    {statusChoices.map((choice) => (
                      <div key={choice.label} className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg transition-colors">
                        <Checkbox
                          id={`status-${choice.label}`}
                          checked={filters.status?.includes(choice.label)}
                          onCheckedChange={(checked) => handleStatusChange(choice.label, checked)}
                        />
                        <label 
                          htmlFor={`status-${choice.label}`}
                          className="flex items-center gap-2 text-sm cursor-pointer flex-1"
                        >
                          <div 
                            className="w-3 h-3 rounded-full shadow-sm"
                            style={{ backgroundColor: choice.color }}
                          />
                          <span className="font-medium text-gray-700">{choice.label}</span>
                        </label>
                      </div>
                    ))}
                  </CardContent>
                </motion.div>
              )}
            </AnimatePresence>
          </Card>

          {/* Priority Filter */}
          <Card className="border shadow-sm">
            <CardHeader 
              className="pb-3 cursor-pointer hover:bg-gray-50 transition-colors"
              onClick={() => toggleSection('priority')}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CardTitle className="text-base font-semibold text-gray-900">Prioridad</CardTitle>
                  {filters.priority?.length > 0 && (
                    <Badge className="bg-blue-600 text-white text-xs">
                      {filters.priority.length}
                    </Badge>
                  )}
                </div>
                {expandedSections.priority ? (
                  <ChevronUp className="w-4 h-4 text-gray-500" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-gray-500" />
                )}
              </div>
            </CardHeader>
            <AnimatePresence>
              {expandedSections.priority && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <CardContent className="space-y-3 pt-0">
                    {priorityChoices.map((priority) => (
                      <div key={priority.label} className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg transition-colors">
                        <Checkbox
                          id={`priority-${priority.label}`}
                          checked={filters.priority?.includes(priority.label)}
                          onCheckedChange={(checked) => handlePriorityChange(priority.label, checked)}
                        />
                        <label 
                          htmlFor={`priority-${priority.label}`}
                          className="flex items-center gap-2 text-sm cursor-pointer flex-1"
                        >
                          <div 
                            className="w-3 h-3 rounded-full shadow-sm"
                            style={{ backgroundColor: priority.color }}
                          />
                          <span className="font-medium text-gray-700">{priority.label}</span>
                        </label>
                      </div>
                    ))}
                  </CardContent>
                </motion.div>
              )}
            </AnimatePresence>
          </Card>

          {/* Active Filters Summary */}
          {totalFilters > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-blue-50 border border-blue-200 rounded-lg p-4"
            >
              <div className="flex items-start justify-between mb-3">
                <h4 className="text-sm font-semibold text-blue-900">Filtros Activos</h4>
                <Badge variant="secondary" className="bg-blue-600 text-white">
                  {totalFilters}
                </Badge>
              </div>
              <div className="space-y-2">
                {filters.status?.map((status) => (
                  <div key={status} className="flex items-center justify-between bg-white rounded px-2 py-1.5">
                    <span className="text-xs font-medium text-gray-700">{status}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-5 w-5"
                      onClick={() => handleStatusChange(status, false)}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
                {filters.priority?.map((priority) => (
                  <div key={priority} className="flex items-center justify-between bg-white rounded px-2 py-1.5">
                    <span className="text-xs font-medium text-gray-700">{priority}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-5 w-5"
                      onClick={() => handlePriorityChange(priority, false)}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-0 left-0 right-0 p-4 border-t bg-gray-50">
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={clearAllFilters}
            disabled={totalFilters === 0}
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Limpiar Todo
          </Button>
          <Button
            className="flex-1 bg-blue-600 hover:bg-blue-700"
            onClick={onClose}
          >
            Aplicar Filtros
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
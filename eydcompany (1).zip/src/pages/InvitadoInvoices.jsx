import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, FileText, Download, Loader2, DollarSign } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function InvitadoInvoices() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openModal, setOpenModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [user, setUser] = useState(null);
  
  const [newInvoice, setNewInvoice] = useState({
    invoice_number: "",
    amount: "",
    date: new Date().toISOString().split('T')[0],
    file: null
  });

  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      const data = await base44.entities.GuestInvoice.filter({ user_email: userData.email });
      setInvoices(data);
    } catch (error) {
      console.error("Error loading invoices:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
       // Simulate upload for now or use UploadFile integration if available
       // For now we just keep the file object to mock the process
       setNewInvoice({...newInvoice, file});
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      // Here we would upload the file first
      let pdf_url = "#";
      if (newInvoice.file) {
         const uploadRes = await base44.integrations.Core.UploadFile({ file: newInvoice.file });
         pdf_url = uploadRes.file_url;
      }

      await base44.entities.GuestInvoice.create({
        user_email: user.email,
        invoice_number: newInvoice.invoice_number,
        amount: parseFloat(newInvoice.amount),
        date: newInvoice.date,
        status: "pending",
        pdf_url: pdf_url
      });
      
      toast({ title: "Factura subida", description: "Tu factura ha sido registrada y está pendiente de pago.", className: "bg-green-50 border-green-200 text-green-800" });
      setOpenModal(false);
      setNewInvoice({ invoice_number: "", amount: "", date: new Date().toISOString().split('T')[0], file: null });
      loadData();
    } catch (error) {
      console.error("Error creating invoice:", error);
      toast({ title: "Error", description: "No se pudo registrar la factura.", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusBadge = (status) => {
    switch(status) {
      case 'paid': return <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-0">Pagado</Badge>;
      case 'rejected': return <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-0">Rechazado</Badge>;
      default: return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-0">Pendiente</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Mis Facturas</h1>
          <p className="text-gray-500 text-sm">Historial de facturación y pagos</p>
        </div>
        
        <Dialog open={openModal} onOpenChange={setOpenModal}>
          <DialogTrigger asChild>
            <Button className="bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm">
              <Plus className="w-4 h-4 mr-2" /> Subir Factura
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Registrar Nueva Factura</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Número de Factura</Label>
                  <Input 
                    required 
                    placeholder="Ej. INV-2024-001" 
                    value={newInvoice.invoice_number}
                    onChange={(e) => setNewInvoice({...newInvoice, invoice_number: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Fecha Emisión</Label>
                  <Input 
                    type="date"
                    required 
                    value={newInvoice.date}
                    onChange={(e) => setNewInvoice({...newInvoice, date: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Importe Total (€)</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                  <Input 
                    type="number"
                    step="0.01"
                    required 
                    className="pl-9"
                    placeholder="0.00" 
                    value={newInvoice.amount}
                    onChange={(e) => setNewInvoice({...newInvoice, amount: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Adjuntar PDF</Label>
                <Input 
                  type="file" 
                  accept=".pdf" 
                  required
                  onChange={handleFileChange}
                />
                <p className="text-xs text-gray-500">Sube tu factura en formato PDF.</p>
              </div>
              
              <div className="flex justify-end pt-4">
                <Button type="submit" disabled={submitting} className="bg-indigo-600 text-white">
                  {submitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin"/> Subiendo...</> : "Registrar Factura"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-white border-gray-200 shadow-sm">
          <CardContent className="p-4">
             <p className="text-xs text-gray-500 font-medium uppercase mb-1">Pendiente de Cobro</p>
             <p className="text-2xl font-bold text-amber-600">
               {invoices.filter(i => i.status === 'pending').reduce((acc, curr) => acc + (curr.amount || 0), 0).toFixed(2)}€
             </p>
          </CardContent>
        </Card>
        <Card className="bg-white border-gray-200 shadow-sm">
          <CardContent className="p-4">
             <p className="text-xs text-gray-500 font-medium uppercase mb-1">Cobrado este año</p>
             <p className="text-2xl font-bold text-green-600">
               {invoices.filter(i => i.status === 'paid').reduce((acc, curr) => acc + (curr.amount || 0), 0).toFixed(2)}€
             </p>
          </CardContent>
        </Card>
        <Card className="bg-white border-gray-200 shadow-sm">
          <CardContent className="p-4">
             <p className="text-xs text-gray-500 font-medium uppercase mb-1">Total Facturas</p>
             <p className="text-2xl font-bold text-gray-900">{invoices.length}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-white border-gray-200 shadow-sm">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50 border-b-gray-200 hover:bg-gray-50">
                <TableHead className="font-semibold text-gray-700">Nº Factura</TableHead>
                <TableHead className="font-semibold text-gray-700">Fecha</TableHead>
                <TableHead className="font-semibold text-gray-700">Importe</TableHead>
                <TableHead className="font-semibold text-gray-700">Documento</TableHead>
                <TableHead className="font-semibold text-gray-700 text-right">Estado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8">Cargando facturas...</TableCell>
                </TableRow>
              ) : invoices.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-12 text-gray-500">
                    No hay facturas registradas.
                  </TableCell>
                </TableRow>
              ) : (
                invoices.map((item) => (
                  <TableRow key={item.id} className="border-b-gray-100">
                    <TableCell className="font-medium text-gray-900">{item.invoice_number}</TableCell>
                    <TableCell className="text-gray-500 text-sm">
                      {new Date(item.date).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="font-mono font-medium text-gray-900">
                      {item.amount?.toFixed(2)}€
                    </TableCell>
                    <TableCell>
                      <a href={item.pdf_url} target="_blank" rel="noopener noreferrer">
                        <Button variant="ghost" size="sm" className="h-8 text-gray-600">
                          <FileText className="w-3 h-3 mr-2" /> PDF
                        </Button>
                      </a>
                    </TableCell>
                    <TableCell className="text-right">
                      {getStatusBadge(item.status)}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Globe, Lock, Users, Building2, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export default function CreateBoardModal({ isOpen, onClose, onSubmit }) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    color: "#0073EA",
    visibility: "shared",
    participants: [],
    allowed_departments: []
  });
  const [users, setUsers] = useState([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [openUserPicker, setOpenUserPicker] = useState(false);

  const departments = [
    "IA", "Marketing", "Relaciones Internacionales", "Dirección",
    "Diseñador", "Operaciones", "Finanzas", "Recursos Humanos",
    "Tecnología", "Ventas", "Otro"
  ];

  useEffect(() => {
    if (isOpen && formData.visibility === "private") {
      loadUsers();
    }
  }, [isOpen, formData.visibility]);

  const loadUsers = async () => {
    setIsLoadingUsers(true);
    try {
      const allUsers = await base44.entities.User.filter({ status: 'active' });
      setUsers(allUsers);
    } catch (error) {
      console.error("Error al cargar usuarios:", error);
    }
    setIsLoadingUsers(false);
  };

  const addParticipant = (userEmail) => {
    if (!formData.participants.includes(userEmail)) {
      setFormData(prev => ({
        ...prev,
        participants: [...prev.participants, userEmail]
      }));
    }
    setOpenUserPicker(false);
  };

  const removeParticipant = (userEmail) => {
    setFormData(prev => ({
      ...prev,
      participants: prev.participants.filter(email => email !== userEmail)
    }));
  };

  const toggleDepartment = (dept) => {
    setFormData(prev => ({
      ...prev,
      allowed_departments: prev.allowed_departments.includes(dept)
        ? prev.allowed_departments.filter(d => d !== dept)
        : [...prev.allowed_departments, dept]
    }));
  };

  const getUserInitials = (name) => {
    if (!name) return "?";
    const names = name.split(" ");
    if (names.length >= 2) {
      return `${names[0][0]}${names[1][0]}`.toUpperCase();
    }
    return names[0][0].toUpperCase();
  };

  const availableUsers = users.filter(user => 
    !formData.participants.includes(user.email)
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const boardData = {
      ...formData,
      view_type: "table",
      columns: [
        {
          id: 'task',
          title: 'Tarea',
          type: 'text',
          width: 250
        },
        {
          id: 'status',
          title: 'Estado',
          type: 'status',
          width: 150,
          options: {
            choices: [
              { label: 'Por hacer', color: '#C4C4C4' },
              { label: 'En desarrollo', color: '#FDAB3D' },
              { label: 'Hecho', color: '#00C875' },
              { label: 'Atascado', color: '#E2445C' }
            ]
          }
        },
        {
          id: 'priority',
          title: 'Prioridad',
          type: 'priority',
          width: 120,
          options: {
            choices: [
              { value: 'low', label: 'Baja', color: '#579BFC' },
              { value: 'medium', label: 'Media', color: '#FDAB3D' },
              { value: 'high', label: 'Alta', color: '#E2445C' },
              { value: 'critical', label: 'Crítica', color: '#7F5347' }
            ]
          }
        },
        {
          id: 'due_date',
          title: 'Fecha límite',
          type: 'date',
          width: 150
        },
        {
          id: 'budget',
          title: 'Presupuesto',
          type: 'budget',
          width: 150,
          options: {
            currency: 'USD'
          }
        },
        {
          id: 'timeline',
          title: 'Línea de tiempo',
          type: 'timeline',
          width: 200,
          options: {
            start_date_field: 'start_date',
            end_date_field: 'end_date'
          }
        },
        {
          id: 'Lider',
          title: 'Encargado',
          type: 'people',
          width: 150
        }
      ],
      groups: [
        {
          id: 'default',
          title: 'Tareas',
          color: '#0073EA',
          collapsed: false
        }
      ]
    };

    onSubmit(boardData);
    setFormData({
      title: "",
      description: "",
      color: "#0073EA",
      visibility: "shared",
      participants: [],
      allowed_departments: []
    });
  };

  const colorOptions = [
    { value: '#0073EA', label: 'Azul' },
    { value: '#00C875', label: 'Verde' },
    { value: '#FDAB3D', label: 'Naranja' },
    { value: '#E2445C', label: 'Rojo' },
    { value: '#784BD1', label: 'Púrpura' },
    { value: '#9CD326', label: 'Lima' }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Crear Nuevo Proyecto</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Nombre del Proyecto *</Label>
            <Input
              id="title"
              placeholder="ej. Plan de Marketing Q1"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
              className="bg-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descripción</Label>
            <Textarea
              id="description"
              placeholder="Describe el propósito de este proyecto..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="bg-white min-h-[80px]"
            />
          </div>

          <div className="space-y-2">
            <Label>Color del Proyecto</Label>
            <div className="flex gap-2">
              {colorOptions.map((color) => (
                <button
                  key={color.value}
                  type="button"
                  onClick={() => setFormData({ ...formData, color: color.value })}
                  className={`w-10 h-10 rounded-lg transition-all ${
                    formData.color === color.value
                      ? 'ring-2 ring-offset-2 ring-blue-500 scale-110'
                      : 'hover:scale-105'
                  }`}
                  style={{ backgroundColor: color.value }}
                  title={color.label}
                />
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Visibilidad</Label>
            <RadioGroup
              value={formData.visibility}
              onValueChange={(value) => setFormData({ ...formData, visibility: value })}
            >
              <div className="flex items-start space-x-3 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                <RadioGroupItem value="shared" id="shared" />
                <div className="flex-1">
                  <Label htmlFor="shared" className="flex items-center gap-2 cursor-pointer font-medium">
                    <Globe className="w-4 h-4 text-blue-600" />
                    Compartido
                  </Label>
                  <p className="text-sm text-gray-500 mt-1">
                    Visible para todos los usuarios del equipo
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                <RadioGroupItem value="private" id="private" />
                <div className="flex-1">
                  <Label htmlFor="private" className="flex items-center gap-2 cursor-pointer font-medium">
                    <Lock className="w-4 h-4 text-gray-600" />
                    Privado
                  </Label>
                  <p className="text-sm text-gray-500 mt-1">
                    Solo personas y departamentos seleccionados pueden verlo
                  </p>
                </div>
              </div>
            </RadioGroup>
          </div>

          {/* Configuración de permisos para proyectos privados */}
          {formData.visibility === "private" && (
            <div className="space-y-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
              <div>
                <Label className="text-sm font-medium flex items-center gap-2 mb-3">
                  <Users className="w-4 h-4" />
                  Usuarios con Acceso
                </Label>
                
                {formData.participants.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {formData.participants.map((email) => {
                      const user = users.find(u => u.email === email);
                      return (
                        <Badge key={email} variant="secondary" className="flex items-center gap-2 pr-1">
                          <div className="w-4 h-4 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-[10px] font-semibold">
                            {getUserInitials(user?.full_name || email)}
                          </div>
                          <span className="text-xs">{user?.full_name || email}</span>
                          <button
                            type="button"
                            onClick={() => removeParticipant(email)}
                            className="hover:bg-gray-300 rounded-full p-0.5"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      );
                    })}
                  </div>
                )}

                <Popover open={openUserPicker} onOpenChange={setOpenUserPicker}>
                  <PopoverTrigger asChild>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      className="w-full"
                      disabled={isLoadingUsers || availableUsers.length === 0}
                    >
                      <Users className="w-4 h-4 mr-2" />
                      {isLoadingUsers ? "Cargando..." : "Agregar Usuario"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[280px] p-0" align="start">
                    <Command>
                      <CommandInput placeholder="Buscar usuario..." />
                      <CommandEmpty>No se encontraron usuarios.</CommandEmpty>
                      <CommandGroup className="max-h-48 overflow-y-auto">
                        {availableUsers.map((user) => (
                          <CommandItem
                            key={user.id}
                            onSelect={() => addParticipant(user.email)}
                            className="flex items-center gap-2 cursor-pointer text-sm"
                          >
                            <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-xs font-semibold">
                              {getUserInitials(user.full_name)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium truncate">{user.full_name || 'Sin nombre'}</p>
                              <p className="text-xs text-gray-500 truncate">{user.email}</p>
                            </div>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>

              <div>
                <Label className="text-sm font-medium flex items-center gap-2 mb-3">
                  <Building2 className="w-4 h-4" />
                  Departamentos con Acceso
                </Label>
                <div className="grid grid-cols-2 gap-2">
                  {departments.map((dept) => (
                    <div key={dept} className="flex items-center space-x-2">
                      <Checkbox
                        id={`dept-${dept}`}
                        checked={formData.allowed_departments.includes(dept)}
                        onCheckedChange={() => toggleDepartment(dept)}
                      />
                      <Label
                        htmlFor={`dept-${dept}`}
                        className="text-xs font-normal cursor-pointer"
                      >
                        {dept}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <p className="text-xs text-gray-600 mt-2">
                Los usuarios seleccionados y aquellos en los departamentos marcados podrán ver este proyecto.
              </p>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="bg-[#0073EA] hover:bg-[#0056B3]"
              disabled={!formData.title.trim()}
            >
              Crear Proyecto
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
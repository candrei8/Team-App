import React, { useState, useEffect } from 'react';
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, SendHorizontal, Loader2 } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { format } from "date-fns";
import ReactMarkdown from 'react-markdown';

export default function ThreadView({ 
  parentMessage, 
  onClose, 
  currentUser 
}) {
  const [replies, setReplies] = useState([]);
  const [replyText, setReplyText] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (parentMessage) {
      loadReplies();
    }
  }, [parentMessage]);

  const loadReplies = async () => {
    // Polling handled by parent or use query here
    const msgs = await base44.entities.Message.list("-created_date"); // In real app filter by reply_to
    // Since standard list doesn't filter by reply_to easily in this prompt context (unless using .filter), 
    // we'll do client side filtering or rely on proper query if supported.
    // Assuming filter support:
    const threadMsgs = await base44.entities.Message.filter({ reply_to: parentMessage.id }, "created_date", 50);
    setReplies(threadMsgs);
  };

  const handleSendReply = async (e) => {
    e.preventDefault();
    if (!replyText.trim()) return;

    setSending(true);
    try {
      await base44.entities.Message.create({
        channel_id: parentMessage.channel_id,
        user_email: currentUser.email,
        user_name: currentUser.full_name,
        user_avatar: currentUser.avatar_url,
        content: replyText,
        reply_to: parentMessage.id,
        created_date: new Date().toISOString()
      });
      
      // Create or update thread metadata if we were strict, but for now just create message
      setReplyText("");
      loadReplies();
    } catch (error) {
      console.error("Error sending reply:", error);
    } finally {
      setSending(false);
    }
  };

  if (!parentMessage) return null;

  return (
    <div className="flex flex-col h-full border-l border-gray-200 bg-gray-50/50">
      {/* Header */}
      <div className="h-14 flex items-center justify-between px-4 border-b border-gray-200 bg-white">
        <h3 className="font-bold text-gray-800">Hilo</h3>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="w-5 h-5 text-gray-500" />
        </Button>
      </div>

      <ScrollArea className="flex-1 p-4">
        {/* Parent Message */}
        <div className="mb-6 pb-4 border-b border-gray-200">
          <div className="flex items-center gap-2 mb-1">
            <img src={parentMessage.user_avatar} className="w-6 h-6 rounded bg-gray-200" alt="" />
            <span className="font-bold text-sm">{parentMessage.user_name}</span>
            <span className="text-xs text-gray-500">{format(new Date(parentMessage.created_date), "HH:mm")}</span>
          </div>
          <div className="text-sm text-gray-700 pl-8">
            <ReactMarkdown>{parentMessage.content}</ReactMarkdown>
          </div>
        </div>

        {/* Replies */}
        <div className="space-y-4">
          {replies.map(reply => (
             <div key={reply.id} className="flex gap-3 group">
                <div className="w-8 flex-shrink-0 pt-1">
                    <img src={reply.user_avatar} className="w-6 h-6 rounded bg-gray-200" alt="" />
                </div>
                <div className="flex-1">
                    <div className="flex items-baseline gap-2">
                        <span className="font-bold text-sm text-gray-800">{reply.user_name}</span>
                        <span className="text-xs text-gray-500">{format(new Date(reply.created_date), "HH:mm")}</span>
                    </div>
                    <div className="text-sm text-gray-800">
                        <ReactMarkdown>{reply.content}</ReactMarkdown>
                    </div>
                </div>
             </div>
          ))}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="p-4 bg-white border-t border-gray-200">
        <form onSubmit={handleSendReply} className="relative">
            <Input
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Responder..."
                className="pr-10"
            />
            <Button 
                type="submit" 
                size="icon" 
                variant="ghost"
                disabled={!replyText.trim() || sending}
                className="absolute right-1 top-1 h-8 w-8 text-blue-600 hover:bg-blue-50"
            >
                {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <SendHorizontal className="w-4 h-4" />}
            </Button>
        </form>
      </div>
    </div>
  );
}
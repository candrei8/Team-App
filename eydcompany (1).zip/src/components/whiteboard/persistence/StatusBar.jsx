import React from 'react';
import { Check, Loader2, AlertCircle, XCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';

const STATUS_CONFIG = {
  saved: {
    icon: Check,
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    text: 'Guardado'
  },
  saving: {
    icon: Loader2,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    text: 'Guardando...',
    animate: true
  },
  unsaved: {
    icon: AlertCircle,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    text: 'Sin guardar'
  },
  error: {
    icon: XCircle,
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    text: 'Error al guardar'
  }
};

export default function StatusBar({ 
  status = 'saved',
  lastSaved,
  elementCount = 0,
  zoom = 1,
  cursorPosition,
  onRetry
}) {
  const config = STATUS_CONFIG[status];
  const Icon = config.icon;

  return (
    <div className="absolute bottom-0 left-0 right-0 h-8 bg-white/90 backdrop-blur-sm border-t border-gray-200 flex items-center justify-between px-4 text-xs z-50">
      {/* Estado de guardado */}
      <div className="flex items-center gap-4">
        <div className={`flex items-center gap-1.5 px-2 py-1 rounded ${config.bgColor}`}>
          <Icon 
            className={`w-3.5 h-3.5 ${config.color} ${config.animate ? 'animate-spin' : ''}`} 
          />
          <span className={`font-medium ${config.color}`}>
            {config.text}
          </span>
        </div>

        {lastSaved && status === 'saved' && (
          <span className="text-gray-500">
            Guardado {formatDistanceToNow(new Date(lastSaved), { 
              addSuffix: true, 
              locale: es 
            })}
          </span>
        )}

        {status === 'error' && onRetry && (
          <button
            onClick={onRetry}
            className="text-blue-600 hover:text-blue-700 font-medium underline"
          >
            Reintentar
          </button>
        )}
      </div>

      {/* Información del canvas */}
      <div className="flex items-center gap-4 text-gray-500">
        <span>{elementCount} elemento{elementCount !== 1 ? 's' : ''}</span>
        <span>Zoom: {Math.round(zoom * 100)}%</span>
        {cursorPosition && (
          <span className="hidden md:inline">
            X: {Math.round(cursorPosition.x)}, Y: {Math.round(cursorPosition.y)}
          </span>
        )}
      </div>
    </div>
  );
}
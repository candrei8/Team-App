import React from 'react';
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Save, 
  ChevronDown, 
  Copy, 
  Download,
  Check,
  Loader2,
  AlertCircle
} from 'lucide-react';

export default function SaveButton({
  status = 'saved', // 'saved' | 'saving' | 'unsaved' | 'error'
  hasChanges = false,
  onSave,
  onSaveAs,
  onExport
}) {
  const getButtonContent = () => {
    switch (status) {
      case 'saving':
        return {
          icon: Loader2,
          text: 'Guardando...',
          className: 'bg-blue-600 hover:bg-blue-700',
          iconClass: 'animate-spin'
        };
      case 'error':
        return {
          icon: AlertCircle,
          text: 'Error',
          className: 'bg-red-600 hover:bg-red-700',
          iconClass: ''
        };
      case 'unsaved':
        return {
          icon: Save,
          text: 'Guardar cambios',
          className: 'bg-[#0073EA] hover:bg-[#0056B3]',
          iconClass: ''
        };
      default: // 'saved'
        return {
          icon: Check,
          text: 'Guardado',
          className: 'bg-gray-400 hover:bg-gray-500',
          iconClass: ''
        };
    }
  };

  const { icon: Icon, text, className, iconClass } = getButtonContent();

  return (
    <div className="flex items-center gap-0.5">
      <Button
        onClick={onSave}
        disabled={status === 'saving' || (!hasChanges && status === 'saved')}
        className={`h-9 rounded-r-none ${className}`}
      >
        <Icon className={`w-4 h-4 mr-2 ${iconClass}`} />
        {text}
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            disabled={status === 'saving'}
            className={`h-9 w-8 px-0 rounded-l-none border-l border-white/20 ${className}`}
          >
            <ChevronDown className="w-4 h-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuItem onClick={onSave} disabled={!hasChanges}>
            <Save className="w-4 h-4 mr-2" />
            Guardar ahora
            {hasChanges && (
              <span className="ml-auto text-xs text-gray-500">Ctrl+S</span>
            )}
          </DropdownMenuItem>
          
          <DropdownMenuItem onClick={onSaveAs}>
            <Copy className="w-4 h-4 mr-2" />
            Guardar como...
          </DropdownMenuItem>
          
          <DropdownMenuSeparator />
          
          <DropdownMenuItem onClick={onExport}>
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
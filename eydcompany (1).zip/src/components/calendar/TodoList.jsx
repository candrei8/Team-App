import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { base44 } from "@/api/base44Client";
import { Plus, Calendar as CalendarIcon, Clock } from "lucide-react";
import { format, isToday, isPast } from "date-fns";
import { es } from "date-fns/locale";

export default function TodoList({ tasks, onTaskClick, onTaskUpdate, currentUser }) {
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [isAdding, setIsAdding] = useState(false);

  const handleAddTask = async (e) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    try {
      await base44.entities.TodoTask.create({
        title: newTaskTitle,
        status: "todo",
        priority: "medium",
        due_date: new Date().toISOString(),
        assigned_to: currentUser?.email,
        created_by: currentUser?.email
      });
      setNewTaskTitle("");
      setIsAdding(false);
      if (onTaskUpdate) onTaskUpdate();
    } catch (error) {
      console.error("Error creating task:", error);
    }
  };

  const toggleComplete = async (task) => {
    const newStatus = task.status === 'done' ? 'todo' : 'done';
    const isCompleted = newStatus === 'done';
    
    try {
      await base44.entities.TodoTask.update(task.id, { 
        status: newStatus,
        is_completed: isCompleted 
      });
      if (onTaskUpdate) onTaskUpdate();
    } catch (error) {
      console.error("Error updating task:", error);
    }
  };

  const myTasks = tasks.filter(t => t.assigned_to === currentUser?.email);
  
  // Group tasks
  const todaysTasks = myTasks.filter(t => isToday(new Date(t.due_date)) && t.status !== 'done');
  const overdueTasks = myTasks.filter(t => isPast(new Date(t.due_date)) && !isToday(new Date(t.due_date)) && t.status !== 'done');
  const upcomingTasks = myTasks.filter(t => !isToday(new Date(t.due_date)) && !isPast(new Date(t.due_date)) && t.status !== 'done');
  const completedTasks = myTasks.filter(t => t.status === 'done');

  const TaskItem = ({ task }) => (
    <div className="group flex items-center gap-3 p-2 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer">
      <Checkbox 
        checked={task.status === 'done'} 
        onCheckedChange={() => toggleComplete(task)}
        onClick={(e) => e.stopPropagation()}
      />
      <div className="flex-1 min-w-0" onClick={() => onTaskClick(task)}>
        <p className={`text-sm font-medium truncate ${task.status === 'done' ? 'text-gray-400 line-through' : 'text-gray-700'}`}>
          {task.title}
        </p>
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase ${
            task.priority === 'high' || task.priority === 'urgent' ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-500'
          }`}>
            {task.priority}
          </span>
          {task.due_date && (
            <span className="flex items-center gap-1">
              <CalendarIcon className="w-3 h-3" />
              {format(new Date(task.due_date), "d MMM", { locale: es })}
            </span>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-white border-r border-gray-200 w-80 flex-shrink-0">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gradient-to-r from-indigo-50 to-white">
        <h2 className="font-bold text-indigo-900">Mi Trabajo</h2>
        <Button variant="ghost" size="icon" onClick={() => setIsAdding(!isAdding)}>
          <Plus className="w-5 h-5 text-indigo-600" />
        </Button>
      </div>

      <div className="p-3 bg-indigo-50/50">
        {isAdding && (
          <form onSubmit={handleAddTask} className="flex gap-2 mb-2">
            <Input 
              autoFocus
              placeholder="Nueva tarea..." 
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              className="bg-white h-9"
            />
            <Button type="submit" size="sm" className="h-9 bg-indigo-600">Add</Button>
          </form>
        )}
        <div className="text-xs font-bold text-indigo-400 uppercase tracking-wider mb-2 pl-1">Para Hoy</div>
      </div>

      <ScrollArea className="flex-1 px-2">
        {overdueTasks.length > 0 && (
          <div className="mb-4">
            <h3 className="px-2 py-1 text-xs font-semibold text-red-500 flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Atrasadas
            </h3>
            {overdueTasks.map(task => <TaskItem key={task.id} task={task} />)}
          </div>
        )}

        <div className="mb-4">
          {todaysTasks.length === 0 && overdueTasks.length === 0 && !isAdding && (
            <div className="text-center py-8 text-gray-400 text-sm">
              <div className="mb-2">🎉</div>
              ¡Todo al día!
            </div>
          )}
          {todaysTasks.map(task => <TaskItem key={task.id} task={task} />)}
        </div>

        {upcomingTasks.length > 0 && (
          <div className="mb-4">
            <h3 className="px-2 py-1 text-xs font-semibold text-gray-500">Próximamente</h3>
            {upcomingTasks.map(task => <TaskItem key={task.id} task={task} />)}
          </div>
        )}

        {completedTasks.length > 0 && (
          <div>
            <h3 className="px-2 py-1 text-xs font-semibold text-gray-400">Completadas</h3>
            {completedTasks.map(task => <TaskItem key={task.id} task={task} />)}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}

// Helper icon
function AlertCircle({ className }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <circle cx="12" cy="12" r="10" />
      <line x1="12" x2="12" y1="8" y2="12" />
      <line x1="12" x2="12.01" y1="16" y2="16" />
    </svg>
  );
}
import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, FileText, ExternalLink, Upload, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function InvitadoWork() {
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openModal, setOpenModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [user, setUser] = useState(null);
  
  const [newSubmission, setNewSubmission] = useState({
    title: "",
    description: "",
    project_link: "",
    files: []
  });

  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      const data = await base44.entities.GuestSubmission.filter({ user_email: userData.email });
      setSubmissions(data);
    } catch (error) {
      console.error("Error loading submissions:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await base44.entities.GuestSubmission.create({
        ...newSubmission,
        user_email: user.email,
        status: "reviewing"
      });
      
      toast({ title: "Entrega enviada", description: "Tu trabajo ha sido enviado para revisión.", className: "bg-green-50 border-green-200 text-green-800" });
      setOpenModal(false);
      setNewSubmission({ title: "", description: "", project_link: "", files: [] });
      loadData();
    } catch (error) {
      console.error("Error creating submission:", error);
      toast({ title: "Error", description: "No se pudo enviar la entrega.", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusBadge = (status) => {
    switch(status) {
      case 'approved': return <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-0">Aprobado</Badge>;
      case 'rejected': return <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-0">Rechazado</Badge>;
      default: return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-0">En Revisión</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Mis Entregas</h1>
          <p className="text-gray-500 text-sm">Gestiona tus entregas y consulta su estado</p>
        </div>
        
        <Dialog open={openModal} onOpenChange={setOpenModal}>
          <DialogTrigger asChild>
            <Button className="bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm">
              <Plus className="w-4 h-4 mr-2" /> Nueva Entrega
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Nueva Entrega de Trabajo</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Título de la Entrega</Label>
                <Input 
                  required 
                  placeholder="Ej. Landing Page V1" 
                  value={newSubmission.title}
                  onChange={(e) => setNewSubmission({...newSubmission, title: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Descripción</Label>
                <Textarea 
                  placeholder="Detalles sobre el trabajo realizado..." 
                  value={newSubmission.description}
                  onChange={(e) => setNewSubmission({...newSubmission, description: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Enlace al Proyecto (Figma, Github, Drive...)</Label>
                <Input 
                  placeholder="https://..." 
                  value={newSubmission.project_link}
                  onChange={(e) => setNewSubmission({...newSubmission, project_link: e.target.value})}
                />
              </div>
              
              <div className="border-2 border-dashed border-gray-200 rounded-lg p-8 flex flex-col items-center justify-center bg-gray-50">
                <Upload className="w-8 h-8 text-gray-400 mb-2" />
                <p className="text-sm font-medium text-gray-900">Arrastra archivos aquí</p>
                <p className="text-xs text-gray-500 mb-4">o haz clic para seleccionar</p>
                <Button type="button" variant="secondary" size="sm">Seleccionar Archivos</Button>
              </div>

              <div className="flex justify-end pt-4">
                <Button type="submit" disabled={submitting} className="bg-indigo-600 text-white">
                  {submitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin"/> Enviando...</> : "Enviar Entrega"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="bg-white border-gray-200 shadow-sm">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50 border-b-gray-200 hover:bg-gray-50">
                <TableHead className="font-semibold text-gray-700">Título</TableHead>
                <TableHead className="font-semibold text-gray-700">Fecha</TableHead>
                <TableHead className="font-semibold text-gray-700">Enlace</TableHead>
                <TableHead className="font-semibold text-gray-700">Archivos</TableHead>
                <TableHead className="font-semibold text-gray-700 text-right">Estado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8">Cargando entregas...</TableCell>
                </TableRow>
              ) : submissions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-12 text-gray-500">
                    No has realizado ninguna entrega todavía.
                  </TableCell>
                </TableRow>
              ) : (
                submissions.map((item) => (
                  <TableRow key={item.id} className="border-b-gray-100">
                    <TableCell className="font-medium">
                      <div className="flex flex-col">
                        <span className="text-gray-900">{item.title}</span>
                        {item.description && <span className="text-xs text-gray-500 truncate max-w-[200px]">{item.description}</span>}
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-500 text-sm">
                      {new Date(item.created_date).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      {item.project_link ? (
                        <a href={item.project_link} target="_blank" rel="noopener noreferrer" className="flex items-center text-indigo-600 hover:underline text-sm">
                          Ver Proyecto <ExternalLink className="w-3 h-3 ml-1" />
                        </a>
                      ) : "-"}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {item.files && item.files.length > 0 ? (
                          <Badge variant="outline" className="text-gray-600 border-gray-300 bg-gray-50">
                            <FileText className="w-3 h-3 mr-1" /> {item.files.length} Archivos
                          </Badge>
                        ) : (
                          <span className="text-gray-400 text-sm">-</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      {getStatusBadge(item.status)}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
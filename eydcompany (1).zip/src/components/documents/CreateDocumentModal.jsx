import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FileText, Save } from "lucide-react";

export default function CreateDocumentModal({ isOpen, onClose, onNext, currentFolder }) {
  const [formData, setFormData] = useState({
    name: "",
    content: "",
    description: ""
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Crear archivo de texto
    const fileName = formData.name.endsWith('.txt') ? formData.name : `${formData.name}.txt`;
    const file = new File([formData.content], fileName, { type: 'text/plain' });
    
    onNext({
      file,
      name: formData.name,
      description: formData.description
    });
    
    // Reset form
    setFormData({ name: "", content: "", description: "" });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl sm:text-2xl font-bold flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
              <FileText className="w-5 h-5 text-white" />
            </div>
            Crear Documento de Texto
          </DialogTitle>
          {currentFolder && (
            <p className="text-sm text-gray-500">
              Se creará en: <span className="font-medium">{currentFolder.name}</span>
            </p>
          )}
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-semibold">Nombre del documento</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Ej: Notas de reunión"
                required
                className="mt-1.5"
                autoFocus
              />
            </div>

            <div>
              <Label className="text-sm font-semibold">Contenido</Label>
              <Textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                placeholder="Escribe aquí el contenido de tu documento..."
                className="mt-1.5 min-h-[300px] font-mono text-sm"
                required
              />
            </div>

            <div>
              <Label className="text-sm font-semibold">Descripción (opcional)</Label>
              <Input
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Breve descripción..."
                className="mt-1.5"
              />
            </div>
          </div>

          <DialogFooter className="gap-2 flex-col sm:flex-row">
            <Button type="button" variant="outline" onClick={onClose} className="h-11 w-full sm:w-auto">
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white h-11 px-6 shadow-lg w-full sm:w-auto"
              disabled={!formData.name || !formData.content}
            >
              <Save className="w-4 h-4 mr-2" />
              Guardar y Continuar
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
import React from 'react';
import { cn } from "@/lib/utils";

export default function ChatLayout({ 
  sidebar, 
  chat, 
  thread, 
  showThread 
}) {
  return (
    <div className="flex h-[calc(100vh-3.5rem)] w-full overflow-hidden bg-white">
      {/* Sidebar - Channels & DMs */}
      <div className="w-64 flex-shrink-0 border-r border-gray-200 bg-[#F5F7FA] hidden md:flex flex-col">
        {sidebar}
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-white relative">
        {chat}
      </div>

      {/* Thread View - Collapsible */}
      {showThread && (
        <div className="w-80 flex-shrink-0 border-l border-gray-200 bg-white shadow-xl z-20 absolute right-0 h-full md:relative md:shadow-none">
          {thread}
        </div>
      )}
    </div>
  );
}
import React from 'react';
import { motion } from 'framer-motion';

const Element = React.memo(({ el, isSelected, onSelect }) => {
  const commonProps = {
    onClick: (e) => { e.stopPropagation(); onSelect(el.id, e.shiftKey); },
    stroke: isSelected ? "#0073EA" : (el.stroke || "#000"),
    strokeWidth: isSelected ? 2 : (el.strokeWidth || 1),
    fill: el.fill || "transparent",
    style: { cursor: 'pointer', pointerEvents: 'all' }
  };
  
  // Selection halo
  const Halo = isSelected ? (
    <rect 
      x={el.x - 4} y={el.y - 4} 
      width={el.width + 8} height={el.height + 8} 
      fill="none" stroke="#0073EA" strokeWidth="1" strokeDasharray="4" 
      className="pointer-events-none animate-pulse"
    />
  ) : null;

  switch (el.type) {
    case 'rect':
      return (
        <g>
          {Halo}
          <rect x={el.x} y={el.y} width={el.width} height={el.height} {...commonProps} rx={4} />
        </g>
      );
    case 'circle':
      return (
        <g>
          {isSelected && <rect x={el.x - el.width/2 - 4} y={el.y - el.height/2 - 4} width={el.width + 8} height={el.height + 8} fill="none" stroke="#0073EA" strokeWidth="1" strokeDasharray="4" />}
          <ellipse cx={el.x} cy={el.y} rx={el.width / 2} ry={el.height / 2} {...commonProps} />
        </g>
      );
    case 'diamond':
      const hw = el.width / 2;
      const hh = el.height / 2;
      const points = `${el.x + hw},${el.y} ${el.x + el.width},${el.y + hh} ${el.x + hw},${el.y + el.height} ${el.x},${el.y + hh}`;
      return (
        <g>
          {Halo}
          <polygon points={points} {...commonProps} />
        </g>
      );
    case 'sticky':
      return (
        <g onClick={commonProps.onClick}>
          {Halo}
          <rect 
            x={el.x} y={el.y} width={el.width} height={el.height} 
            fill={el.fill || "#FFF9C4"} stroke="none" 
            style={{ filter: 'drop-shadow(2px 2px 2px rgba(0,0,0,0.1))' }}
          />
          <foreignObject x={el.x} y={el.y} width={el.width} height={el.height} style={{ pointerEvents: 'none' }}>
            <div className="w-full h-full p-2 flex items-center justify-center text-center text-sm select-none overflow-hidden break-words">
              {el.text || "Nota"}
            </div>
          </foreignObject>
        </g>
      );
    case 'text':
      return (
        <g onClick={commonProps.onClick}>
          {Halo}
          <text 
            x={el.x} y={el.y + el.height/2} 
            dominantBaseline="middle" 
            fontSize={el.fontSize || 16}
            fontFamily="sans-serif"
            fill={el.fill || "#000"}
            style={{ userSelect: 'none', cursor: 'pointer' }}
          >
            {el.text || "Texto"}
          </text>
        </g>
      );
    default:
      return null;
  }
});

export default Element;
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { MessageSquare, Send, Smile, X, AtSign } from "lucide-react";
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const EMOJI_OPTIONS = ['👍', '❤️', '😂', '🎉', '👏', '🔥'];

export default function CommentsPanel({ 
  elementId, 
  comments, 
  onAddComment, 
  onAddReaction,
  activeSessions,
  currentUser 
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [mentions, setMentions] = useState([]);
  const [showMentionMenu, setShowMentionMenu] = useState(false);
  const [mentionSearch, setMentionSearch] = useState('');

  const elementComments = comments.filter(c => c.element_id === elementId);
  const unreadCount = elementComments.filter(c => !c.is_read && c.user_email !== currentUser.email).length;

  const handleCommentChange = (e) => {
    const value = e.target.value;
    setNewComment(value);

    // Detectar @menciones
    const lastAtIndex = value.lastIndexOf('@');
    if (lastAtIndex !== -1 && lastAtIndex === value.length - 1) {
      setShowMentionMenu(true);
      setMentionSearch('');
    } else if (showMentionMenu) {
      const searchTerm = value.substring(lastAtIndex + 1);
      if (searchTerm.includes(' ')) {
        setShowMentionMenu(false);
      } else {
        setMentionSearch(searchTerm);
      }
    }
  };

  const handleMentionSelect = (user) => {
    const lastAtIndex = newComment.lastIndexOf('@');
    const beforeAt = newComment.substring(0, lastAtIndex);
    const newValue = beforeAt + `@${user.user_name} `;
    setNewComment(newValue);
    setMentions([...mentions, user.user_email]);
    setShowMentionMenu(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    onAddComment({
      element_id: elementId,
      comment: newComment,
      mentions
    });

    setNewComment('');
    setMentions([]);
  };

  const filteredUsers = activeSessions.filter(s => 
    s.user_name.toLowerCase().includes(mentionSearch.toLowerCase()) &&
    s.user_email !== currentUser.email
  );

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="h-9 w-9 relative">
          <MessageSquare className="w-4 h-4" />
          {unreadCount > 0 && (
            <Badge 
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-orange-500 text-white text-xs"
            >
              {unreadCount}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-96">
        <SheetHeader>
          <SheetTitle>Comentarios ({elementComments.length})</SheetTitle>
        </SheetHeader>

        <div className="flex flex-col h-full mt-4">
          {/* Lista de comentarios */}
          <ScrollArea className="flex-1 pr-4">
            <div className="space-y-4">
              {elementComments.map((comment) => (
                <div key={comment.id} className="space-y-2">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                      {comment.user_name.substring(0, 2).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm text-gray-900">
                          {comment.user_name}
                        </span>
                        <span className="text-xs text-gray-500">
                          {format(new Date(comment.created_date), 'HH:mm', { locale: es })}
                        </span>
                      </div>
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">
                        {comment.comment}
                      </p>

                      {/* Reacciones */}
                      <div className="flex items-center gap-2 mt-2">
                        {Object.entries(comment.reactions || {}).map(([emoji, users]) => (
                          <button
                            key={emoji}
                            onClick={() => onAddReaction(comment.id, emoji)}
                            className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs transition-all ${
                              users.includes(currentUser.email)
                                ? 'bg-blue-100 ring-2 ring-blue-300'
                                : 'bg-gray-100 hover:bg-gray-200'
                            }`}
                          >
                            <span>{emoji}</span>
                            <span className="font-medium">{users.length}</span>
                          </button>
                        ))}

                        {/* Añadir reacción */}
                        <Popover>
                          <PopoverTrigger asChild>
                            <button className="w-7 h-7 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors">
                              <Smile className="w-4 h-4 text-gray-600" />
                            </button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-2">
                            <div className="flex gap-1">
                              {EMOJI_OPTIONS.map(emoji => (
                                <button
                                  key={emoji}
                                  onClick={() => onAddReaction(comment.id, emoji)}
                                  className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded transition-colors text-lg"
                                >
                                  {emoji}
                                </button>
                              ))}
                            </div>
                          </PopoverContent>
                        </Popover>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {elementComments.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <MessageSquare className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-sm">No hay comentarios aún</p>
                  <p className="text-xs text-gray-400 mt-1">Sé el primero en comentar</p>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Formulario de nuevo comentario */}
          <form onSubmit={handleSubmit} className="mt-4 border-t pt-4 space-y-3">
            <div className="relative">
              <Textarea
                value={newComment}
                onChange={handleCommentChange}
                placeholder="Escribe un comentario... (@menciona usuarios)"
                className="resize-none pr-10"
                rows={3}
                maxLength={500}
              />

              {/* Menú de menciones */}
              {showMentionMenu && filteredUsers.length > 0 && (
                <div className="absolute bottom-full left-0 right-0 mb-2 bg-white border rounded-lg shadow-lg max-h-48 overflow-y-auto">
                  {filteredUsers.map(user => (
                    <button
                      key={user.id}
                      type="button"
                      onClick={() => handleMentionSelect(user)}
                      className="w-full flex items-center gap-2 px-3 py-2 hover:bg-gray-50 transition-colors text-left"
                    >
                      <div 
                        className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold"
                        style={{ backgroundColor: user.user_color }}
                      >
                        {user.user_name.substring(0, 2).toUpperCase()}
                      </div>
                      <span className="text-sm font-medium">{user.user_name}</span>
                    </button>
                  ))}
                </div>
              )}

              <button
                type="button"
                className="absolute bottom-2 right-2 text-gray-400 hover:text-gray-600"
              >
                <AtSign className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-500">
                {newComment.length}/500
              </span>
              <Button
                type="submit"
                size="sm"
                disabled={!newComment.trim()}
                className="bg-[#0073EA] hover:bg-[#0056B3]"
              >
                <Send className="w-4 h-4 mr-2" />
                Enviar
              </Button>
            </div>
          </form>
        </div>
      </SheetContent>
    </Sheet>
  );
}
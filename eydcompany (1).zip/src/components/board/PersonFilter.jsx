import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { X, User, Users, Search, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function PersonFilter({ items, selectedPeople, onChange, onClose, board }) {
  const [searchQuery, setSearchQuery] = useState("");

  // Extract unique people from items - checking multiple possible column types
  const allPeople = useMemo(() => {
    const peopleColumn = board?.columns?.find(col => col.type === 'people');
    const peopleSet = new Set();

    items.forEach(item => {
      const personValue = item.data?.[peopleColumn?.id];
      if (personValue) {
        if (Array.isArray(personValue)) {
          personValue.forEach(person => peopleSet.add(person));
        } else {
          peopleSet.add(personValue);
        }
      }
    });

    return Array.from(peopleSet).sort();
  }, [items, board]);

  // Filter people based on search
  const filteredPeople = useMemo(() => {
    if (!searchQuery.trim()) return allPeople;
    return allPeople.filter(person =>
      person.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [allPeople, searchQuery]);

  const handlePersonChange = (person, checked) => {
    const newPeople = checked 
      ? [...selectedPeople, person]
      : selectedPeople.filter(p => p !== person);
    onChange(newPeople);
  };

  const handleSelectAll = () => {
    onChange(filteredPeople);
  };

  const handleClearAll = () => {
    onChange([]);
  };

  const getPersonColor = (index) => {
    const colors = [
      '#6366F1', '#8B5CF6', '#EC4899', '#F59E0B', 
      '#10B981', '#3B82F6', '#EF4444', '#8B5CF6'
    ];
    return colors[index % colors.length];
  };

  const getPersonInitials = (name) => {
    const parts = name.split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  // Count tasks per person
  const getPersonTaskCount = (person) => {
    const peopleColumn = board?.columns?.find(col => col.type === 'people');
    return items.filter(item => {
      const personValue = item.data?.[peopleColumn?.id];
      if (Array.isArray(personValue)) {
        return personValue.includes(person);
      }
      return personValue === person;
    }).length;
  };

  return (
    <motion.div
      initial={{ x: 400, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 400, opacity: 0 }}
      transition={{ type: "spring", damping: 25, stiffness: 300 }}
      className="w-[380px] h-full bg-white shadow-2xl border-l border-gray-200"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-purple-50 to-pink-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
            <Users className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">Filtrar por Persona</h3>
            {selectedPeople.length > 0 && (
              <p className="text-xs text-gray-600">{selectedPeople.length} seleccionada{selectedPeople.length !== 1 ? 's' : ''}</p>
            )}
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="h-8 w-8 hover:bg-gray-200"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>

      {/* Search */}
      <div className="p-4 border-b bg-gray-50">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Buscar persona..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 h-9 bg-white"
          />
        </div>
      </div>

      {/* Quick Actions */}
      {allPeople.length > 0 && (
        <div className="flex gap-2 px-4 py-3 border-b bg-gray-50">
          <Button
            variant="outline"
            size="sm"
            onClick={handleSelectAll}
            className="flex-1 h-8 text-xs"
            disabled={selectedPeople.length === filteredPeople.length}
          >
            Seleccionar Todo
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleClearAll}
            className="flex-1 h-8 text-xs"
            disabled={selectedPeople.length === 0}
          >
            Limpiar
          </Button>
        </div>
      )}

      {/* Content */}
      <div className="overflow-y-auto h-[calc(100%-240px)]">
        <div className="p-4">
          {allPeople.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="w-8 h-8 text-gray-400" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-1">Sin personas asignadas</h4>
              <p className="text-sm text-gray-500">
                Añade personas a tus tareas para filtrar por ellas
              </p>
            </div>
          ) : filteredPeople.length === 0 ? (
            <div className="text-center py-12">
              <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-sm text-gray-500">
                No se encontraron personas que coincidan con "{searchQuery}"
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <AnimatePresence>
                {filteredPeople.map((person, index) => {
                  const taskCount = getPersonTaskCount(person);
                  const isSelected = selectedPeople.includes(person);
                  
                  return (
                    <motion.div
                      key={person}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ delay: index * 0.05 }}
                      className={`flex items-center space-x-3 p-3 rounded-lg transition-all cursor-pointer ${
                        isSelected 
                          ? 'bg-purple-50 border-2 border-purple-300' 
                          : 'hover:bg-gray-50 border-2 border-transparent'
                      }`}
                      onClick={() => handlePersonChange(person, !isSelected)}
                    >
                      <Checkbox
                        id={`person-${person}`}
                        checked={isSelected}
                        onCheckedChange={(checked) => handlePersonChange(person, checked)}
                      />
                      <div 
                        className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-sm"
                        style={{ backgroundColor: getPersonColor(index) }}
                      >
                        {getPersonInitials(person)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900 text-sm truncate">
                          {person}
                        </p>
                        <p className="text-xs text-gray-500">
                          {taskCount} tarea{taskCount !== 1 ? 's' : ''}
                        </p>
                      </div>
                      {isSelected && (
                        <Badge className="bg-purple-600 text-white">
                          ✓
                        </Badge>
                      )}
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>

      {/* Selected People Summary */}
      {selectedPeople.length > 0 && (
        <div className="border-t bg-purple-50 p-4">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-semibold text-purple-900">Seleccionadas</h4>
            <Badge className="bg-purple-600 text-white">{selectedPeople.length}</Badge>
          </div>
          <div className="flex flex-wrap gap-2">
            {selectedPeople.map((person, index) => (
              <Badge
                key={person}
                variant="secondary"
                className="gap-1 pr-1 bg-white border border-purple-200"
              >
                <div 
                  className="w-4 h-4 rounded-full flex items-center justify-center text-white text-[10px] font-bold"
                  style={{ backgroundColor: getPersonColor(allPeople.indexOf(person)) }}
                >
                  {getPersonInitials(person)[0]}
                </div>
                <span className="text-xs">{person}</span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePersonChange(person, false);
                  }}
                  className="ml-1 hover:bg-purple-200 rounded-full p-0.5"
                >
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="absolute bottom-0 left-0 right-0 p-4 border-t bg-gray-50">
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={handleClearAll}
            disabled={selectedPeople.length === 0}
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Limpiar
          </Button>
          <Button
            className="flex-1 bg-purple-600 hover:bg-purple-700"
            onClick={onClose}
          >
            Aplicar Filtros
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
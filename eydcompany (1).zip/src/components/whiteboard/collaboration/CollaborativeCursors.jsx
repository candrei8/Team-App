import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function CollaborativeCursors({ sessions, currentUserEmail, zoom, pan }) {
  const [visibleLabels, setVisibleLabels] = useState({});

  // Ocultar labels después de 3 segundos sin movimiento
  useEffect(() => {
    const timers = {};
    
    sessions.forEach(session => {
      if (session.user_email !== currentUserEmail && session.cursor_position) {
        if (timers[session.id]) {
          clearTimeout(timers[session.id]);
        }
        
        setVisibleLabels(prev => ({ ...prev, [session.id]: true }));
        
        timers[session.id] = setTimeout(() => {
          setVisibleLabels(prev => ({ ...prev, [session.id]: false }));
        }, 3000);
      }
    });

    return () => {
      Object.values(timers).forEach(timer => clearTimeout(timer));
    };
  }, [sessions, currentUserEmail]);

  return (
    <AnimatePresence>
      {sessions
        .filter(s => s.user_email !== currentUserEmail && s.cursor_position && s.is_active)
        .map((session) => {
          const { x, y } = session.cursor_position;
          const screenX = x * zoom + pan.x;
          const screenY = y * zoom + pan.y;

          // Determinar si el cursor está inactivo (>30s)
          const lastActivity = new Date(session.last_activity);
          const secondsSince = (new Date() - lastActivity) / 1000;
          const isInactive = secondsSince > 30;

          return (
            <motion.div
              key={session.id}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ 
                opacity: isInactive ? 0.3 : 1, 
                scale: 1,
                x: screenX,
                y: screenY
              }}
              exit={{ opacity: 0, scale: 0.5 }}
              transition={{ 
                type: "spring", 
                stiffness: 500, 
                damping: 30,
                opacity: { duration: 0.2 }
              }}
              className="fixed pointer-events-none z-50"
              style={{ 
                left: 0, 
                top: 0,
              }}
            >
              {/* Cursor SVG */}
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path
                  d="M5.65376 12.3673L11.6321 4.03347C11.9653 3.52175 12.7042 3.52175 13.0374 4.03347L19.0157 12.3673C19.4861 13.0758 18.9811 14 18.1433 14H6.52624C5.68839 14 5.18339 13.0758 5.65376 12.3673Z"
                  fill={session.user_color}
                  stroke="white"
                  strokeWidth="1.5"
                />
              </svg>

              {/* Nombre del usuario */}
              <AnimatePresence>
                {visibleLabels[session.id] && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    transition={{ duration: 0.2 }}
                    className="absolute top-6 left-3 whitespace-nowrap"
                  >
                    <div
                      className="px-2 py-1 rounded-md text-white text-xs font-medium shadow-lg"
                      style={{ backgroundColor: session.user_color }}
                    >
                      {session.user_name}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
    </AnimatePresence>
  );
}
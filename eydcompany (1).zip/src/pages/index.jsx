import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Boards from "./Boards";

import Board from "./Board";

import Analytics from "./Analytics";

import Settings from "./Settings";

import Users from "./Users";

import Documents from "./Documents";

import Whiteboards from "./Whiteboards";

import WhiteboardCanvas from "./WhiteboardCanvas";

import Profile from "./Profile";

import AccessBlocked from "./AccessBlocked";

import AdminPanel from "./AdminPanel";

import AuditLogs from "./AuditLogs";

import InvitadoDashboard from "./InvitadoDashboard";

import InvitadoProfile from "./InvitadoProfile";

import InvitadoWork from "./InvitadoWork";

import InvitadoInvoices from "./InvitadoInvoices";

import Messages from "./Messages";

import GuestRecords from "./GuestRecords";

import CalendarView from "./CalendarView";

import Privacy from "./Privacy";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Boards: Boards,
    
    Board: Board,
    
    Analytics: Analytics,
    
    Settings: Settings,
    
    Users: Users,
    
    Documents: Documents,
    
    Whiteboards: Whiteboards,
    
    WhiteboardCanvas: WhiteboardCanvas,
    
    Profile: Profile,
    
    AccessBlocked: AccessBlocked,
    
    AdminPanel: AdminPanel,
    
    AuditLogs: AuditLogs,
    
    InvitadoDashboard: InvitadoDashboard,
    
    InvitadoProfile: InvitadoProfile,
    
    InvitadoWork: InvitadoWork,
    
    InvitadoInvoices: InvitadoInvoices,
    
    Messages: Messages,
    
    GuestRecords: GuestRecords,
    
    CalendarView: CalendarView,
    
    Privacy: Privacy,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Boards" element={<Boards />} />
                
                <Route path="/Board" element={<Board />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Users" element={<Users />} />
                
                <Route path="/Documents" element={<Documents />} />
                
                <Route path="/Whiteboards" element={<Whiteboards />} />
                
                <Route path="/WhiteboardCanvas" element={<WhiteboardCanvas />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/AccessBlocked" element={<AccessBlocked />} />
                
                <Route path="/AdminPanel" element={<AdminPanel />} />
                
                <Route path="/AuditLogs" element={<AuditLogs />} />
                
                <Route path="/InvitadoDashboard" element={<InvitadoDashboard />} />
                
                <Route path="/InvitadoProfile" element={<InvitadoProfile />} />
                
                <Route path="/InvitadoWork" element={<InvitadoWork />} />
                
                <Route path="/InvitadoInvoices" element={<InvitadoInvoices />} />
                
                <Route path="/Messages" element={<Messages />} />
                
                <Route path="/GuestRecords" element={<GuestRecords />} />
                
                <Route path="/CalendarView" element={<CalendarView />} />
                
                <Route path="/Privacy" element={<Privacy />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}
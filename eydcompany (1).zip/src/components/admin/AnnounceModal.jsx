import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Megaphone, Upload, X, File, FileText, Image as ImageIcon } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function AnnounceModal({ isOpen, onClose, onSubmit }) {
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [sendEmail, setSendEmail] = useState(false);
  const [targetType, setTargetType] = useState("all");
  const [targetValue, setTargetValue] = useState("");
  const [users, setUsers] = useState([]);
  const [attachments, setAttachments] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadUsers();
    }
  }, [isOpen]);

  const loadUsers = async () => {
    try {
      const allUsers = await base44.entities.User.list("-created_date");
      setUsers(allUsers);
    } catch (error) {
      console.error("Error al cargar usuarios:", error);
    }
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setIsUploading(true);

    try {
      const uploadedFiles = [];
      
      for (const file of files) {
        // Validar tipo de archivo
        const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        if (!validTypes.includes(file.type)) {
          toast({
            title: "Archivo no soportado",
            description: `${file.name} no es un tipo de archivo válido`,
            variant: "destructive"
          });
          continue;
        }

        // Validar tamaño (máximo 10MB)
        if (file.size > 10 * 1024 * 1024) {
          toast({
            title: "Archivo muy grande",
            description: `${file.name} excede el tamaño máximo de 10MB`,
            variant: "destructive"
          });
          continue;
        }

        // Subir archivo
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        
        uploadedFiles.push({
          name: file.name,
          url: file_url,
          type: file.type,
          size: file.size
        });
      }

      setAttachments([...attachments, ...uploadedFiles]);
      
      toast({
        title: "✓ Archivos subidos",
        description: `${uploadedFiles.length} archivo(s) subido(s) correctamente`
      });
    } catch (error) {
      console.error("Error al subir archivos:", error);
      toast({
        title: "Error",
        description: "No se pudieron subir los archivos",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const removeAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const getFileIcon = (type) => {
    if (type.startsWith('image/')) return <ImageIcon className="w-4 h-4" />;
    if (type.includes('pdf')) return <FileText className="w-4 h-4" />;
    return <File className="w-4 h-4" />;
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const handleSubmit = async () => {
    if (!title.trim() || !message.trim()) {
      toast({
        title: "Campos requeridos",
        description: "Título y mensaje son obligatorios",
        variant: "destructive"
      });
      return;
    }

    if (targetType !== "all" && !targetValue) {
      toast({
        title: "Selecciona un destinatario",
        description: "Debes seleccionar un usuario o departamento",
        variant: "destructive"
      });
      return;
    }

    setIsSending(true);

    try {
      await onSubmit({
        title,
        message,
        sendEmail,
        targetType,
        targetValue,
        attachments
      });

      // Limpiar formulario
      setTitle("");
      setMessage("");
      setSendEmail(false);
      setTargetType("all");
      setTargetValue("");
      setAttachments([]);
      
      onClose();
    } catch (error) {
      console.error("Error al enviar anuncio:", error);
    } finally {
      setIsSending(false);
    }
  };

  const departments = [
    "IA",
    "Marketing",
    "Relaciones Internacionales",
    "Dirección",
    "Diseñador",
    "Operaciones",
    "Finanzas",
    "Recursos Humanos",
    "Tecnología",
    "Ventas",
    "Otro"
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Megaphone className="w-6 h-6 text-[#0073EA]" />
            Enviar Anuncio
          </DialogTitle>
          <DialogDescription>
            Envía un anuncio a usuarios específicos o a toda la organización
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 py-4">
          {/* Título */}
          <div className="space-y-2">
            <Label htmlFor="title">Título *</Label>
            <Input
              id="title"
              placeholder="Ej: Nueva actualización del sistema"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={100}
            />
          </div>

          {/* Mensaje */}
          <div className="space-y-2">
            <Label htmlFor="message">Mensaje *</Label>
            <Textarea
              id="message"
              placeholder="Escribe el contenido del anuncio..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="min-h-[120px] resize-none"
              maxLength={1000}
            />
            <p className="text-xs text-gray-500 text-right">
              {message.length}/1000 caracteres
            </p>
          </div>

          {/* Destinatarios */}
          <div className="space-y-2">
            <Label htmlFor="targetType">Enviar a *</Label>
            <Select value={targetType} onValueChange={(value) => {
              setTargetType(value);
              setTargetValue("");
            }}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona destinatarios" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los usuarios</SelectItem>
                <SelectItem value="user">Usuario específico</SelectItem>
                <SelectItem value="department">Departamento</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Usuario específico */}
          {targetType === "user" && (
            <div className="space-y-2">
              <Label htmlFor="user">Selecciona usuario</Label>
              <Select value={targetValue} onValueChange={setTargetValue}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un usuario" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.email}>
                      {user.full_name || user.email} ({user.email})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Departamento */}
          {targetType === "department" && (
            <div className="space-y-2">
              <Label htmlFor="department">Selecciona departamento</Label>
              <Select value={targetValue} onValueChange={setTargetValue}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un departamento" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Archivos adjuntos */}
          <div className="space-y-2">
            <Label>Archivos adjuntos (opcional)</Label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 hover:border-[#0073EA] transition-colors">
              <input
                type="file"
                id="file-upload"
                multiple
                accept="image/*,.pdf,.doc,.docx"
                onChange={handleFileUpload}
                className="hidden"
                disabled={isUploading}
              />
              <label
                htmlFor="file-upload"
                className="flex flex-col items-center gap-2 cursor-pointer"
              >
                <Upload className="w-8 h-8 text-gray-400" />
                <p className="text-sm text-gray-600">
                  {isUploading ? "Subiendo archivos..." : "Haz clic para subir archivos"}
                </p>
                <p className="text-xs text-gray-500">
                  Imágenes, PDF, DOC, DOCX (máx. 10MB por archivo)
                </p>
              </label>
            </div>

            {/* Lista de archivos */}
            {attachments.length > 0 && (
              <div className="space-y-2 mt-3">
                {attachments.map((file, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between bg-gray-50 rounded-lg p-3 border"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      {getFileIcon(file.type)}
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {file.name}
                        </p>
                        <p className="text-xs text-gray-500">
                          {formatFileSize(file.size)}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeAttachment(index)}
                      className="flex-shrink-0 hover:bg-red-100 hover:text-red-600"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Enviar por Email */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border">
            <div>
              <Label htmlFor="sendEmail" className="font-medium cursor-pointer">
                Enviar también por correo electrónico
              </Label>
              <p className="text-sm text-gray-600 mt-1">
                Los usuarios recibirán el anuncio en su email
              </p>
            </div>
            <Switch
              id="sendEmail"
              checked={sendEmail}
              onCheckedChange={setSendEmail}
            />
          </div>
        </div>

        {/* Botones */}
        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isSending}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isSending || isUploading}
            className="bg-[#0073EA] hover:bg-[#0056B3]"
          >
            {isSending ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Enviando...
              </>
            ) : (
              <>
                <Megaphone className="w-4 h-4 mr-2" />
                Enviar Anuncio
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
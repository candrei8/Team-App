import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Users } from "lucide-react";

const USER_COLORS = [
  "#FF6B6B", "#4ECDC4", "#45B7D1", "#FFA07A", "#98D8C8", 
  "#F7DC6F", "#BB8FCE", "#85C1E2", "#F8B739", "#52B788", 
  "#E85D75", "#6C5CE7"
];

export default function ActiveUsers({ sessions, currentUserEmail }) {
  const [sheetOpen, setSheetOpen] = useState(false);
  
  const activeSessions = sessions.filter(s => s.is_active);
  const visibleSessions = activeSessions.slice(0, 5);
  const hiddenCount = activeSessions.length - visibleSessions.length;

  const getUserInitials = (name) => {
    const parts = name.split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  const getTimeSince = (timestamp) => {
    const seconds = Math.floor((new Date() - new Date(timestamp)) / 1000);
    if (seconds < 60) return 'Ahora';
    if (seconds < 3600) return `Hace ${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `Hace ${Math.floor(seconds / 3600)}h`;
    return `Hace ${Math.floor(seconds / 86400)}d`;
  };

  return (
    <TooltipProvider>
      <div className="flex items-center gap-2">
        {/* Stack de avatares */}
        <div className="flex items-center -space-x-2">
          {visibleSessions.map((session, index) => (
            <Tooltip key={session.id}>
              <TooltipTrigger asChild>
                <div
                  className="relative w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold cursor-pointer ring-2 ring-white transition-transform hover:scale-110 hover:z-10"
                  style={{ 
                    backgroundColor: session.user_color,
                    zIndex: visibleSessions.length - index
                  }}
                >
                  {getUserInitials(session.user_name)}
                  {/* Indicador de activo */}
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p className="font-medium">{session.user_name}</p>
                <p className="text-xs text-gray-400">
                  {session.user_email === currentUserEmail ? 'Tú' : 'Activo ahora'}
                </p>
              </TooltipContent>
            </Tooltip>
          ))}

          {hiddenCount > 0 && (
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center bg-gray-500 text-white text-sm font-bold ring-2 ring-white cursor-pointer hover:scale-110 transition-transform"
              onClick={() => setSheetOpen(true)}
            >
              +{hiddenCount}
            </div>
          )}
        </div>

        {/* Botón para ver todos */}
        <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="h-9 w-9">
              <Users className="w-4 h-4" />
            </Button>
          </SheetTrigger>
          <SheetContent className="w-80">
            <SheetHeader>
              <SheetTitle>Usuarios Activos ({activeSessions.length})</SheetTitle>
            </SheetHeader>
            
            <div className="mt-6 space-y-3">
              {activeSessions.map((session) => (
                <div 
                  key={session.id}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div
                    className="relative w-12 h-12 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0"
                    style={{ backgroundColor: session.user_color }}
                  >
                    {getUserInitials(session.user_name)}
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-sm text-gray-900 truncate">
                        {session.user_name}
                      </p>
                      {session.user_email === currentUserEmail && (
                        <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">
                          Tú
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 truncate">{session.user_email}</p>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {getTimeSince(session.last_activity)}
                    </p>
                  </div>

                  {session.locked_element_id && (
                    <div className="text-xs text-gray-500 flex items-center gap-1">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></div>
                      Editando
                    </div>
                  )}
                </div>
              ))}

              {activeSessions.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-sm">No hay usuarios conectados</p>
                </div>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </TooltipProvider>
  );
}
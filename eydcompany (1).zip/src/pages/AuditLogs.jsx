import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  History,
  Search,
  Filter,
  Download,
  RefreshCw,
  FileText,
  MessageSquare,
  Folder,
  User,
  Settings,
  Shield,
  Calendar,
  Clock,
  ChevronRight,
  Loader2
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { motion } from "framer-motion";

export default function AuditLogsPage() {
  const [logs, setLogs] = useState([]);
  const [filteredLogs, setFilteredLogs] = useState([]);
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterUser, setFilterUser] = useState("all");
  const [filterActionType, setFilterActionType] = useState("all");
  const [filterDateRange, setFilterDateRange] = useState("all");

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [searchQuery, filterUser, filterActionType, filterDateRange, logs]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const userData = await base44.auth.me();
      setCurrentUser(userData);

      if (userData.role !== "admin") {
        window.location.href = "/Dashboard";
        return;
      }

      const [auditLogs, allUsers] = await Promise.all([
        base44.entities.UserAuditLog.list("-created_date", 500),
        base44.entities.User.list()
      ]);

      setLogs(auditLogs);
      setUsers(allUsers);
    } catch (error) {
      console.error("Error al cargar datos:", error);
    }
    setIsLoading(false);
  };

  const applyFilters = () => {
    let filtered = [...logs];

    // Filtro de búsqueda
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(log =>
        log.user_name?.toLowerCase().includes(query) ||
        log.user_email?.toLowerCase().includes(query) ||
        log.action_description?.toLowerCase().includes(query) ||
        log.target_name?.toLowerCase().includes(query)
      );
    }

    // Filtro por usuario
    if (filterUser !== "all") {
      filtered = filtered.filter(log => log.user_email === filterUser);
    }

    // Filtro por tipo de acción
    if (filterActionType !== "all") {
      filtered = filtered.filter(log => log.action_type === filterActionType);
    }

    // Filtro por rango de fecha
    if (filterDateRange !== "all") {
      const now = new Date();
      const ranges = {
        today: 1,
        week: 7,
        month: 30,
        quarter: 90
      };
      const daysAgo = ranges[filterDateRange];
      if (daysAgo) {
        const cutoffDate = new Date(now.setDate(now.getDate() - daysAgo));
        filtered = filtered.filter(log => new Date(log.created_date) >= cutoffDate);
      }
    }

    setFilteredLogs(filtered);
  };

  const getActionIcon = (actionType) => {
    const icons = {
      file_upload: FileText,
      file_download: Download,
      file_delete: FileText,
      file_view: FileText,
      message_sent: MessageSquare,
      message_deleted: MessageSquare,
      board_created: Folder,
      board_updated: Folder,
      board_deleted: Folder,
      item_created: Folder,
      item_updated: Folder,
      item_deleted: Folder,
      role_change: Shield,
      department_change: User,
      status_change: User,
      profile_update: User,
      settings_changed: Settings,
      login: User,
      logout: User,
    };
    const Icon = icons[actionType] || History;
    return <Icon className="w-4 h-4" />;
  };

  const getActionBadge = (actionType) => {
    const config = {
      file_upload: { bg: "bg-blue-100", text: "text-blue-700", label: "Subida de Archivo" },
      file_download: { bg: "bg-green-100", text: "text-green-700", label: "Descarga" },
      file_delete: { bg: "bg-red-100", text: "text-red-700", label: "Eliminación" },
      file_view: { bg: "bg-gray-100", text: "text-gray-700", label: "Visualización" },
      message_sent: { bg: "bg-purple-100", text: "text-purple-700", label: "Mensaje Enviado" },
      message_deleted: { bg: "bg-orange-100", text: "text-orange-700", label: "Mensaje Eliminado" },
      board_created: { bg: "bg-indigo-100", text: "text-indigo-700", label: "Proyecto Creado" },
      board_updated: { bg: "bg-cyan-100", text: "text-cyan-700", label: "Proyecto Actualizado" },
      board_deleted: { bg: "bg-red-100", text: "text-red-700", label: "Proyecto Eliminado" },
      item_created: { bg: "bg-teal-100", text: "text-teal-700", label: "Tarea Creada" },
      item_updated: { bg: "bg-lime-100", text: "text-lime-700", label: "Tarea Actualizada" },
      item_deleted: { bg: "bg-rose-100", text: "text-rose-700", label: "Tarea Eliminada" },
      role_change: { bg: "bg-purple-100", text: "text-purple-700", label: "Cambio de Rol" },
      department_change: { bg: "bg-blue-100", text: "text-blue-700", label: "Cambio de Depto." },
      status_change: { bg: "bg-amber-100", text: "text-amber-700", label: "Cambio de Estado" },
      profile_update: { bg: "bg-gray-100", text: "text-gray-700", label: "Perfil Actualizado" },
      settings_changed: { bg: "bg-slate-100", text: "text-slate-700", label: "Configuración" },
      login: { bg: "bg-green-100", text: "text-green-700", label: "Inicio de Sesión" },
      logout: { bg: "bg-gray-100", text: "text-gray-700", label: "Cierre de Sesión" },
    };

    const style = config[actionType] || { bg: "bg-gray-100", text: "text-gray-700", label: "Otra Acción" };

    return (
      <Badge className={`${style.bg} ${style.text} border-0 text-xs`}>
        {getActionIcon(actionType)}
        <span className="ml-1">{style.label}</span>
      </Badge>
    );
  };

  const exportLogs = () => {
    const csvContent = [
      ["Fecha", "Usuario", "Email", "Acción", "Descripción", "Recurso", "IP"],
      ...filteredLogs.map(log => [
        format(new Date(log.created_date), "dd/MM/yyyy HH:mm:ss", { locale: es }),
        log.user_name,
        log.user_email,
        log.action_type,
        log.action_description,
        log.target_name || "N/A",
        log.ip_address || "N/A"
      ])
    ].map(row => row.join(",")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `audit-logs-${format(new Date(), "yyyyMMdd-HHmmss")}.csv`;
    a.click();
  };

  const actionTypeOptions = [
    { value: "all", label: "Todas las acciones" },
    { value: "file_upload", label: "Subida de Archivos" },
    { value: "file_download", label: "Descargas" },
    { value: "file_delete", label: "Eliminaciones" },
    { value: "message_sent", label: "Mensajes Enviados" },
    { value: "board_created", label: "Proyectos Creados" },
    { value: "board_updated", label: "Proyectos Actualizados" },
    { value: "item_created", label: "Tareas Creadas" },
    { value: "role_change", label: "Cambios de Rol" },
    { value: "login", label: "Inicios de Sesión" },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F6F8]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-[#0073EA] mx-auto mb-4" />
          <p className="text-[#676879]">Cargando registros de auditoría...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 bg-[#F5F6F8] min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-[#323338] flex items-center gap-3">
              <History className="w-8 h-8 text-[#0073EA]" />
              Registro de Auditoría
            </h1>
            <p className="text-sm text-[#676879] mt-1">
              {filteredLogs.length} de {logs.length} registros
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={loadData}
              variant="outline"
              className="rounded-lg"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Actualizar
            </Button>
            <Button
              onClick={exportLogs}
              className="bg-[#0073EA] hover:bg-[#0056B3] rounded-lg"
            >
              <Download className="w-4 h-4 mr-2" />
              Exportar CSV
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">Total Registros</p>
                  <p className="text-2xl font-bold text-[#323338]">{logs.length}</p>
                </div>
                <History className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">Archivos</p>
                  <p className="text-2xl font-bold text-[#323338]">
                    {logs.filter(l => l.action_type?.includes("file")).length}
                  </p>
                </div>
                <FileText className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">Mensajes</p>
                  <p className="text-2xl font-bold text-[#323338]">
                    {logs.filter(l => l.action_type?.includes("message")).length}
                  </p>
                </div>
                <MessageSquare className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">Proyectos</p>
                  <p className="text-2xl font-bold text-[#323338]">
                    {logs.filter(l => l.action_type?.includes("board")).length}
                  </p>
                </div>
                <Folder className="w-8 h-8 text-indigo-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Search */}
              <div className="relative md:col-span-2">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-[#676879]" />
                <Input
                  placeholder="Buscar en registros..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>

              {/* User Filter */}
              <Select value={filterUser} onValueChange={setFilterUser}>
                <SelectTrigger>
                  <SelectValue placeholder="Usuario" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los usuarios</SelectItem>
                  {users.map(user => (
                    <SelectItem key={user.id} value={user.email}>
                      {user.full_name || user.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Action Type Filter */}
              <Select value={filterActionType} onValueChange={setFilterActionType}>
                <SelectTrigger>
                  <SelectValue placeholder="Tipo de acción" />
                </SelectTrigger>
                <SelectContent>
                  {actionTypeOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Date Range Filter */}
            <div className="flex gap-2 mt-4">
              <Button
                variant={filterDateRange === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterDateRange("all")}
                className="text-xs"
              >
                Todo
              </Button>
              <Button
                variant={filterDateRange === "today" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterDateRange("today")}
                className="text-xs"
              >
                Hoy
              </Button>
              <Button
                variant={filterDateRange === "week" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterDateRange("week")}
                className="text-xs"
              >
                Última semana
              </Button>
              <Button
                variant={filterDateRange === "month" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterDateRange("month")}
                className="text-xs"
              >
                Último mes
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Logs List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Registros Filtrados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              {filteredLogs.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <History className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                  <p>No se encontraron registros con los filtros aplicados</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredLogs.map((log, index) => (
                    <motion.div
                      key={log.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.02 }}
                    >
                      <Card className="hover:shadow-md transition-shadow border-l-4 border-l-[#0073EA]">
                        <CardContent className="p-4">
                          <div className="flex flex-col md:flex-row md:items-start gap-3">
                            {/* User Info - Quien realizó la acción */}
                            <div className="flex items-center gap-3 flex-1">
                              <div className="w-10 h-10 bg-gradient-to-br from-[#0073EA] to-[#00C875] rounded-full flex items-center justify-center flex-shrink-0">
                                <span className="text-white font-semibold text-sm">
                                  {log.user_name?.charAt(0) || "U"}
                                </span>
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="font-medium text-gray-900 truncate">{log.user_name}</p>
                                <p className="text-xs text-gray-500 truncate">{log.user_email}</p>
                              </div>
                            </div>

                            {/* Action Badge */}
                            <div className="flex flex-wrap items-center gap-2">
                              {getActionBadge(log.action_type)}
                            </div>

                            {/* Timestamp - Completo con segundos */}
                            <div className="flex items-center gap-1 text-xs text-gray-500 whitespace-nowrap">
                              <Clock className="w-3 h-3" />
                              {format(new Date(log.created_date), "dd/MM/yyyy HH:mm:ss", { locale: es })}
                            </div>
                          </div>

                          {/* Action Description */}
                          <div className="mt-3 pl-0 md:pl-13">
                            <p className="text-sm text-gray-700">{log.action_description}</p>
                            
                            {log.target_name && (
                              <div className="mt-2 flex items-center gap-2 text-xs text-gray-600">
                                <ChevronRight className="w-3 h-3" />
                                <span className="font-medium">Recurso:</span>
                                <span className="truncate">{log.target_name}</span>
                              </div>
                            )}

                            {log.metadata && Object.keys(log.metadata).length > 0 && (
                              <div className="mt-2 p-2 bg-gray-50 rounded text-xs">
                                <span className="font-medium text-gray-700">Detalles: </span>
                                <span className="text-gray-600">
                                  {JSON.stringify(log.metadata, null, 2)}
                                </span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
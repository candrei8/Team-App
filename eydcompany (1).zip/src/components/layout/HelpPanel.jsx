import React from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { HelpCircle, BookOpen, MessageCircle, Video, FileText, ExternalLink } from "lucide-react";

export default function HelpPanel() {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="hover:bg-[#E1E5F3] rounded-lg h-10 w-10">
          <HelpCircle className="w-5 h-5 text-[#676879]" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <div className="p-2">
          <p className="text-sm font-semibold px-2 py-1.5">Centro de Ayuda</p>
        </div>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem className="cursor-pointer">
          <BookOpen className="w-4 h-4 mr-3 text-gray-500" />
          <span>Guía de inicio rápido</span>
        </DropdownMenuItem>
        
        <DropdownMenuItem className="cursor-pointer">
          <Video className="w-4 h-4 mr-3 text-gray-500" />
          <span>Ver tutoriales en video</span>
        </DropdownMenuItem>
        
        <DropdownMenuItem className="cursor-pointer">
          <FileText className="w-4 h-4 mr-3 text-gray-500" />
          <span>Documentación</span>
        </DropdownMenuItem>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem className="cursor-pointer">
          <MessageCircle className="w-4 h-4 mr-3 text-gray-500" />
          <span>Contactar soporte</span>
        </DropdownMenuItem>
        
        <DropdownMenuItem className="cursor-pointer">
          <ExternalLink className="w-4 h-4 mr-3 text-gray-500" />
          <span>Base de conocimientos</span>
        </DropdownMenuItem>
        
        <DropdownMenuSeparator />
        
        <div className="p-2">
          <p className="text-xs text-gray-500 px-2">
            ¿Necesitas ayuda?<br />
            Estamos aquí para ti 24/7
          </p>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
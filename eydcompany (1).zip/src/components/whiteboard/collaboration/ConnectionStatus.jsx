import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Wifi, WifiOff, AlertCircle } from 'lucide-react';

export default function ConnectionStatus({ status }) {
  if (status === 'connected') return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -100, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className={`fixed top-0 left-0 right-0 z-50 flex items-center justify-center px-4 py-3 text-white text-sm font-medium shadow-lg ${
          status === 'connecting' || status === 'reconnecting'
            ? 'bg-yellow-500'
            : 'bg-red-500'
        }`}
      >
        <div className="flex items-center gap-2">
          {status === 'connecting' || status === 'reconnecting' ? (
            <>
              <WifiOff className="w-4 h-4 animate-pulse" />
              <span>
                {status === 'connecting' ? 'Conectando...' : 'Conexión perdida. Reconectando...'}
              </span>
            </>
          ) : (
            <>
              <AlertCircle className="w-4 h-4" />
              <span>Sin conexión. Trabajando en modo offline.</span>
            </>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
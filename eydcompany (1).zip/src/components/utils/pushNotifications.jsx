import { base44 } from '@/api/base44Client';

// CLAVE VAPID PÚBLICA (Placeholder)
const VAPID_PUBLIC_KEY = 'BMKP22iUYgUivxIkv69yViEuiBIa-Ib9-SkvMeAtA3LFgDzkrxZJjSgSnfckjBJuBkr3qBUYIHBQFLXYp5Nksh8';

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export async function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    try {
      // Usamos el truco del Blob porque no podemos servir /sw.js directamente
      // Nota: Esto limita el scope, pero funcionará para la página actual y subrutas si se carga en root layout
      // Mejor estrategia: Fetch el archivo de componente y crear blob
      // Sin embargo, en producción esto requiere que el archivo sea accesible via fetch. 
      // Como es un archivo JS en components, Webpack/Vite lo empaquetará. 
      // Necesitamos leerlo como texto crudo.
      // Alternativa simple: poner el código del SW en un string aquí mismo.
      
      const swCode = `
const CACHE_NAME = 'ed-company-v1';
self.addEventListener('install', (event) => { self.skipWaiting(); });
self.addEventListener('activate', (event) => { event.waitUntil(self.clients.claim()); });
self.addEventListener('push', (event) => {
  let notificationData = {
    title: 'Nueva Notificación',
    body: 'Tienes una nueva actualización',
    icon: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691331048c912041d25cea34/d90f3652c_E-DLOGOAZUL-640w.png',
    vibrate: [200, 100, 200],
    data: { url: '/', timestamp: Date.now() }
  };
  if (event.data) {
    try {
      const payload = event.data.json();
      notificationData = { ...notificationData, ...payload };
    } catch (e) {
      notificationData.body = event.data.text();
    }
  }
  self.registration.showNotification(notificationData.title, {
    body: notificationData.body,
    icon: notificationData.icon,
    vibrate: notificationData.vibrate,
    data: notificationData.data,
    actions: notificationData.actions || [{ action: 'open', title: 'Ver ahora' }]
  });
});
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  if (event.action === 'close') return;
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        for (let i = 0; i < clientList.length; i++) {
          const client = clientList[i];
          if (client.url === event.notification.data.url && 'focus' in client) return client.focus();
        }
        if (self.clients.openWindow) return self.clients.openWindow(event.notification.data.url || '/');
      })
  );
});
      `;
      
      const blob = new Blob([swCode], { type: 'application/javascript' });
      const swUrl = URL.createObjectURL(blob);
      
      const registration = await navigator.serviceWorker.register(swUrl, { scope: '/' });
      console.log('✓ Service Worker registrado via Blob');
      return registration;
    } catch (error) {
      console.error('Error al registrar Service Worker:', error);
      throw error;
    }
  }
}

export async function requestNotificationPermission() {
  if (!('Notification' in window)) return 'denied';
  const permission = await Notification.requestPermission();
  return permission;
}

export async function subscribeToPushNotifications(user) {
  try {
    const registration = await navigator.serviceWorker.ready;
    
    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
    });

    const ua = navigator.userAgent;
    let deviceType = 'Desktop';
    if (/Android/i.test(ua)) deviceType = 'Android';
    else if (/iPhone|iPad|iPod/i.test(ua)) deviceType = 'iOS';

    const subscriptionData = {
      endpoint: subscription.endpoint,
      keys: {
        p256dh: subscription.toJSON().keys.p256dh,
        auth: subscription.toJSON().keys.auth
      },
      user_email: user.email,
      device_info: {
        userAgent: ua,
        deviceType: deviceType
      },
      is_active: true,
      last_used: new Date().toISOString()
    };

    const existing = await base44.entities.PushSubscription.filter({
      endpoint: subscription.endpoint
    });

    if (existing.length > 0) {
      await base44.entities.PushSubscription.update(existing[0].id, {
        ...subscriptionData,
        updated_date: new Date().toISOString()
      });
    } else {
      await base44.entities.PushSubscription.create(subscriptionData);
    }

    return subscription;
  } catch (error) {
    console.error('Error al suscribirse a push:', error);
    throw error;
  }
}

export async function unsubscribeFromPushNotifications() {
  try {
    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.getSubscription();
    
    if (subscription) {
      const existing = await base44.entities.PushSubscription.filter({
        endpoint: subscription.endpoint
      });

      if (existing.length > 0) {
        await base44.entities.PushSubscription.update(existing[0].id, {
          is_active: false
        });
      }

      await subscription.unsubscribe();
    }
  } catch (error) {
    console.error('Error al desuscribirse:', error);
    throw error;
  }
}

export async function isPushNotificationSubscribed() {
  if (!('serviceWorker' in navigator)) return false;
  const registration = await navigator.serviceWorker.ready;
  const subscription = await registration.pushManager.getSubscription();
  return !!subscription;
}

export async function getUsersPushSubscriptions(userEmails) {
  const allActiveSubscriptions = await base44.entities.PushSubscription.filter({
    is_active: true
  });
  return allActiveSubscriptions.filter(sub => userEmails.includes(sub.user_email));
}

export async function showTestNotification() {
  const registration = await navigator.serviceWorker.ready;
  registration.showNotification('🔔 Notificación de Prueba', {
    body: '¡Las notificaciones push están funcionando correctamente!',
    icon: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691331048c912041d25cea34/d90f3652c_E-DLOGOAZUL-640w.png',
    vibrate: [200, 100, 200],
    data: {
      url: window.location.href
    }
  });
}
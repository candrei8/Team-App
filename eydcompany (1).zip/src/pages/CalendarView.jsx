import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Plus, 
  Filter,
  Clock,
  AlignJustify,
  Grid
} from "lucide-react";
import { 
  format, 
  addMonths, 
  subMonths, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  isSameMonth, 
  isSameDay, 
  addDays,
  subDays,
  isToday,
  parseISO,
  startOfDay,
  endOfDay,
  addWeeks,
  subWeeks,
  addHours,
  startOfHour
} from "date-fns";
import { es } from "date-fns/locale";
import { useToast } from "@/components/ui/use-toast";

// Components
import TodoList from "@/components/calendar/TodoList";
import CreateEventModal from "@/components/calendar/CreateEventModal";
import EventDetailsModal from "@/components/calendar/EventDetailsModal";
import CalendarIntegrationsModal from "@/components/calendar/CalendarIntegrationsModal";

export default function CalendarView() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState("month"); // month, week, day, agenda
  const [events, setEvents] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  
  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isIntegrationsModalOpen, setIsIntegrationsModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null); // For creating event on specific day
  const [selectedEvent, setSelectedEvent] = useState(null); // For viewing details
  const [selectedTask, setSelectedTask] = useState(null); // For viewing task details

  // Filters
  const [filterType, setFilterType] = useState("all"); // all, my, team

  const { toast } = useToast();

  useEffect(() => {
    // Check for OAuth callback
    const params = new URLSearchParams(window.location.search);
    const code = params.get("code");
    const provider = params.get("state")?.split('=')[1]; // state="provider=google"

    if (code && provider) {
      handleAuthCallback(code, provider);
    } else {
      loadData();
    }
  }, [currentDate, view]);

  const loadData = async () => {
    setLoading(true);
    try {
      const user = await base44.auth.me();
      setCurrentUser(user);

      // Calculate range based on view
      let start, end;
      if (view === 'month') {
        start = startOfWeek(startOfMonth(currentDate), { weekStartsOn: 1 });
        end = endOfWeek(endOfMonth(currentDate), { weekStartsOn: 1 });
      } else if (view === 'week') {
        start = startOfWeek(currentDate, { weekStartsOn: 1 });
        end = endOfWeek(currentDate, { weekStartsOn: 1 });
      } else {
        // Day or Agenda - fetch a bit wider range just in case
        start = startOfWeek(startOfMonth(currentDate), { weekStartsOn: 1 });
        end = endOfWeek(endOfMonth(currentDate), { weekStartsOn: 1 });
      }

      // Fetch Events
      // Note: In a real app we would filter by date range in the query
      // Here we fetch recently updated/created and filter in memory or assume backend filtering
      const allEvents = await base44.entities.CalendarEvent.list();
      const allTasks = await base44.entities.TodoTask.list();

      setEvents(allEvents);
      setTasks(allTasks);
    } catch (error) {
      console.error("Error loading calendar data:", error);
      toast({ title: "Error al cargar datos", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleAuthCallback = async (code, provider) => {
    setLoading(true);
    try {
      const redirectUri = window.location.origin + window.location.pathname;
      await base44.functions.invoke('calendarAuth', { 
        action: 'exchange', 
        code, 
        provider,
        redirect_uri: redirectUri
      });
      
      toast({ title: "Calendario conectado", description: "Sincronizando eventos..." });
      
      // Clear URL
      window.history.replaceState({}, document.title, window.location.pathname);
      
      // Trigger initial sync
      await base44.functions.invoke('calendarSync', {});
      loadData();
      
    } catch (error) {
      console.error("Auth Error:", error);
      toast({ title: "Error de conexión", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const navigate = (direction) => {
    if (view === 'month') {
      setCurrentDate(direction === 'next' ? addMonths(currentDate, 1) : subMonths(currentDate, 1));
    } else if (view === 'week') {
      setCurrentDate(direction === 'next' ? addWeeks(currentDate, 1) : subWeeks(currentDate, 1));
    } else {
      setCurrentDate(direction === 'next' ? addDays(currentDate, 1) : subDays(currentDate, 1));
    }
  };

  const handleDateClick = (day) => {
    setSelectedDate(day);
    setIsCreateModalOpen(true);
  };

  const handleEventClick = (e, event) => {
    e.stopPropagation();
    setSelectedEvent(event);
    setSelectedTask(null);
  };

  const handleTaskClick = (task) => {
    setSelectedTask(task);
    setSelectedEvent(null);
  };

  // Filter logic
  const getFilteredEvents = () => {
    return events.filter(event => {
      // Basic date range check could go here
      
      if (filterType === 'my') {
        return event.created_by === currentUser?.email || event.attendees?.includes(currentUser?.email);
      }
      if (filterType === 'team') {
        return event.visibility === 'team' || event.visibility === 'public' || event.created_by === currentUser?.email;
      }
      return true; // all
    });
  };

  const getFilteredTasks = () => {
    return tasks.filter(task => {
      if (task.status === 'done' && view !== 'agenda') return false; // Hide completed tasks in calendar view usually
      if (filterType === 'my') {
        return task.assigned_to === currentUser?.email;
      }
      return true;
    });
  };

  // Render helpers
  const renderMonthCell = (day) => {
    const dayEvents = getFilteredEvents().filter(e => isSameDay(parseISO(e.start_date), day));
    const dayTasks = getFilteredTasks().filter(t => t.due_date && isSameDay(parseISO(t.due_date), day));
    const isCurrentMonth = isSameMonth(day, currentDate);

    return (
      <div 
        key={day.toString()} 
        className={`min-h-[100px] border border-gray-100 p-1 hover:bg-gray-50 transition-colors cursor-pointer flex flex-col gap-1 ${!isCurrentMonth ? 'bg-gray-50/50 text-gray-400' : 'bg-white'}`}
        onClick={() => handleDateClick(day)}
      >
        <div className={`text-right text-sm mb-1 px-1 ${isToday(day) ? 'font-bold text-blue-600' : ''}`}>
          {format(day, "d")}
        </div>
        
        {/* Events */}
        {dayEvents.map(event => (
          <div 
            key={event.id}
            onClick={(e) => handleEventClick(e, event)}
            className={`text-xs px-1.5 py-0.5 rounded truncate text-white cursor-pointer hover:opacity-90`}
            style={{ backgroundColor: event.color || '#3b82f6' }}
          >
            {format(parseISO(event.start_date), "HH:mm")} {event.title}
          </div>
        ))}

        {/* Tasks */}
        {dayTasks.map(task => (
          <div 
            key={task.id}
            onClick={(e) => { e.stopPropagation(); handleTaskClick(task); }}
            className="text-xs px-1.5 py-0.5 rounded truncate bg-white border border-gray-200 text-gray-700 flex items-center gap-1 hover:border-blue-300"
          >
            <div className={`w-1.5 h-1.5 rounded-full ${task.priority === 'high' ? 'bg-red-500' : 'bg-green-500'}`} />
            {task.title}
          </div>
        ))}
      </div>
    );
  };

  const renderMonthView = () => {
    const start = startOfWeek(startOfMonth(currentDate), { weekStartsOn: 1 });
    const end = endOfWeek(endOfMonth(currentDate), { weekStartsOn: 1 });
    const days = eachDayOfInterval({ start, end });

    const weekDays = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];

    return (
      <div className="flex flex-col h-full overflow-hidden">
        <div className="grid grid-cols-7 mb-2">
          {weekDays.map(d => (
            <div key={d} className="text-center text-sm font-semibold text-gray-500 py-2">
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 flex-1 overflow-y-auto">
          {days.map(day => renderMonthCell(day))}
        </div>
      </div>
    );
  };

  const renderWeekView = () => {
    const start = startOfWeek(currentDate, { weekStartsOn: 1 });
    const end = endOfWeek(currentDate, { weekStartsOn: 1 });
    const days = eachDayOfInterval({ start, end });
    const hours = Array.from({ length: 24 }, (_, i) => i);

    return (
      <div className="flex flex-col h-full overflow-hidden bg-white rounded-lg border">
        <div className="grid grid-cols-8 border-b bg-gray-50">
          <div className="p-2 border-r"></div>
          {days.map(day => (
            <div key={day.toString()} className={`p-2 text-center border-r font-medium ${isToday(day) ? 'text-blue-600' : ''}`}>
              <div className="text-xs uppercase">{format(day, "EEE", { locale: es })}</div>
              <div className="text-lg">{format(day, "d")}</div>
            </div>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto">
          {hours.map(hour => (
            <div key={hour} className="grid grid-cols-8 min-h-[60px]">
              <div className="p-2 border-r border-b text-xs text-gray-400 text-right sticky left-0 bg-white">
                {hour}:00
              </div>
              {days.map(day => {
                // Find events starting in this hour
                const hourEvents = getFilteredEvents().filter(e => {
                  const eventStart = parseISO(e.start_date);
                  return isSameDay(eventStart, day) && eventStart.getHours() === hour;
                });

                return (
                  <div 
                    key={day.toString() + hour} 
                    className="border-r border-b relative group hover:bg-gray-50 transition-colors"
                    onClick={() => {
                      const d = new Date(day);
                      d.setHours(hour);
                      handleDateClick(d);
                    }}
                  >
                    {hourEvents.map(event => (
                      <div
                        key={event.id}
                        onClick={(e) => handleEventClick(e, event)}
                        className="absolute left-1 right-1 top-1 p-1 rounded text-xs text-white overflow-hidden z-10 shadow-sm hover:z-20 hover:shadow-md transition-all"
                        style={{ 
                          backgroundColor: event.color || '#3b82f6',
                          height: 'calc(100% - 4px)' // Simple fixed height for now
                        }}
                      >
                        <div className="font-semibold">{event.title}</div>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderAgendaView = () => {
    // Group by day
    const allItems = [
      ...getFilteredEvents().map(e => ({ ...e, _date: parseISO(e.start_date), _type: 'event' })),
      ...getFilteredTasks().filter(t => t.due_date).map(t => ({ ...t, _date: parseISO(t.due_date), _type: 'task' }))
    ].sort((a, b) => a._date - b._date);

    return (
      <div className="bg-white rounded-lg border h-full overflow-y-auto p-4">
        {allItems.length === 0 && (
          <div className="text-center text-gray-500 py-10">No hay eventos ni tareas próximos.</div>
        )}
        {allItems.map(item => (
          <div key={item.id} className="flex gap-4 mb-6 group">
            <div className="w-16 text-center flex-shrink-0">
              <div className="text-xs font-bold text-gray-500 uppercase">{format(item._date, "MMM", { locale: es })}</div>
              <div className="text-2xl font-bold text-gray-800">{format(item._date, "d")}</div>
              <div className="text-xs text-gray-400">{format(item._date, "EEE", { locale: es })}</div>
            </div>
            <div 
              className={`flex-1 p-3 rounded-lg border border-l-4 cursor-pointer hover:shadow-md transition-all ${
                item._type === 'event' ? 'border-l-blue-500 bg-blue-50/30' : 'border-l-green-500 bg-white'
              }`}
              onClick={() => item._type === 'event' ? setSelectedEvent(item) : setSelectedTask(item)}
            >
              <div className="flex justify-between items-start">
                <h4 className={`font-bold ${item._type === 'task' && item.status === 'done' ? 'line-through text-gray-500' : ''}`}>
                  {item.title}
                </h4>
                <div className="text-xs text-gray-500 bg-white/50 px-2 py-1 rounded">
                  {item._type === 'event' 
                    ? `${format(item._date, "HH:mm")} - ${format(parseISO(item.end_date), "HH:mm")}`
                    : "Tarea"
                  }
                </div>
              </div>
              {item.description && <p className="text-sm text-gray-600 mt-1 line-clamp-2">{item.description}</p>}
              {item._type === 'event' && item.location && (
                <div className="text-xs text-gray-500 mt-2 flex items-center gap-1">
                  <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                  {item.location}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="hidden lg:block w-80 flex-shrink-0 border-r bg-white">
        <TodoList 
          tasks={tasks} 
          onTaskClick={handleTaskClick}
          onTaskUpdate={loadData}
          currentUser={currentUser}
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <div className="bg-white border-b p-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Button variant="outline" size="icon" onClick={() => navigate('prev')}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" onClick={() => setCurrentDate(new Date())}>
                Hoy
              </Button>
              <Button variant="outline" size="icon" onClick={() => navigate('next')}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
            <h2 className="text-xl font-bold capitalize text-gray-800">
              {format(currentDate, view === 'month' ? "MMMM yyyy" : "d MMMM yyyy", { locale: es })}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setIsIntegrationsModalOpen(true)}
              className="hidden md:flex text-gray-600"
            >
              <Grid className="w-4 h-4 mr-2" />
              Conectar Calendarios
            </Button>

            <div className="h-6 w-px bg-gray-200 mx-1 hidden md:block"></div>

            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[140px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="my">Mis Eventos</SelectItem>
                <SelectItem value="team">Equipo</SelectItem>
              </SelectContent>
            </Select>

            <div className="h-6 w-px bg-gray-200 mx-1"></div>

            <Tabs value={view} onValueChange={setView} className="w-auto">
              <TabsList>
                <TabsTrigger value="month" className="hidden sm:flex"><CalendarIcon className="w-4 h-4 mr-2" />Mes</TabsTrigger>
                <TabsTrigger value="week" className="hidden sm:flex"><Grid className="w-4 h-4 mr-2" />Semana</TabsTrigger>
                <TabsTrigger value="agenda" className="hidden sm:flex"><AlignJustify className="w-4 h-4 mr-2" />Agenda</TabsTrigger>
                
                {/* Mobile icons only */}
                <TabsTrigger value="month" className="sm:hidden"><CalendarIcon className="w-4 h-4" /></TabsTrigger>
                <TabsTrigger value="week" className="sm:hidden"><Grid className="w-4 h-4" /></TabsTrigger>
                <TabsTrigger value="agenda" className="sm:hidden"><AlignJustify className="w-4 h-4" /></TabsTrigger>
              </TabsList>
            </Tabs>

            <Button onClick={() => { setSelectedDate(new Date()); setIsCreateModalOpen(true); }}>
              <Plus className="w-4 h-4 mr-2" />
              Nuevo
            </Button>
          </div>
        </div>

        {/* Calendar Grid */}
        <div className="flex-1 p-4 overflow-hidden">
          {view === 'month' && renderMonthView()}
          {view === 'week' && renderWeekView()}
          {view === 'agenda' && renderAgendaView()}
        </div>
      </div>

      {/* Modals */}
      <CreateEventModal 
        isOpen={isCreateModalOpen} 
        onClose={() => setIsCreateModalOpen(false)}
        selectedDate={selectedDate}
        currentUser={currentUser}
        onEventCreated={loadData}
      />

      <CalendarIntegrationsModal
        isOpen={isIntegrationsModalOpen}
        onClose={() => setIsIntegrationsModalOpen(false)}
        currentUser={currentUser}
      />

      {(selectedEvent || selectedTask) && (
        <EventDetailsModal 
          isOpen={!!(selectedEvent || selectedTask)}
          onClose={() => { setSelectedEvent(null); setSelectedTask(null); }}
          event={selectedEvent || selectedTask}
          isTask={!!selectedTask}
          onUpdate={() => { loadData(); if(!selectedTask) setSelectedEvent(null); }}
          onDelete={() => { loadData(); setSelectedEvent(null); setSelectedTask(null); }}
        />
      )}
    </div>
  );
}
import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, UserPlus, UserMinus, AtSign, Trash2 } from 'lucide-react';

const TOAST_ICONS = {
  user_join: UserPlus,
  user_leave: UserMinus,
  mention: AtSign,
  element_deleted: Trash2
};

export default function CollaborationToast({ toasts, onDismiss }) {
  useEffect(() => {
    toasts.forEach(toast => {
      if (toast.id) {
        const timer = setTimeout(() => {
          onDismiss(toast.id);
        }, toast.duration || 3000);

        return () => clearTimeout(timer);
      }
    });
  }, [toasts, onDismiss]);

  return (
    <div className="fixed bottom-6 right-6 z-50 space-y-2">
      <AnimatePresence>
        {toasts.map((toast) => {
          const Icon = TOAST_ICONS[toast.type];
          
          return (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, x: 100, scale: 0.8 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 100, scale: 0.8 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="bg-white rounded-lg shadow-lg border border-gray-200 p-4 min-w-[300px] max-w-md"
              onClick={toast.onClick}
              style={{ cursor: toast.onClick ? 'pointer' : 'default' }}
            >
              <div className="flex items-start gap-3">
                {Icon && (
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                )}
                
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">
                    {toast.title}
                  </p>
                  {toast.description && (
                    <p className="text-xs text-gray-600 mt-1">
                      {toast.description}
                    </p>
                  )}
                  {toast.onClick && (
                    <p className="text-xs text-blue-600 mt-2">
                      Click para ver
                    </p>
                  )}
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDismiss(toast.id);
                  }}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Barra de progreso */}
              <motion.div
                className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-b-lg"
                initial={{ width: '100%' }}
                animate={{ width: '0%' }}
                transition={{ duration: (toast.duration || 3000) / 1000, ease: 'linear' }}
              />
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
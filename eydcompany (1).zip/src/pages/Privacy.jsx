import React from "react";
import { ArrowLeft, Shield, Lock, Eye, FileText, Database } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link to="/">
            <Button variant="ghost" className="pl-0 hover:pl-2 transition-all -ml-4 text-gray-600 hover:text-gray-900">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver a la aplicación
            </Button>
          </Link>
        </div>

        <Card className="bg-white shadow-lg border-0 overflow-hidden">
          <div className="h-2 bg-gradient-to-r from-blue-500 to-indigo-600"></div>
          <CardContent className="p-8 sm:p-12">
            <div className="border-b border-gray-100 pb-8 mb-8">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-3 bg-blue-50 rounded-xl">
                  <Shield className="w-8 h-8 text-blue-600" />
                </div>
                <h1 className="text-3xl sm:text-4xl font-bold text-gray-900">Política de Privacidad</h1>
              </div>
              <p className="text-gray-500 flex items-center gap-2 text-sm">
                <ClockIcon className="w-4 h-4" />
                Última actualización: {new Date().toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>

            <div className="space-y-10 text-gray-600 leading-relaxed">
              <section>
                <div className="flex items-center gap-2 mb-4">
                  <Database className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-bold text-gray-900">1. Responsable del tratamiento de datos</h2>
                </div>
                <p className="mb-4">
                  E&D Company es el responsable del tratamiento de los datos personales que se recogen y tratan a través de esta aplicación. 
                  Nos comprometemos a proteger su privacidad y a cumplir con la normativa vigente en materia de protección de datos (RGPD).
                </p>
                <div className="bg-gray-50 p-4 rounded-lg text-sm border border-gray-100">
                  <p><strong>Contacto:</strong> ia@eydcomapny.com</p>
                  <p><strong>Dirección:</strong> Calle Velazquez, 46, 28001 Madrid</p>
                </div>
              </section>

              <section>
                <div className="flex items-center gap-2 mb-4">
                  <FileText className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-bold text-gray-900">2. Finalidad de los datos</h2>
                </div>
                <p className="mb-4">Recopilamos y tratamos sus datos estrictamente para las siguientes finalidades:</p>
                <ul className="grid sm:grid-cols-2 gap-4">
                  {[
                    "Gestión de proyectos y tareas colaborativas",
                    "Comunicación entre miembros del equipo",
                    "Procesamiento de facturación y pagos",
                    "Gestión de entregas y aprobaciones",
                    "Mejora de la experiencia de usuario",
                    "Seguridad y prevención de fraude"
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-50 mt-2 shrink-0"></div>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </section>

              <section>
                <div className="flex items-center gap-2 mb-4">
                  <Eye className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-bold text-gray-900">3. Derechos del usuario</h2>
                </div>
                <p className="mb-4">
                  Como usuario, usted tiene control total sobre sus datos. Puede ejercer los siguientes derechos en cualquier momento:
                </p>
                <div className="grid sm:grid-cols-3 gap-4 text-sm">
                  <div className="p-4 rounded-lg bg-blue-50 border border-blue-100">
                    <strong className="block text-blue-900 mb-1">Acceso</strong>
                    Conocer qué datos tenemos sobre usted.
                  </div>
                  <div className="p-4 rounded-lg bg-blue-50 border border-blue-100">
                    <strong className="block text-blue-900 mb-1">Rectificación</strong>
                    Corregir datos inexactos o incompletos.
                  </div>
                  <div className="p-4 rounded-lg bg-blue-50 border border-blue-100">
                    <strong className="block text-blue-900 mb-1">Cancelación</strong>
                    Solicitar la eliminación de sus datos.
                  </div>
                </div>
              </section>

              <section>
                <div className="flex items-center gap-2 mb-4">
                  <Lock className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-bold text-gray-900">4. Seguridad de los datos</h2>
                </div>
                <p>
                  Implementamos medidas de seguridad técnicas y organizativas de alto nivel para proteger sus datos contra el acceso no autorizado, 
                  la pérdida o la destrucción. Utilizamos encriptación SSL/TLS estándar de la industria para toda la transmisión de datos y
                  almacenamiento seguro en servidores certificados.
                </p>
              </section>
            </div>
            
            <div className="mt-12 pt-8 border-t border-gray-100 text-center">
              <p className="text-sm text-gray-500">
                Si tiene preguntas sobre esta política, por favor contáctenos a través de nuestro canal de soporte.
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 text-center text-sm text-gray-400 flex justify-center gap-6">
          <span>&copy; {new Date().getFullYear()} E&D Company</span>
          <Link to="/" className="hover:text-gray-600 transition-colors">Términos de Servicio</Link>
          <Link to="/Privacy" className="hover:text-gray-600 transition-colors">Privacidad</Link>
        </div>
      </div>
    </div>
  );
}

function ClockIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  )
}
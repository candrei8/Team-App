import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Users,
  Shield,
  Folder,
  Bell,
  Megaphone,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  Ban,
  Activity,
  FileText,
  History
} from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useToast } from "@/components/ui/use-toast";

import AnnounceModal from "../components/admin/AnnounceModal";
import { getUsersPushSubscriptions } from "@/components/utils/pushNotifications";

export default function AdminPanel() {
  const [users, setUsers] = useState([]);
  const [boards, setBoards] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showAnnounceModal, setShowAnnounceModal] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const userData = await base44.auth.me();
      setCurrentUser(userData);

      if (userData.role !== "admin") {
        navigate(createPageUrl("Dashboard"));
        return;
      }

      const [usersData, boardsData, notificationsData] = await Promise.all([
        base44.entities.User.list("-created_date"),
        base44.entities.Board.list("-created_date"),
        base44.entities.Notification.list("-created_date", 10)
      ]);

      setUsers(usersData);
      setBoards(boardsData);
      setNotifications(notificationsData);
    } catch (error) {
      console.error("Error al cargar datos:", error);
      toast({
        title: "Error",
        description: "No se pudieron cargar los datos del panel",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  const handleSendAnnouncement = async (announcementData) => {
    const { title, message, sendEmail, targetType, targetValue, attachments } = announcementData;

    try {
      let targetUsers = [];

      // Determinar destinatarios
      if (targetType === "all") {
        targetUsers = users.filter(u => u.status === "active");
      } else if (targetType === "user") {
        targetUsers = users.filter(u => u.email === targetValue && u.status === "active");
      } else if (targetType === "department") {
        targetUsers = users.filter(u => u.department === targetValue && u.status === "active");
      }

      let successCount = 0;
      let errorCount = 0;

      // Preparar metadata con archivos adjuntos
      const metadata = attachments.length > 0 ? { attachments } : {};

      // Enviar notificaciones push
      for (const user of targetUsers) {
        try {
          await base44.entities.Notification.create({
            user_email: user.email,
            title: title,
            message: message,
            type: "system",
            priority: "high",
            is_read: false,
            metadata: metadata
          });
          successCount++;
        } catch (error) {
          console.error(`Error enviando a ${user.email}:`, error);
          errorCount++;
        }
      }

      // ---------------------------------------------------------
      // Enviar Notificaciones Push (Integración Backend)
      // ---------------------------------------------------------
      try {
        const targetEmails = targetUsers.map(u => u.email);
        const pushSubscriptions = await getUsersPushSubscriptions(targetEmails);
        
        console.log(`📢 Enviando push a ${pushSubscriptions.length} dispositivos...`);

        const pushPayload = {
          title: `📢 ${title}`,
          message: message,
          body: message,
          icon: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691331048c912041d25cea34/d90f3652c_E-DLOGOAZUL-640w.png',
          badge: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691331048c912041d25cea34/d90f3652c_E-DLOGOAZUL-640w.png',
          tag: `announcement-${Date.now()}`,
          requireInteraction: true,
          data: {
            url: '/',
            type: 'announcement',
            timestamp: new Date().toISOString()
          },
          actions: [
            { action: 'open', title: 'Ver ahora' },
            { action: 'close', title: 'Cerrar' }
          ]
        };

        let pushSentCount = 0;
        
        // Nota: Esto requiere la integración de backend 'SendPushNotification'
        // Si no está habilitada, fallará silenciosamente o logueará error.
        if (base44.integrations?.Core?.SendPushNotification) {
           for (const subscription of pushSubscriptions) {
              try {
                await base44.integrations.Core.SendPushNotification({
                  subscription: {
                    endpoint: subscription.endpoint,
                    keys: subscription.keys
                  },
                  payload: JSON.stringify(pushPayload)
                });
                pushSentCount++;
              } catch (err) {
                console.error('Error enviando push individual:', err);
              }
           }
           if (pushSentCount > 0) {
             toast({ title: `✓ ${pushSentCount} notificaciones push enviadas` });
           }
        } else {
           console.warn('⚠️ Integración SendPushNotification no disponible en backend.');
           // Fallback: Crear notificación local para que el usuario vea que "algo pasó" si está probando
           // (Solo para demo/testing si el usuario actual es parte del target)
           if (targetEmails.includes(currentUser.email)) {
              if ('serviceWorker' in navigator) {
                 const reg = await navigator.serviceWorker.ready;
                 reg.showNotification(pushPayload.title, pushPayload);
              }
           }
        }
      } catch (pushError) {
        console.error('Error en proceso push:', pushError);
      }

      // Enviar emails si está activado
      if (sendEmail) {
        for (const user of targetUsers) {
          try {
            // Preparar contenido del email con archivos adjuntos
            let emailBody = message;
            if (attachments.length > 0) {
              emailBody += '\n\n📎 Archivos adjuntos:\n';
              attachments.forEach(file => {
                emailBody += `- ${file.name}: ${file.url}\n`;
              });
            }

            await base44.integrations.Core.SendEmail({
              to: user.email,
              subject: `📢 Anuncio: ${title}`,
              body: emailBody,
              from_name: "E&D Company - Admin"
            });
          } catch (error) {
            console.error(`Error enviando email a ${user.email}:`, error);
          }
        }
      }

      // Mostrar resultado
      let targetDescription = "";
      if (targetType === "all") {
        targetDescription = "todos los usuarios";
      } else if (targetType === "user") {
        const user = users.find(u => u.email === targetValue);
        targetDescription = user?.full_name || targetValue;
      } else if (targetType === "department") {
        targetDescription = `departamento de ${targetValue}`;
      }

      toast({
        title: "✓ Anuncio enviado",
        description: `Enviado a ${targetDescription}${sendEmail ? ' (push + email)' : ' (push)'}. ${successCount} exitosos, ${errorCount} errores.`
      });

      setShowAnnounceModal(false);
      loadData();
    } catch (error) {
      console.error("Error al enviar anuncio:", error);
      toast({
        title: "Error",
        description: "No se pudo enviar el anuncio",
        variant: "destructive"
      });
    }
  };

  const activeUsers = users.filter(u => u.status === "active");
  const pendingUsers = users.filter(u => u.status === "pending" || !u.status);
  const suspendedUsers = users.filter(u => u.status === "suspended");

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F6F8]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0073EA] mx-auto mb-4"></div>
          <p className="text-[#676879]">Cargando panel de administración...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#F5F6F8] min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-[#323338] flex items-center gap-3">
              <Shield className="w-8 h-8 text-purple-600" />
              Panel de Administración
            </h1>
            <p className="text-[#676879] mt-1">
              Gestiona usuarios, proyectos y comunicaciones
            </p>
          </div>
          <Button
            onClick={() => setShowAnnounceModal(true)}
            className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-lg"
          >
            <Megaphone className="w-4 h-4 mr-2" />
            Enviar Anuncio
          </Button>
        </div>

        {/* Alerta de usuarios pendientes */}
        {pendingUsers.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-lg"
          >
            <div className="flex items-start gap-3">
              <Clock className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <h3 className="font-semibold text-amber-900">
                  {pendingUsers.length} usuario{pendingUsers.length !== 1 ? 's' : ''} pendiente{pendingUsers.length !== 1 ? 's' : ''} de aprobación
                </h3>
                <p className="text-sm text-amber-700 mt-1">
                  Revisa y aprueba las solicitudes de acceso en la sección de Usuarios
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate(createPageUrl("Users"))}
                className="border-amber-300 text-amber-700 hover:bg-amber-100"
              >
                Ver usuarios
              </Button>
            </div>
          </motion.div>
        )}

        {/* Stats Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0 }}
          >
            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 border-0 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100 text-sm font-medium mb-2">Total Usuarios</p>
                    <p className="text-4xl font-bold">{users.length}</p>
                  </div>
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="bg-gradient-to-br from-green-500 to-green-600 border-0 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100 text-sm font-medium mb-2">Usuarios Activos</p>
                    <p className="text-4xl font-bold">{activeUsers.length}</p>
                  </div>
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <CheckCircle className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gradient-to-br from-amber-500 to-orange-500 border-0 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-amber-100 text-sm font-medium mb-2">Pendientes</p>
                    <p className="text-4xl font-bold">{pendingUsers.length}</p>
                  </div>
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <Clock className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gradient-to-br from-purple-500 to-purple-600 border-0 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100 text-sm font-medium mb-2">Total Proyectos</p>
                    <p className="text-4xl font-bold">{boards.length}</p>
                  </div>
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <Folder className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Acciones Rápidas */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-[#0073EA]" />
                  Acciones Rápidas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  variant="outline"
                  className="w-full justify-start h-auto py-3"
                  onClick={() => navigate(createPageUrl("Users"))}
                >
                  <Users className="w-5 h-5 mr-3 text-blue-600" />
                  <div className="text-left">
                    <p className="font-medium">Gestionar Usuarios</p>
                    <p className="text-xs text-gray-500">Aprobar, suspender y administrar</p>
                  </div>
                </Button>

                <Button
                  variant="outline"
                  className="w-full justify-start h-auto py-3"
                  onClick={() => setShowAnnounceModal(true)}
                >
                  <Megaphone className="w-5 h-5 mr-3 text-purple-600" />
                  <div className="text-left">
                    <p className="font-medium">Enviar Anuncio</p>
                    <p className="text-xs text-gray-500">Comunicación global o específica</p>
                  </div>
                </Button>

                <Button
                  variant="outline"
                  className="w-full justify-start h-auto py-3"
                  onClick={() => navigate(createPageUrl("Boards"))}
                >
                  <Folder className="w-5 h-5 mr-3 text-green-600" />
                  <div className="text-left">
                    <p className="font-medium">Ver Todos los Proyectos</p>
                    <p className="text-xs text-gray-500">Acceso a todos los boards</p>
                  </div>
                </Button>

                <Button
                  variant="outline"
                  className="w-full justify-start h-auto py-3"
                  onClick={() => navigate(createPageUrl("Analytics"))}
                >
                  <Activity className="w-5 h-5 mr-3 text-orange-600" />
                  <div className="text-left">
                    <p className="font-medium">Ver Analíticas</p>
                    <p className="text-xs text-gray-500">Métricas y estadísticas</p>
                  </div>
                </Button>

                <Button
                  variant="outline"
                  className="w-full justify-start h-auto py-3"
                  onClick={() => navigate(createPageUrl("GuestRecords"))}
                >
                  <FileText className="w-5 h-5 mr-3 text-indigo-600" />
                  <div className="text-left">
                    <p className="font-medium">Expedientes de Invitados</p>
                    <p className="text-xs text-gray-500">Gestionar solicitudes y propuestas</p>
                  </div>
                </Button>

                <Button
                  variant="outline"
                  className="w-full justify-start h-auto py-3 border-purple-200 bg-purple-50 hover:bg-purple-100"
                  onClick={() => navigate(createPageUrl("AuditLogs"))}
                >
                  <History className="w-5 h-5 mr-3 text-purple-600" />
                  <div className="text-left">
                    <p className="font-medium text-purple-900">Registro de Auditoría</p>
                    <p className="text-xs text-purple-700">Historial completo de actividad</p>
                  </div>
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          {/* Estado del Sistema */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-[#0073EA]" />
                  Estado del Sistema
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <div>
                      <p className="font-medium text-green-900">Sistema Operativo</p>
                      <p className="text-sm text-green-700">Todos los servicios funcionando</p>
                    </div>
                  </div>
                  <Badge className="bg-green-600 text-white">OK</Badge>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between py-2 border-b">
                    <span className="text-sm text-gray-600">Usuarios Activos</span>
                    <span className="font-semibold">{activeUsers.length}</span>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b">
                    <span className="text-sm text-gray-600">Usuarios Pendientes</span>
                    <Badge variant={pendingUsers.length > 0 ? "default" : "secondary"}>
                      {pendingUsers.length}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b">
                    <span className="text-sm text-gray-600">Usuarios Suspendidos</span>
                    <Badge variant={suspendedUsers.length > 0 ? "destructive" : "secondary"}>
                      {suspendedUsers.length}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <span className="text-sm text-gray-600">Proyectos Totales</span>
                    <span className="font-semibold">{boards.length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      {/* Announce Modal */}
      <AnnounceModal
        isOpen={showAnnounceModal}
        onClose={() => setShowAnnounceModal(false)}
        onSubmit={handleSendAnnouncement}
      />
    </div>
  );
}
import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User, Briefcase, CreditCard, Building, Save, Upload } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function InvitadoProfile() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState({
    bio: "",
    specialty: "",
    phone: "",
    address: "",
    tax_id: "",
    bank_account: "",
    portfolio_url: "",
    company: "",
    position: ""
  });
  
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      
      const profileData = await base44.entities.GuestProfile.filter({ user_email: userData.email });
      if (profileData && profileData.length > 0) {
        setProfile(profileData[0]);
      } else {
        // Initialize empty profile locally if not exists
        setProfile(prev => ({ ...prev, user_email: userData.email }));
      }
    } catch (error) {
      console.error("Error loading profile:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const existing = await base44.entities.GuestProfile.filter({ user_email: user.email });
      
      if (existing && existing.length > 0) {
        await base44.entities.GuestProfile.update(existing[0].id, profile);
      } else {
        await base44.entities.GuestProfile.create({ ...profile, user_email: user.email });
      }
      
      toast({
        title: "Perfil actualizado",
        description: "Tus datos se han guardado correctamente.",
        className: "bg-green-50 border-green-200 text-green-800"
      });
    } catch (error) {
      console.error("Error saving profile:", error);
      toast({
        title: "Error",
        description: "No se pudieron guardar los cambios.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div>Cargando perfil...</div>;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Mi Perfil</h1>
        <Button onClick={handleSave} disabled={saving} className="bg-indigo-600 hover:bg-indigo-700 text-white">
          {saving ? "Guardando..." : <><Save className="w-4 h-4 mr-2" /> Guardar Cambios</>}
        </Button>
      </div>

      <Tabs defaultValue="account" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-white border border-gray-200 h-12 p-1 mb-6">
          <TabsTrigger value="account" className="data-[state=active]:bg-indigo-50 data-[state=active]:text-indigo-700">
            <User className="w-4 h-4 mr-2" /> Datos de Cuenta
          </TabsTrigger>
          <TabsTrigger value="fiscal" className="data-[state=active]:bg-indigo-50 data-[state=active]:text-indigo-700">
            <Building className="w-4 h-4 mr-2" /> Datos Fiscales y Bancarios
          </TabsTrigger>
          <TabsTrigger value="professional" className="data-[state=active]:bg-indigo-50 data-[state=active]:text-indigo-700">
            <Briefcase className="w-4 h-4 mr-2" /> Perfil Profesional
          </TabsTrigger>
        </TabsList>

        <TabsContent value="account">
          <Card className="bg-white border-gray-200 shadow-sm">
            <CardHeader>
              <CardTitle>Información de la Cuenta</CardTitle>
              <CardDescription>Tus datos básicos de acceso y contacto.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nombre Completo</Label>
                  <Input value={user?.full_name || ""} disabled className="bg-gray-50" />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input value={user?.email || ""} disabled className="bg-gray-50" />
                </div>
                <div className="space-y-2">
                  <Label>Teléfono</Label>
                  <Input name="phone" value={profile.phone || ""} onChange={handleChange} placeholder="+34 000 000 000" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fiscal">
          <Card className="bg-white border-gray-200 shadow-sm">
            <CardHeader>
              <CardTitle>Datos de Facturación</CardTitle>
              <CardDescription>Información necesaria para emitir facturas y recibir pagos.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="font-medium text-gray-900 border-b pb-2">Información Fiscal</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>NIF / CIF / ID Fiscal</Label>
                    <Input name="tax_id" value={profile.tax_id || ""} onChange={handleChange} placeholder="12345678Z" />
                  </div>
                  <div className="space-y-2">
                    <Label>Razón Social / Empresa</Label>
                    <Input name="company" value={profile.company || ""} onChange={handleChange} placeholder="Nombre o Empresa" />
                  </div>
                  <div className="col-span-2 space-y-2">
                    <Label>Dirección de Facturación</Label>
                    <Input name="address" value={profile.address || ""} onChange={handleChange} placeholder="Calle Principal 123, Ciudad, CP" />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="font-medium text-gray-900 border-b pb-2">Datos Bancarios</h3>
                <div className="space-y-2">
                  <Label>Cuenta Bancaria (IBAN)</Label>
                  <div className="relative">
                    <CreditCard className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input name="bank_account" value={profile.bank_account || ""} onChange={handleChange} className="pl-10 font-mono" placeholder="ES00 0000 0000 0000 0000 0000" />
                  </div>
                  <p className="text-xs text-gray-500">Esta cuenta se usará para realizar las transferencias de tus facturas aprobadas.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="professional">
          <Card className="bg-white border-gray-200 shadow-sm">
            <CardHeader>
              <CardTitle>Perfil Profesional</CardTitle>
              <CardDescription>Información sobre tu experiencia y especialidad.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Especialidad</Label>
                  <Input name="specialty" value={profile.specialty || ""} onChange={handleChange} placeholder="Ej. Diseño UX/UI, Desarrollo Frontend..." />
                </div>
                <div className="space-y-2">
                  <Label>Cargo / Rol</Label>
                  <Input name="position" value={profile.position || ""} onChange={handleChange} placeholder="Ej. Senior Designer" />
                </div>
                <div className="col-span-2 space-y-2">
                  <Label>Enlace al Portfolio / LinkedIn</Label>
                  <Input name="portfolio_url" value={profile.portfolio_url || ""} onChange={handleChange} placeholder="https://..." />
                </div>
                <div className="col-span-2 space-y-2">
                  <Label>Bio / Resumen Profesional</Label>
                  <Textarea name="bio" value={profile.bio || ""} onChange={handleChange} placeholder="Breve descripción de tu perfil..." className="min-h-[100px]" />
                </div>
              </div>
              
              {/* CV Upload Placeholder - Simplified functionality */}
              <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 flex flex-col items-center justify-center text-center">
                <Upload className="w-8 h-8 text-gray-400 mb-2" />
                <p className="text-sm font-medium text-gray-900">Subir CV actualizado (PDF)</p>
                <p className="text-xs text-gray-500 mb-4">Máx. 5MB</p>
                <Button variant="outline" size="sm">Seleccionar Archivo</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
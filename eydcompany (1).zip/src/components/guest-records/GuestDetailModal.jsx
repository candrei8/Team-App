import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
    User, 
    FileText, 
    CheckCircle, 
    XCircle, 
    Clock,
    Download,
    ExternalLink,
    Mail,
    Activity,
    DollarSign,
    Ban,
    AlertCircle
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/components/ui/use-toast";

export default function GuestDetailModal({ isOpen, onClose, profile, onStatusChange }) {
  const [submissions, setSubmissions] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [activities, setActivities] = useState([]);
  const [loadingData, setLoadingData] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen && profile) {
      loadRelatedData();
    }
  }, [isOpen, profile]);

  const loadRelatedData = async () => {
    setLoadingData(true);
    try {
      const [userSubmissions, userInvoices, userActivities] = await Promise.all([
        base44.entities.GuestSubmission.filter({ user_email: profile.user_email }, "-created_date"),
        base44.entities.GuestInvoice.filter({ user_email: profile.user_email }, "-date"),
        base44.entities.GuestActivity.filter({ user_email: profile.user_email }, "-created_date")
      ]);
      setSubmissions(userSubmissions);
      setInvoices(userInvoices);
      setActivities(userActivities);
    } catch (error) {
      console.error("Error loading related data:", error);
    } finally {
      setLoadingData(false);
    }
  };

  const handleSubmissionAction = async (id, status) => {
    try {
      await base44.entities.GuestSubmission.update(id, { status });
      setSubmissions(prev => prev.map(s => s.id === id ? { ...s, status } : s));
      toast({ title: `Entrega ${status === 'approved' ? 'aprobada' : 'rechazada'}` });
    } catch (e) {
      toast({ title: "Error al actualizar", variant: "destructive" });
    }
  };

  const handleInvoicePay = async (id) => {
    try {
      await base44.entities.GuestInvoice.update(id, { status: 'paid' });
      setInvoices(prev => prev.map(i => i.id === id ? { ...i, status: 'paid' } : i));
      toast({ title: "Factura marcada como pagada" });
    } catch (e) {
      toast({ title: "Error al actualizar", variant: "destructive" });
    }
  };

  if (!profile) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col p-0 overflow-hidden">
        <DialogHeader className="p-6 pb-2 bg-gray-50 border-b">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
                {profile.profile_photo ? (
                    <img src={profile.profile_photo} alt="" className="w-16 h-16 rounded-full object-cover border-2 border-white shadow-sm" />
                ) : (
                    <div className="w-16 h-16 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center text-gray-400 shadow-sm">
                        <User className="w-8 h-8" />
                    </div>
                )}
                <div>
                    <DialogTitle className="text-2xl font-bold text-gray-900">{profile.user_email}</DialogTitle>
                    <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="bg-white">{profile.company || "Freelance"}</Badge>
                        <Badge className={profile.status === 'aprobado' ? 'bg-green-600' : 'bg-amber-500'}>
                            {profile.status.toUpperCase().replace('_', ' ')}
                        </Badge>
                    </div>
                </div>
            </div>
            <div className="flex gap-2">
                <Button variant="outline" size="sm" asChild>
                    <a href={`mailto:${profile.user_email}`}>
                        <Mail className="w-4 h-4 mr-2" /> Contactar
                    </a>
                </Button>
                {profile.status !== 'rechazado' && (
                    <Button variant="destructive" size="sm" onClick={() => onStatusChange(profile.id, 'rechazado')}>
                        <Ban className="w-4 h-4 mr-2" /> Desactivar
                    </Button>
                )}
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-hidden flex flex-col">
            <Tabs defaultValue="profile" className="flex-1 flex flex-col">
                <div className="px-6 pt-2 bg-gray-50 border-b">
                    <TabsList className="w-full justify-start bg-transparent p-0 h-auto gap-6">
                        <TabsTrigger value="profile" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-indigo-600 rounded-none pb-2 px-0">Perfil</TabsTrigger>
                        <TabsTrigger value="activity" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-indigo-600 rounded-none pb-2 px-0">Actividad</TabsTrigger>
                        <TabsTrigger value="submissions" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-indigo-600 rounded-none pb-2 px-0">
                            Entregas <Badge variant="secondary" className="ml-2 text-xs">{submissions.length}</Badge>
                        </TabsTrigger>
                        <TabsTrigger value="invoices" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-indigo-600 rounded-none pb-2 px-0">
                            Facturas <Badge variant="secondary" className="ml-2 text-xs">{invoices.length}</Badge>
                        </TabsTrigger>
                    </TabsList>
                </div>
                
                <ScrollArea className="flex-1 p-6 bg-white">
                    <TabsContent value="profile" className="mt-0 space-y-6">
                        <div className="grid md:grid-cols-2 gap-8">
                            <div className="space-y-4">
                                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                                    <User className="w-4 h-4 text-indigo-600" /> Información Profesional
                                </h3>
                                <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                                    <div className="grid grid-cols-3"><span className="text-gray-500 text-sm">Cargo:</span> <span className="col-span-2 font-medium text-sm">{profile.position || "-"}</span></div>
                                    <div className="grid grid-cols-3"><span className="text-gray-500 text-sm">Especialidad:</span> <span className="col-span-2 font-medium text-sm">{profile.specialty || "-"}</span></div>
                                    <div className="grid grid-cols-3"><span className="text-gray-500 text-sm">Teléfono:</span> <span className="col-span-2 font-medium text-sm">{profile.phone || "-"}</span></div>
                                    <div className="grid grid-cols-3"><span className="text-gray-500 text-sm">Portfolio:</span> 
                                        <span className="col-span-2 text-sm">
                                            {profile.portfolio_url ? <a href={profile.portfolio_url} target="_blank" className="text-blue-600 hover:underline flex items-center gap-1">Ver <ExternalLink className="w-3 h-3"/></a> : "-"}
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-4">
                                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                                    <FileText className="w-4 h-4 text-green-600" /> Datos Fiscales
                                </h3>
                                <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                                    <div className="grid grid-cols-3"><span className="text-gray-500 text-sm">ID Fiscal:</span> <span className="col-span-2 font-medium text-sm font-mono">{profile.tax_id || "-"}</span></div>
                                    <div className="grid grid-cols-3"><span className="text-gray-500 text-sm">Dirección:</span> <span className="col-span-2 font-medium text-sm">{profile.address || "-"}</span></div>
                                    <div className="grid grid-cols-3"><span className="text-gray-500 text-sm">Banco:</span> <span className="col-span-2 font-medium text-sm font-mono">{profile.bank_account || "-"}</span></div>
                                </div>
                            </div>
                        </div>
                        
                        <div>
                            <h3 className="font-semibold text-gray-900 mb-2">Biografía</h3>
                            <p className="text-sm text-gray-600 leading-relaxed">{profile.bio || "No especificada."}</p>
                        </div>
                    </TabsContent>

                    <TabsContent value="activity" className="mt-0">
                        {activities.length === 0 ? (
                            <div className="text-center py-8 text-gray-400">Sin actividad registrada</div>
                        ) : (
                            <div className="border-l-2 border-gray-100 ml-3 space-y-6">
                                {activities.map((act, i) => (
                                    <div key={i} className="relative pl-6">
                                        <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-gray-200 border-2 border-white ring-1 ring-gray-100" />
                                        <p className="text-sm font-medium text-gray-900">{act.description}</p>
                                        <p className="text-xs text-gray-500 mt-0.5">{format(new Date(act.created_date), "PPP p", {locale: es})}</p>
                                    </div>
                                ))}
                            </div>
                        )}
                    </TabsContent>

                    <TabsContent value="submissions" className="mt-0 space-y-4">
                        {submissions.map(sub => (
                            <div key={sub.id} className="bg-white border rounded-lg p-4 flex flex-col sm:flex-row justify-between gap-4 hover:border-gray-300 transition-colors">
                                <div>
                                    <div className="flex items-center gap-2 mb-1">
                                        <h4 className="font-semibold text-gray-900">{sub.title}</h4>
                                        <Badge variant={sub.status === 'approved' ? 'default' : 'secondary'}>
                                            {sub.status === 'approved' ? 'Aprobada' : sub.status === 'rejected' ? 'Rechazada' : 'Revisión'}
                                        </Badge>
                                    </div>
                                    <p className="text-sm text-gray-500 mb-2">{sub.description}</p>
                                    {sub.files?.length > 0 && (
                                        <div className="flex gap-2">
                                            {sub.files.map((f, idx) => (
                                                <a key={idx} href={f.url} target="_blank" className="text-xs bg-gray-100 px-2 py-1 rounded flex items-center gap-1 hover:bg-gray-200">
                                                    <Download className="w-3 h-3" /> {f.name}
                                                </a>
                                            ))}
                                        </div>
                                    )}
                                </div>
                                {sub.status === 'reviewing' && (
                                    <div className="flex items-center gap-2">
                                        <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => handleSubmissionAction(sub.id, 'approved')}>
                                            <CheckCircle className="w-4 h-4 mr-1" /> Aprobar
                                        </Button>
                                        <Button size="sm" variant="destructive" onClick={() => handleSubmissionAction(sub.id, 'rejected')}>
                                            <XCircle className="w-4 h-4 mr-1" /> Rechazar
                                        </Button>
                                    </div>
                                )}
                            </div>
                        ))}
                    </TabsContent>

                    <TabsContent value="invoices" className="mt-0 space-y-4">
                        {invoices.map(inv => (
                            <div key={inv.id} className="bg-white border rounded-lg p-4 flex items-center justify-between">
                                <div>
                                    <div className="flex items-center gap-2">
                                        <span className="font-mono font-semibold text-gray-900">#{inv.invoice_number}</span>
                                        <Badge className={inv.status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}>
                                            {inv.status === 'paid' ? 'Pagada' : 'Pendiente'}
                                        </Badge>
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1">{format(new Date(inv.date), "PPP", {locale: es})}</p>
                                </div>
                                <div className="text-right flex items-center gap-4">
                                    <div className="font-bold text-lg">${inv.amount?.toLocaleString()}</div>
                                    {inv.status === 'pending' && (
                                        <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => handleInvoicePay(inv.id)}>
                                            <DollarSign className="w-4 h-4 mr-1" /> Pagar
                                        </Button>
                                    )}
                                    {inv.pdf_url && (
                                        <Button size="icon" variant="ghost" asChild>
                                            <a href={inv.pdf_url} target="_blank">
                                                <Download className="w-4 h-4" />
                                            </a>
                                        </Button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </TabsContent>
                </ScrollArea>
            </Tabs>
        </div>

        <DialogFooter className="p-4 border-t bg-white">
            <Button variant="outline" onClick={onClose} className="w-full sm:w-auto">Cerrar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
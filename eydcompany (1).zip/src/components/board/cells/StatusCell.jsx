import React, { useState, useEffect } from 'react';
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function StatusCell({ value, options, onUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [localValue, setLocalValue] = useState(value);
  
  // Sincronizar el valor local con el prop
  useEffect(() => {
    setLocalValue(value);
  }, [value]);
  
  const choices = options?.choices || [
    { label: 'Sin Iniciar', color: '#C4C4C4' },
    { label: 'Trabajando en ello', color: '#FFCB00' },
    { label: 'Hecho', color: '#00C875' },
    { label: 'Bloqueado', color: '#E2445C' }
  ];
  
  const currentChoice = choices.find(choice => 
    choice.label.toLowerCase() === (localValue || '').toLowerCase()
  ) || choices[0];

  const handleChange = (newValue) => {
    setLocalValue(newValue); // Actualizar inmediatamente el estado local
    onUpdate(newValue); // Enviar actualización al servidor
    setIsEditing(false);
  };

  if (isEditing) {
    return (
      <Select
        value={currentChoice.label}
        onValueChange={handleChange}
        onOpenChange={(open) => {
          if (!open) setIsEditing(false);
        }}
        open={true}
      >
        <SelectTrigger className="w-full border-none p-0 h-auto focus:ring-0">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {choices.map((choice) => (
            <SelectItem key={choice.label} value={choice.label}>
              <div className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: choice.color }}
                />
                <span>{choice.label}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    );
  }

  return (
    <Badge
      className="cursor-pointer border-none text-white font-medium px-3 py-1 hover:opacity-80 transition-opacity"
      style={{ backgroundColor: currentChoice.color }}
      onClick={() => setIsEditing(true)}
    >
      {currentChoice.label}
    </Badge>
  );
}
import React, { useRef, useEffect, useState } from 'react';
import { useWhiteboard, generateId } from './store/WhiteboardContext';
import { motion } from 'framer-motion';
import { 
  MousePointer2, 
  Hand, 
  Square, 
  Circle, 
  Type, 
  StickyNote, 
  Minus, 
  Image as ImageIcon,
  Trash2,
  Move,
  Diamond
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export default function Toolbar() {
  const { state, dispatch } = useWhiteboard();
  const { tool } = state;

  const tools = [
    { id: 'select', icon: MousePointer2, label: 'Seleccionar (V)', shortcut: 'v' },
    { id: 'hand', icon: Hand, label: 'Mover (H)', shortcut: 'h' },
    { separator: true },
    { id: 'rect', icon: Square, label: 'Rectángulo (R)', shortcut: 'r' },
    { id: 'circle', icon: Circle, label: 'Círculo (C)', shortcut: 'c' },
    { id: 'diamond', icon: Diamond, label: 'Rombo (D)', shortcut: 'd' },
    { id: 'text', icon: Type, label: 'Texto (T)', shortcut: 't' },
    { id: 'sticky', icon: StickyNote, label: 'Nota (N)', shortcut: 'n' },
    { id: 'connector', icon: Minus, label: 'Conector (L)', shortcut: 'l', rotate: 45 },
  ];

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      const t = tools.find(t => t.shortcut === e.key.toLowerCase());
      if (t) dispatch({ type: 'SET_TOOL', payload: t.id });
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (state.selection.length > 0) {
           dispatch({ type: 'DELETE_ELEMENTS', payload: state.selection });
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [state.selection]);

  return (
    <motion.div 
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-white shadow-lg border rounded-2xl p-1.5 flex items-center gap-1 z-50"
    >
      <TooltipProvider delayDuration={0}>
        {tools.map((t, i) => (
          t.separator ? (
            <Separator key={i} orientation="vertical" className="h-6 mx-1" />
          ) : (
            <Tooltip key={t.id}>
              <TooltipTrigger asChild>
                <Button
                  variant={tool === t.id ? "secondary" : "ghost"}
                  size="icon"
                  onClick={() => dispatch({ type: 'SET_TOOL', payload: t.id })}
                  className={`rounded-xl transition-all ${tool === t.id ? 'bg-blue-100 text-blue-600 hover:bg-blue-200' : 'hover:bg-gray-100 text-gray-600'}`}
                >
                  <t.icon className={`w-5 h-5 ${t.rotate ? 'transform rotate-[-45deg]' : ''}`} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{t.label}</p>
              </TooltipContent>
            </Tooltip>
          )
        ))}
      </TooltipProvider>
    </motion.div>
  );
}
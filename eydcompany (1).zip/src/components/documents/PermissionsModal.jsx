import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Lock,
  Users,
  Building,
  Globe,
  Shield,
  Save,
  X,
  Search
} from "lucide-react";
// import { ScrollArea } from "@/components/ui/scroll-area";

const ACCESS_TYPES = [
  { value: "only_me", label: "Solo yo", icon: Lock, description: "Privado para el creador" },
  { value: "admins_only", label: "Solo administradores", icon: Shield, description: "Visible solo para admins" },
  { value: "my_department", label: "Solo mi departamento", icon: Building, description: "Todos de mi departamento" },
  { value: "specific_departments", label: "Departamentos específicos", icon: Building, description: "Seleccionar departamentos" },
  { value: "specific_users", label: "Usuarios específicos", icon: Users, description: "Seleccionar usuarios" },
  { value: "everyone", label: "Todos", icon: Globe, description: "Público internamente" },
  { value: "custom", label: "Personalizado", icon: Lock, description: "Configuración avanzada" }
];

const DEPARTMENTS = ["Desarrollo", "Diseño", "Marketing", "Ventas", "RRHH", "Finanzas"];

export default function PermissionsModal({ isOpen, onClose, onSave, files, currentUser, existingPermissions = [], isEditMode = false }) {
  const [accessType, setAccessType] = useState("my_department");
  const [permissions, setPermissions] = useState({
    can_view: true,
    can_download: true,
    can_comment: false,
    can_edit_permissions: false,
    can_delete: false,
    can_share_external: false,
    can_move: false,
    can_rename: false
  });
  const [selectedDepartments, setSelectedDepartments] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [userSearchQuery, setUserSearchQuery] = useState("");
  const [allUsers, setAllUsers] = useState([]);
  const [templates, setTemplates] = useState([]);

  useEffect(() => {
    if (isOpen) {
      loadUsers();
      loadTemplates();
      
      // Si estamos en modo edición, cargar permisos existentes
      if (isEditMode && existingPermissions.length > 0) {
        loadExistingPermissions();
      } else {
        // Reset a valores por defecto
        setAccessType("my_department");
        setPermissions({
          can_view: true,
          can_download: true,
          can_comment: false,
          can_edit_permissions: false,
          can_delete: false,
          can_share_external: false,
          can_move: false,
          can_rename: false
        });
        setSelectedDepartments([]);
        setSelectedUsers([]);
      }
    }
  }, [isOpen, isEditMode, existingPermissions]);

  const loadUsers = async () => {
    try {
      const users = await base44.entities.User.list();
      setAllUsers(users.filter(u => u.email !== currentUser.email && u.status === "active"));
    } catch (error) {
      console.error("Error al cargar usuarios:", error);
    }
  };

  const loadTemplates = async () => {
    try {
      const temps = await base44.entities.PermissionTemplate.filter({
        user_email: currentUser.email
      });
      setTemplates(temps);
    } catch (error) {
      console.error("Error al cargar plantillas:", error);
    }
  };

  const loadExistingPermissions = () => {
    if (existingPermissions.length === 0) return;

    // Determinar el tipo de acceso basado en los permisos existentes
    const firstPerm = existingPermissions[0];
    
    // Cargar permisos de acción del primer permiso
    setPermissions({
      can_view: firstPerm.can_view,
      can_download: firstPerm.can_download,
      can_comment: firstPerm.can_comment,
      can_edit_permissions: firstPerm.can_edit_permissions,
      can_delete: firstPerm.can_delete,
      can_share_external: firstPerm.can_share_external,
      can_move: firstPerm.can_move,
      can_rename: firstPerm.can_rename
    });

    // Determinar tipo de acceso
    if (firstPerm.permission_type === "public") {
      setAccessType("everyone");
    } else if (firstPerm.permission_type === "role" && firstPerm.entity_id === "admin") {
      setAccessType("admins_only");
    } else if (firstPerm.permission_type === "user" && firstPerm.entity_id === currentUser.email) {
      setAccessType("only_me");
    } else if (firstPerm.permission_type === "department") {
      if (existingPermissions.length === 1 && firstPerm.entity_id === currentUser.department) {
        setAccessType("my_department");
      } else {
        setAccessType("specific_departments");
        const depts = existingPermissions
          .filter(p => p.permission_type === "department")
          .map(p => p.entity_id);
        setSelectedDepartments(depts);
      }
    } else if (firstPerm.permission_type === "user") {
      setAccessType("specific_users");
      const userEmails = existingPermissions
        .filter(p => p.permission_type === "user")
        .map(p => p.entity_id);
      // Cargar usuarios después de tener la lista
      setTimeout(() => {
        setSelectedUsers(allUsers.filter(u => userEmails.includes(u.email)));
      }, 500);
    } else {
      setAccessType("custom");
    }
  };

  const handleSave = () => {
    const config = {
      accessType,
      permissions,
      selectedDepartments,
      selectedUsers: selectedUsers.map(u => u.email)
    };
    onSave(config);
  };

  const toggleDepartment = (dept) => {
    setSelectedDepartments(prev =>
      prev.includes(dept) ? prev.filter(d => d !== dept) : [...prev, dept]
    );
  };

  const toggleUser = (user) => {
    setSelectedUsers(prev =>
      prev.find(u => u.email === user.email)
        ? prev.filter(u => u.email !== user.email)
        : [...prev, user]
    );
  };

  const filteredUsers = allUsers.filter(user =>
    user.full_name.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(userSearchQuery.toLowerCase())
  );

  const applyTemplate = (template) => {
    const config = template.configuration;
    setAccessType(config.accessType);
    setPermissions(config.permissions);
    setSelectedDepartments(config.selectedDepartments || []);
    setSelectedUsers(allUsers.filter(u => config.selectedUsers?.includes(u.email)));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
              <Lock className="w-5 h-5 text-white" />
            </div>
            {isEditMode ? 'Editar Permisos' : 'Configurar Permisos'}
          </DialogTitle>
          <p className="text-sm text-gray-500">
            {isEditMode 
              ? `Editando permisos de: ${files?.[0]?.name || 'documento'}`
              : `${files?.length || 0} archivo${files?.length !== 1 ? 's' : ''} seleccionado${files?.length !== 1 ? 's' : ''}`
            }
          </p>
        </DialogHeader>

        <div className="flex-1 pr-4">
          <div className="space-y-6 py-4">
            {/* Plantillas Rápidas */}
            {templates.length > 0 && (
              <div>
                <Label className="text-sm font-semibold mb-2 block">Plantillas Guardadas</Label>
                <div className="flex flex-wrap gap-2">
                  {templates.map((template) => (
                    <Button
                      key={template.id}
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => applyTemplate(template)}
                      className="text-xs"
                    >
                      {template.name}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Tipo de Acceso */}
            <div>
              <Label className="text-sm font-semibold mb-3 block">¿Quién puede acceder?</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {ACCESS_TYPES.map((type) => {
                  const Icon = type.icon;
                  return (
                    <button
                      key={type.value}
                      type="button"
                      onClick={() => setAccessType(type.value)}
                      className={`
                        p-4 rounded-lg border-2 text-left transition-all hover:shadow-md
                        ${accessType === type.value
                          ? 'border-purple-500 bg-purple-50'
                          : 'border-gray-200 hover:border-purple-300'
                        }
                      `}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`
                          w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0
                          ${accessType === type.value ? 'bg-purple-500' : 'bg-gray-100'}
                        `}>
                          <Icon className={`w-5 h-5 ${accessType === type.value ? 'text-white' : 'text-gray-600'}`} />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-gray-900 text-sm">{type.label}</p>
                          <p className="text-xs text-gray-500 mt-0.5">{type.description}</p>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Departamentos Específicos */}
            {accessType === "specific_departments" && (
              <div>
                <Label className="text-sm font-semibold mb-2 block">Seleccionar Departamentos</Label>
                <div className="flex flex-wrap gap-2">
                  {DEPARTMENTS.map((dept) => (
                    <Badge
                      key={dept}
                      variant={selectedDepartments.includes(dept) ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => toggleDepartment(dept)}
                    >
                      {dept}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Usuarios Específicos */}
            {accessType === "specific_users" && (
              <div>
                <Label className="text-sm font-semibold mb-2 block">Seleccionar Usuarios</Label>
                <div className="relative mb-3">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Buscar usuarios..."
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <div className="max-h-48 overflow-y-auto border rounded-lg p-2 space-y-1">
                  {filteredUsers.map((user) => (
                    <div
                      key={user.email}
                      className="flex items-center gap-2 p-2 hover:bg-gray-50 rounded cursor-pointer"
                      onClick={() => toggleUser(user)}
                    >
                      <Checkbox
                        checked={selectedUsers.find(u => u.email === user.email)}
                        onCheckedChange={() => toggleUser(user)}
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{user.full_name}</p>
                        <p className="text-xs text-gray-500">{user.email}</p>
                      </div>
                    </div>
                  ))}
                </div>
                {selectedUsers.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selectedUsers.map((user) => (
                      <Badge key={user.email} variant="secondary" className="gap-1">
                        {user.full_name}
                        <X
                          className="w-3 h-3 cursor-pointer"
                          onClick={() => toggleUser(user)}
                        />
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Permisos de Acción */}
            <div>
              <Label className="text-sm font-semibold mb-3 block">Permisos de Acción</Label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { key: 'can_view', label: 'Ver' },
                  { key: 'can_download', label: 'Descargar' },
                  { key: 'can_comment', label: 'Comentar' },
                  { key: 'can_edit_permissions', label: 'Editar permisos' },
                  { key: 'can_delete', label: 'Eliminar' },
                  { key: 'can_share_external', label: 'Compartir externamente' },
                  { key: 'can_move', label: 'Mover' },
                  { key: 'can_rename', label: 'Renombrar' }
                ].map(({ key, label }) => (
                  <div key={key} className="flex items-center space-x-2">
                    <Checkbox
                      id={key}
                      checked={permissions[key]}
                      onCheckedChange={(checked) =>
                        setPermissions({ ...permissions, [key]: checked })
                      }
                    />
                    <label
                      htmlFor={key}
                      className="text-sm text-gray-700 cursor-pointer select-none"
                    >
                      {label}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            type="button"
            onClick={handleSave}
            className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
          >
            <Save className="w-4 h-4 mr-2" />
            {isEditMode ? 'Actualizar Permisos' : 'Guardar y Subir'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
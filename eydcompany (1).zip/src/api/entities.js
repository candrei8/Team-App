import { base44 } from './base44Client';


export const Board = base44.entities.Board;

export const Item = base44.entities.Item;

export const DocumentFolder = base44.entities.DocumentFolder;

export const Document = base44.entities.Document;

export const Notification = base44.entities.Notification;

export const Whiteboard = base44.entities.Whiteboard;

export const WhiteboardSession = base44.entities.WhiteboardSession;

export const WhiteboardComment = base44.entities.WhiteboardComment;

export const WhiteboardActivity = base44.entities.WhiteboardActivity;

export const WhiteboardPermission = base44.entities.WhiteboardPermission;

export const PushSubscription = base44.entities.PushSubscription;

export const TodoTask = base44.entities.TodoTask;

export const CalendarEvent = base44.entities.CalendarEvent;

export const Channel = base44.entities.Channel;

export const Message = base44.entities.Message;

export const GuestProfile = base44.entities.GuestProfile;

export const GuestDocument = base44.entities.GuestDocument;

export const GuestProposal = base44.entities.GuestProposal;

export const GuestConversation = base44.entities.GuestConversation;

export const GuestMessage = base44.entities.GuestMessage;

export const GuestInvoice = base44.entities.GuestInvoice;

export const GuestActivity = base44.entities.GuestActivity;

export const GuestStatusHistory = base44.entities.GuestStatusHistory;

export const DocumentPermission = base44.entities.DocumentPermission;

export const DocumentActivity = base44.entities.DocumentActivity;

export const DocumentComment = base44.entities.DocumentComment;

export const ExternalShare = base44.entities.ExternalShare;

export const PermissionTemplate = base44.entities.PermissionTemplate;

export const FavoriteDocument = base44.entities.FavoriteDocument;

export const UserAuditLog = base44.entities.UserAuditLog;

export const GuestSubmission = base44.entities.GuestSubmission;

export const MessageReaction = base44.entities.MessageReaction;

export const MessageThread = base44.entities.MessageThread;

export const CalendarIntegration = base44.entities.CalendarIntegration;



// auth sdk:
export const User = base44.auth;
import React, { useCallback, useState } from "react";
import { Upload, X, File, FileText, Image as ImageIcon } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";

const ALLOWED_TYPES = {
  'application/pdf': { icon: FileText, color: 'text-red-500' },
  'application/msword': { icon: FileText, color: 'text-blue-500' },
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': { icon: FileText, color: 'text-blue-500' },
  'application/vnd.ms-excel': { icon: FileText, color: 'text-green-500' },
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': { icon: FileText, color: 'text-green-500' },
  'application/vnd.ms-powerpoint': { icon: FileText, color: 'text-orange-500' },
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': { icon: FileText, color: 'text-orange-500' },
  'image/jpeg': { icon: ImageIcon, color: 'text-purple-500' },
  'image/png': { icon: ImageIcon, color: 'text-purple-500' },
  'image/gif': { icon: ImageIcon, color: 'text-purple-500' },
  'application/zip': { icon: File, color: 'text-gray-500' },
  'application/x-zip-compressed': { icon: File, color: 'text-gray-500' }
};

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

export default function DragDropUpload({ onFilesSelected, currentFolder }) {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [errors, setErrors] = useState([]);

  const validateFile = (file) => {
    const errors = [];
    
    if (file.size > MAX_FILE_SIZE) {
      errors.push(`${file.name}: El archivo supera el límite de 50MB`);
    }
    
    if (!ALLOWED_TYPES[file.type]) {
      errors.push(`${file.name}: Tipo de archivo no permitido`);
    }
    
    return errors;
  };

  const handleFiles = (files) => {
    const fileArray = Array.from(files);
    const allErrors = [];
    const validFiles = [];

    fileArray.forEach(file => {
      const fileErrors = validateFile(file);
      if (fileErrors.length > 0) {
        allErrors.push(...fileErrors);
      } else {
        validFiles.push(file);
      }
    });

    setErrors(allErrors);
    
    if (validFiles.length > 0) {
      setSelectedFiles(validFiles);
      onFilesSelected(validFiles);
    }
  };

  const handleDragOver = useCallback((e) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  }, []);

  const handleFileInput = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(e.target.files);
    }
  };

  const removeFile = (index) => {
    const newFiles = selectedFiles.filter((_, i) => i !== index);
    setSelectedFiles(newFiles);
    if (newFiles.length === 0) {
      setErrors([]);
    }
  };

  const getFileIcon = (fileType) => {
    return ALLOWED_TYPES[fileType]?.icon || File;
  };

  const getFileColor = (fileType) => {
    return ALLOWED_TYPES[fileType]?.color || 'text-gray-500';
  };

  return (
    <div className="space-y-4">
      {/* Drag & Drop Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          relative border-2 border-dashed rounded-xl p-8 transition-all duration-200
          ${isDragging 
            ? 'border-blue-500 bg-blue-50 scale-105' 
            : 'border-gray-300 hover:border-blue-400 hover:bg-gray-50'
          }
        `}
      >
        <div className="text-center">
          <motion.div
            animate={isDragging ? { scale: 1.1 } : { scale: 1 }}
            className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${
              isDragging ? 'bg-blue-500' : 'bg-blue-100'
            }`}
          >
            <Upload className={`w-8 h-8 ${isDragging ? 'text-white' : 'text-blue-600'}`} />
          </motion.div>

          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            {isDragging ? '¡Suelta los archivos aquí!' : 'Arrastra archivos o haz clic para seleccionar'}
          </h3>
          
          <p className="text-sm text-gray-500 mb-4">
            Formatos: PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX, JPG, PNG, GIF, ZIP
          </p>
          
          <p className="text-xs text-gray-400 mb-4">
            Tamaño máximo por archivo: 50MB
          </p>

          <input
            type="file"
            id="file-input"
            multiple
            accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png,.gif,.zip"
            onChange={handleFileInput}
            className="hidden"
          />
          
          <Button
            type="button"
            onClick={() => document.getElementById('file-input')?.click()}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Upload className="w-4 h-4 mr-2" />
            Seleccionar Archivos
          </Button>
        </div>
      </div>

      {/* Selected Files Preview */}
      <AnimatePresence>
        {selectedFiles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-2"
          >
            <h4 className="font-semibold text-gray-900 text-sm">
              Archivos Seleccionados ({selectedFiles.length})
            </h4>
            {selectedFiles.map((file, index) => {
              const Icon = getFileIcon(file.type);
              const colorClass = getFileColor(file.type);
              
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="flex items-center gap-3 p-3 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
                >
                  <div className={`w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center ${colorClass}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 truncate text-sm">{file.name}</p>
                    <p className="text-xs text-gray-500">
                      {(file.size / (1024 * 1024)).toFixed(2)} MB
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeFile(index)}
                    className="flex-shrink-0"
                  >
                    <X className="w-4 h-4 text-gray-500" />
                  </Button>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Errors */}
      <AnimatePresence>
        {errors.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="p-4 bg-red-50 border border-red-200 rounded-lg"
          >
            <h4 className="font-semibold text-red-900 text-sm mb-2">Errores de Validación</h4>
            <ul className="space-y-1">
              {errors.map((error, index) => (
                <li key={index} className="text-xs text-red-700">• {error}</li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Clock, Ban, LogOut, RefreshCw } from "lucide-react";

export default function AccessBlockedPage() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isChecking, setIsChecking] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    setIsLoading(true);
    try {
      const userData = await base44.auth.me();
      console.log("🔒 AccessBlocked - Usuario:", userData.email, "| Status:", userData.status);
      setUser(userData);
      
      // Si el usuario es activo, redirigir al dashboard
      if (userData.status === "active" || userData.role === "admin") {
        console.log("✅ Usuario activo o admin detectado, redirigiendo...");
        window.location.href = "/";
      }
    } catch (error) {
      console.error("Error al cargar usuario:", error);
    }
    setIsLoading(false);
  };

  const handleCheckStatus = async () => {
    setIsChecking(true);
    try {
      const userData = await base44.auth.me();
      console.log("🔄 Verificando status:", userData.status);
      setUser(userData);
      
      // Si el usuario ahora está activo, recargar la página
      if (userData.status === "active" || userData.role === "admin") {
        console.log("✅ Status actualizado a activo, redirigiendo...");
        window.location.href = "/";
      }
    } catch (error) {
      console.error("Error al verificar estado:", error);
    }
    setIsChecking(false);
  };

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0073EA] mx-auto mb-4"></div>
          <p className="text-gray-600">Verificando tu cuenta...</p>
        </div>
      </div>
    );
  }

  const isPending = user?.status === "pending" || !user?.status;
  const isSuspended = user?.status === "suspended";

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 p-4">
      <Card className="max-w-2xl w-full shadow-2xl border-0">
        <CardContent className="p-8 md:p-12">
          <div className="text-center space-y-6">
            {/* Icon */}
            <div className="flex justify-center">
              <div className={`w-20 h-20 rounded-full flex items-center justify-center ${
                isPending ? "bg-amber-100" : "bg-red-100"
              }`}>
                {isPending ? (
                  <Clock className="w-10 h-10 text-amber-600" />
                ) : (
                  <Ban className="w-10 h-10 text-red-600" />
                )}
              </div>
            </div>

            {/* Title */}
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {isPending ? "Cuenta Pendiente de Verificación" : "Cuenta Suspendida"}
              </h1>
              <p className="text-gray-600">
                {user?.full_name && `Hola ${user.full_name.split(" ")[0]},`}
              </p>
            </div>

            {/* Message */}
            <Card className={`${
              isPending ? "bg-amber-50 border-amber-200" : "bg-red-50 border-red-200"
            }`}>
              <CardContent className="p-6">
                {isPending ? (
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <div className="text-left">
                        <p className="font-semibold text-amber-900 mb-2">
                          Tu cuenta está siendo revisada
                        </p>
                        <p className="text-sm text-amber-800 leading-relaxed">
                          Un administrador debe aprobar tu cuenta antes de que puedas acceder a la aplicación. 
                          Recibirás una notificación por email cuando tu cuenta sea activada.
                        </p>
                      </div>
                    </div>
                    
                    <div className="pt-4 border-t border-amber-200">
                      <p className="text-xs text-amber-700 mb-3">
                        <strong>Información de tu cuenta:</strong>
                      </p>
                      <div className="space-y-2 text-left text-sm text-amber-800">
                        <p>• Email: <strong>{user?.email}</strong></p>
                        <p>• Registrado: <strong>{new Date(user?.created_date).toLocaleDateString('es-ES', { 
                          day: 'numeric', 
                          month: 'long', 
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}</strong></p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <Ban className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                      <div className="text-left">
                        <p className="font-semibold text-red-900 mb-2">
                          Tu cuenta ha sido suspendida
                        </p>
                        {user?.suspension_reason && (
                          <div className="bg-white rounded-lg p-4 border border-red-200 mt-3">
                            <p className="text-xs text-red-600 font-medium mb-1">MOTIVO DE LA SUSPENSIÓN:</p>
                            <p className="text-sm text-red-900 font-medium">
                              {user.suspension_reason}
                            </p>
                          </div>
                        )}
                        <p className="text-sm text-red-800 mt-3 leading-relaxed">
                          Si crees que esto es un error, por favor contacta con un administrador del sistema.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3 justify-center pt-4">
              {isPending && (
                <Button
                  onClick={handleCheckStatus}
                  disabled={isChecking}
                  className="bg-[#0073EA] hover:bg-[#0056B3]"
                >
                  {isChecking ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Verificando...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Verificar Estado
                    </>
                  )}
                </Button>
              )}
              
              <Button
                variant="outline"
                onClick={handleLogout}
                className="border-gray-300"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Cerrar Sesión
              </Button>
            </div>

            {/* Help Text */}
            <div className="pt-6 border-t border-gray-200">
              <p className="text-xs text-gray-500">
                {isPending ? (
                  <>
                    Esto suele tomar unos minutos. Si tienes preguntas, contacta al equipo de soporte.
                  </>
                ) : (
                  <>
                    Para más información, contacta con el administrador del sistema.
                  </>
                )}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
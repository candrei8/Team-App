import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { X, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";

export default function ElementPropertiesPanel({ elements, onUpdate }) {
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  
  if (elements.length === 0) return null;

  const element = elements[0];
  const { type, properties } = element;

  const handlePropertyChange = (key, value) => {
    onUpdate(element.id, {
      properties: {
        ...properties,
        [key]: value
      }
    });
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingImage(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      handlePropertyChange('url', file_url);
    } catch (error) {
      console.error('Error al subir imagen:', error);
      alert('Error al subir la imagen');
    } finally {
      setIsUploadingImage(false);
    }
  };

  return (
    <div className="w-80 bg-white border-l border-[#E1E5F3] overflow-y-auto shadow-lg">
      <div className="p-4 border-b border-[#E1E5F3] flex items-center justify-between">
        <h3 className="font-semibold text-[#323338]">Propiedades</h3>
        <span className="text-xs text-gray-500">
          {elements.length} seleccionado{elements.length > 1 ? 's' : ''}
        </span>
      </div>

      <div className="p-4 space-y-6">
        {/* Sticky Note Properties */}
        {type === 'sticky_note' && (
          <>
            <div className="space-y-2">
              <Label>Color</Label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { name: 'Amarillo', value: '#FFEB3B' },
                  { name: 'Rosa', value: '#F48FB1' },
                  { name: 'Azul', value: '#64B5F6' },
                  { name: 'Verde', value: '#81C784' },
                  { name: 'Naranja', value: '#FFB74D' },
                  { name: 'Púrpura', value: '#BA68C8' },
                ].map((color) => (
                  <button
                    key={color.value}
                    className={`h-10 rounded-lg border-2 transition-all ${
                      properties.color === color.value
                        ? 'border-[#0073EA] scale-105'
                        : 'border-gray-300 hover:scale-105'
                    }`}
                    style={{ backgroundColor: color.value }}
                    onClick={() => handlePropertyChange('color', color.value)}
                    title={color.name}
                  />
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Tamaño de Fuente</Label>
              <Slider
                value={[properties.fontSize || 14]}
                onValueChange={([value]) => handlePropertyChange('fontSize', value)}
                min={10}
                max={24}
                step={1}
                className="w-full"
              />
              <span className="text-xs text-gray-500">{properties.fontSize || 14}px</span>
            </div>
          </>
        )}

        {/* Shape Properties */}
        {type === 'shape' && (
          <>
            <div className="space-y-2">
              <Label>Forma</Label>
              <Select 
                value={properties.shape} 
                onValueChange={(value) => handlePropertyChange('shape', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rectangle">Rectángulo</SelectItem>
                  <SelectItem value="circle">Círculo</SelectItem>
                  <SelectItem value="triangle">Triángulo</SelectItem>
                  <SelectItem value="diamond">Diamante</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Color de Relleno</Label>
              <Input
                type="color"
                value={properties.fill || '#ffffff'}
                onChange={(e) => handlePropertyChange('fill', e.target.value)}
                className="h-10"
              />
            </div>

            <div className="space-y-2">
              <Label>Color de Borde</Label>
              <Input
                type="color"
                value={properties.stroke || '#000000'}
                onChange={(e) => handlePropertyChange('stroke', e.target.value)}
                className="h-10"
              />
            </div>

            <div className="space-y-2">
              <Label>Grosor de Borde</Label>
              <Slider
                value={[properties.strokeWidth || 2]}
                onValueChange={([value]) => handlePropertyChange('strokeWidth', value)}
                min={1}
                max={10}
                step={1}
                className="w-full"
              />
              <span className="text-xs text-gray-500">{properties.strokeWidth || 2}px</span>
            </div>
            
            <div className="space-y-2">
              <Label>Texto (doble click en la forma para editar)</Label>
              <p className="text-xs text-gray-500">
                {properties.text ? `"${properties.text}"` : 'Sin texto'}
              </p>
            </div>
          </>
        )}

        {/* Text Properties */}
        {type === 'text' && (
          <>
            <div className="space-y-2">
              <Label>Color de Texto</Label>
              <Input
                type="color"
                value={properties.color || '#000000'}
                onChange={(e) => handlePropertyChange('color', e.target.value)}
                className="h-10"
              />
            </div>

            <div className="space-y-2">
              <Label>Tamaño</Label>
              <Select
                value={String(properties.fontSize || 18)}
                onValueChange={(value) => handlePropertyChange('fontSize', parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="14">Cuerpo (14px)</SelectItem>
                  <SelectItem value="18">Subtítulo (18px)</SelectItem>
                  <SelectItem value="24">Título (24px)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Alineación</Label>
              <Select
                value={properties.align || 'left'}
                onValueChange={(value) => handlePropertyChange('align', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="left">Izquierda</SelectItem>
                  <SelectItem value="center">Centro</SelectItem>
                  <SelectItem value="right">Derecha</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Estilo</Label>
              <div className="flex gap-2">
                <Button
                  variant={properties.bold ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePropertyChange('bold', !properties.bold)}
                  className="flex-1"
                >
                  <strong>B</strong>
                </Button>
                <Button
                  variant={properties.italic ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePropertyChange('italic', !properties.italic)}
                  className="flex-1"
                >
                  <em>I</em>
                </Button>
              </div>
            </div>
          </>
        )}

        {/* Connector Properties */}
        {type === 'connector' && (
          <>
            <div className="space-y-2">
              <Label>Color de Línea</Label>
              <Input
                type="color"
                value={properties.stroke || '#000000'}
                onChange={(e) => handlePropertyChange('stroke', e.target.value)}
                className="h-10"
              />
            </div>

            <div className="space-y-2">
              <Label>Grosor</Label>
              <Slider
                value={[properties.strokeWidth || 2]}
                onValueChange={([value]) => handlePropertyChange('strokeWidth', value)}
                min={1}
                max={10}
                step={1}
                className="w-full"
              />
              <span className="text-xs text-gray-500">{properties.strokeWidth || 2}px</span>
            </div>

            <div className="space-y-2">
              <Label>Flechas</Label>
              <div className="flex gap-2">
                <Button
                  variant={properties.arrowStart ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePropertyChange('arrowStart', !properties.arrowStart)}
                  className="flex-1"
                >
                  ← Inicio
                </Button>
                <Button
                  variant={properties.arrowEnd ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePropertyChange('arrowEnd', !properties.arrowEnd)}
                  className="flex-1"
                >
                  Fin →
                </Button>
              </div>
            </div>
          </>
        )}

        {/* Image Properties */}
        {type === 'image' && (
          <>
            <div className="space-y-2">
              <Label>Imagen</Label>
              {properties.url ? (
                <div className="space-y-2">
                  <img 
                    src={properties.url} 
                    alt="Preview" 
                    className="w-full h-32 object-cover rounded-lg border"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full"
                    onClick={() => handlePropertyChange('url', null)}
                  >
                    Cambiar Imagen
                  </Button>
                </div>
              ) : (
                <div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="image-upload"
                    disabled={isUploadingImage}
                  />
                  <label htmlFor="image-upload">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      asChild
                      disabled={isUploadingImage}
                    >
                      <span>
                        <Upload className="w-4 h-4 mr-2" />
                        {isUploadingImage ? 'Subiendo...' : 'Subir Imagen'}
                      </span>
                    </Button>
                  </label>
                </div>
              )}
            </div>
          </>
        )}

        {/* Common Properties */}
        <div className="pt-4 border-t space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Posición X:</span>
            <span className="font-mono text-gray-900">{Math.round(element.position.x)}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Posición Y:</span>
            <span className="font-mono text-gray-900">{Math.round(element.position.y)}</span>
          </div>
          {element.size && (
            <>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Ancho:</span>
                <span className="font-mono text-gray-900">{Math.round(element.size.width)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Alto:</span>
                <span className="font-mono text-gray-900">{Math.round(element.size.height)}</span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
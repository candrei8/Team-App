import React, { useState, useEffect } from "react";
import { Whiteboard } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Plus, 
  Search, 
  Pen,
  MoreHorizontal,
  Trash2,
  Copy,
  Clock
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format, formatDistanceToNow } from "date-fns";
import { es } from 'date-fns/locale';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import CreateWhiteboardModal from "../components/whiteboard/CreateWhiteboardModal";

const WhiteboardCard = ({ whiteboard, onDelete, onDuplicate }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(createPageUrl("WhiteboardCanvas") + `?id=${whiteboard.id}`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="cursor-pointer overflow-hidden hover:shadow-xl transition-all duration-300 border-[#E1E5F3] group">
        <div 
          onClick={handleClick}
          className="relative aspect-video bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center overflow-hidden"
        >
          {whiteboard.thumbnail ? (
            <img 
              src={whiteboard.thumbnail} 
              alt={whiteboard.title}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="text-center p-6">
              <Pen className="w-12 h-12 text-gray-300 mx-auto mb-2" />
              <p className="text-sm text-gray-400">Pizarra en blanco</p>
            </div>
          )}
          
          {/* Overlay con info */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <Badge className="bg-white/90 text-gray-900">
                {whiteboard.elements?.length || 0} elementos
              </Badge>
            </div>
          </div>

          {/* Botón de acciones */}
          <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity" onClick={(e) => e.stopPropagation()}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="secondary" size="icon" className="h-8 w-8 bg-white/90 hover:bg-white">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onDuplicate(whiteboard)}>
                  <Copy className="w-4 h-4 mr-2" />
                  Duplicar
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="text-red-600"
                  onClick={() => {
                    if (window.confirm('¿Eliminar esta pizarra?')) {
                      onDelete(whiteboard.id);
                    }
                  }}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Eliminar
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <CardContent className="p-4">
          <h3 className="font-semibold text-gray-900 mb-1 line-clamp-1">
            {whiteboard.title}
          </h3>
          {whiteboard.description && (
            <p className="text-sm text-gray-500 line-clamp-2 mb-2">
              {whiteboard.description}
            </p>
          )}
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <Clock className="w-3 h-3" />
            <span>
              {formatDistanceToNow(new Date(whiteboard.updated_date), { 
                addSuffix: true,
                locale: es 
              })}
            </span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function WhiteboardsPage() {
  const [whiteboards, setWhiteboards] = useState([]);
  const [filteredWhiteboards, setFilteredWhiteboards] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);

  useEffect(() => {
    loadWhiteboards();
  }, []);

  useEffect(() => {
    filterWhiteboards();
  }, [searchQuery, whiteboards]);

  const loadWhiteboards = async () => {
    setIsLoading(true);
    try {
      const data = await Whiteboard.list("-updated_date");
      setWhiteboards(data);
    } catch (error) {
      console.error("Error al cargar pizarras:", error);
    }
    setIsLoading(false);
  };

  const filterWhiteboards = () => {
    if (!searchQuery) {
      setFilteredWhiteboards(whiteboards);
      return;
    }

    const lowercasedQuery = searchQuery.toLowerCase();
    const filtered = whiteboards.filter(wb =>
      wb.title.toLowerCase().includes(lowercasedQuery) ||
      wb.description?.toLowerCase().includes(lowercasedQuery)
    );
    setFilteredWhiteboards(filtered);
  };

  const handleCreateWhiteboard = async (whiteboardData) => {
    try {
      const newWhiteboard = await Whiteboard.create({
        ...whiteboardData,
        elements: [],
        canvas_settings: {
          grid_visible: true,
          grid_type: "dots",
          zoom: 1,
          pan: { x: 0, y: 0 }
        }
      });
      setWhiteboards(prev => [newWhiteboard, ...prev]);
      setShowCreateModal(false);
    } catch (error) {
      console.error("Error al crear pizarra:", error);
    }
  };

  const handleDeleteWhiteboard = async (whiteboardId) => {
    try {
      await Whiteboard.delete(whiteboardId);
      setWhiteboards(prev => prev.filter(wb => wb.id !== whiteboardId));
    } catch (error) {
      console.error("Error al eliminar pizarra:", error);
    }
  };

  const handleDuplicateWhiteboard = async (whiteboard) => {
    try {
      const duplicated = await Whiteboard.create({
        title: `${whiteboard.title} (Copia)`,
        description: whiteboard.description,
        elements: whiteboard.elements || [],
        canvas_settings: whiteboard.canvas_settings
      });
      setWhiteboards(prev => [duplicated, ...prev]);
    } catch (error) {
      console.error("Error al duplicar pizarra:", error);
    }
  };

  return (
    <div className="p-4 md:p-6 bg-[#F5F6F8] min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-[#323338]">
              Pizarras
            </h1>
            <p className="text-[#676879] text-sm mt-1">
              Crea y gestiona tus pizarras colaborativas
            </p>
          </div>
          <Button 
            onClick={() => setShowCreateModal(true)}
            className="bg-gradient-to-r from-[#0073EA] to-[#0056B3] hover:from-[#0056B3] hover:to-[#0073EA] text-white rounded-lg h-10 px-5 font-medium text-sm shadow-md transition-all hover:shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nueva Pizarra
          </Button>
        </div>

        {/* Buscador */}
        <div className="relative mb-6 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-[#676879]" />
          <Input
            placeholder="Buscar pizarras..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-white border-[#E1E5F3] rounded-lg h-10 focus:ring-2 focus:ring-[#0073EA]/20 text-sm"
          />
        </div>

        {/* Grid de Whiteboards */}
        <AnimatePresence mode="wait">
          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array(8).fill(0).map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="aspect-video bg-gray-200"></div>
                  <CardContent className="p-4 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-full"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredWhiteboards.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-16"
            >
              <div className="w-24 h-24 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Pen className="w-12 h-12 text-blue-500" />
              </div>
              <h3 className="text-xl font-semibold text-[#323338] mb-2">
                {searchQuery ? "No se encontraron pizarras" : "Aún no hay pizarras"}
              </h3>
              <p className="text-[#676879] mb-6">
                {searchQuery 
                  ? "Intenta ajustar tu búsqueda." 
                  : "¡Comienza creando tu primera pizarra colaborativa!"
                }
              </p>
              {!searchQuery && (
                <Button 
                  onClick={() => setShowCreateModal(true)}
                  className="bg-gradient-to-r from-[#0073EA] to-[#0056B3] hover:from-[#0056B3] hover:to-[#0073EA] text-white rounded-xl h-12 px-6 font-medium shadow-md hover:shadow-lg transition-all"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Crear Primera Pizarra
                </Button>
              )}
            </motion.div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredWhiteboards.map((whiteboard) => (
                <WhiteboardCard
                  key={whiteboard.id}
                  whiteboard={whiteboard}
                  onDelete={handleDeleteWhiteboard}
                  onDuplicate={handleDuplicateWhiteboard}
                />
              ))}
            </div>
          )}
        </AnimatePresence>

        {/* Modal de creación */}
        <CreateWhiteboardModal
          isOpen={showCreateModal}
          onClose={() => setShowCreateModal(false)}
          onSubmit={handleCreateWhiteboard}
        />
      </div>
    </div>
  );
}
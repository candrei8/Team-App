import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Share2, 
  Link as LinkIcon, 
  Mail, 
  Check, 
  Copy, 
  Trash2,
  Crown,
  Edit3,
  Eye,
  UserPlus
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const ROLE_ICONS = {
  owner: Crown,
  editor: Edit3,
  viewer: Eye,
  guest: UserPlus
};

const ROLE_COLORS = {
  owner: 'text-yellow-600 bg-yellow-100',
  editor: 'text-blue-600 bg-blue-100',
  viewer: 'text-gray-600 bg-gray-100',
  guest: 'text-purple-600 bg-purple-100'
};

const ROLE_LABELS = {
  owner: 'Propietario',
  editor: 'Editor',
  viewer: 'Observador',
  guest: 'Invitado'
};

export default function SharePanel({ 
  whiteboardId, 
  permissions, 
  currentUserEmail, 
  onInviteUser, 
  onUpdatePermission, 
  onRemovePermission 
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('editor');
  const [linkCopied, setLinkCopied] = useState(false);
  const { toast } = useToast();

  const currentUserPermission = permissions.find(p => p.user_email === currentUserEmail);
  const isOwner = currentUserPermission?.role === 'owner';
  const canShare = isOwner || currentUserPermission?.can_share;

  const handleInvite = async () => {
    if (!email.trim()) return;

    try {
      await onInviteUser(email, role);
      setEmail('');
      toast({
        title: "Invitación enviada",
        description: `Se ha invitado a ${email} como ${ROLE_LABELS[role]}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo enviar la invitación",
        variant: "destructive"
      });
    }
  };

  const handleCopyLink = () => {
    const link = `${window.location.origin}/whiteboard/${whiteboardId}`;
    navigator.clipboard.writeText(link);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
    toast({
      title: "Enlace copiado",
      description: "El enlace se ha copiado al portapapeles",
    });
  };

  const handleRoleChange = async (permissionId, newRole) => {
    try {
      await onUpdatePermission(permissionId, newRole);
      toast({
        title: "Rol actualizado",
        description: "El rol del usuario se ha actualizado correctamente",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo actualizar el rol",
        variant: "destructive"
      });
    }
  };

  const handleRemove = async (permissionId) => {
    try {
      await onRemovePermission(permissionId);
      toast({
        title: "Acceso eliminado",
        description: "Se ha eliminado el acceso del usuario",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar el acceso",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="h-9">
          <Share2 className="w-4 h-4 mr-2" />
          Compartir
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Compartir Whiteboard</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Invitar por email */}
          {canShare && (
            <div className="space-y-3">
              <h4 className="text-sm font-medium">Invitar personas</h4>
              <div className="flex gap-2">
                <Input
                  type="email"
                  placeholder="correo@ejemplo.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleInvite()}
                  className="flex-1"
                />
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="editor">Editor</SelectItem>
                    <SelectItem value="viewer">Observador</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={handleInvite}
                disabled={!email.trim()}
                className="w-full bg-[#0073EA] hover:bg-[#0056B3]"
              >
                <Mail className="w-4 h-4 mr-2" />
                Enviar Invitación
              </Button>
            </div>
          )}

          {/* Copiar enlace */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium">Enlace compartible</h4>
            <div className="flex gap-2">
              <Input
                value={`${window.location.origin}/whiteboard/${whiteboardId}`}
                readOnly
                className="flex-1"
              />
              <Button 
                variant="outline"
                size="icon"
                onClick={handleCopyLink}
              >
                {linkCopied ? (
                  <Check className="w-4 h-4 text-green-600" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
            <p className="text-xs text-gray-500">
              Cualquiera con el enlace podrá ver este whiteboard
            </p>
          </div>

          {/* Lista de usuarios con acceso */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium">
              Personas con acceso ({permissions.length})
            </h4>
            <div className="max-h-64 overflow-y-auto space-y-2">
              {permissions.map((permission) => {
                const Icon = ROLE_ICONS[permission.role];
                const isCurrentUser = permission.user_email === currentUserEmail;
                const canModify = isOwner && !isCurrentUser && permission.role !== 'owner';

                return (
                  <div 
                    key={permission.id}
                    className="flex items-center justify-between p-3 rounded-lg border hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                        {permission.user_email.substring(0, 2).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {permission.user_email}
                          </p>
                          {isCurrentUser && (
                            <Badge variant="outline" className="text-xs">Tú</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-1 mt-1">
                          <Icon className={`w-3 h-3 ${ROLE_COLORS[permission.role].split(' ')[0]}`} />
                          <span className={`text-xs px-2 py-0.5 rounded-full ${ROLE_COLORS[permission.role]}`}>
                            {ROLE_LABELS[permission.role]}
                          </span>
                        </div>
                      </div>
                    </div>

                    {canModify && (
                      <div className="flex items-center gap-2">
                        <Select
                          value={permission.role}
                          onValueChange={(value) => handleRoleChange(permission.id, value)}
                        >
                          <SelectTrigger className="w-28 h-8 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="editor">Editor</SelectItem>
                            <SelectItem value="viewer">Observador</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-red-500 hover:text-red-700"
                          onClick={() => handleRemove(permission.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
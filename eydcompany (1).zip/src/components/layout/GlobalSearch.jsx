import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Search, Folder, FileText, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";

export default function GlobalSearch({ isOpen, onClose }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState({ boards: [], items: [] });
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!query.trim()) {
      setResults({ boards: [], items: [] });
      return;
    }

    const searchTimeout = setTimeout(async () => {
      setIsLoading(true);
      try {
        const [boards, items] = await Promise.all([
          base44.entities.Board.list(),
          base44.entities.Item.list()
        ]);

        const lowercaseQuery = query.toLowerCase();
        const filteredBoards = boards.filter(board =>
          board.title.toLowerCase().includes(lowercaseQuery) ||
          board.description?.toLowerCase().includes(lowercaseQuery)
        );

        const filteredItems = items.filter(item =>
          item.name?.toLowerCase().includes(lowercaseQuery)
        );

        setResults({
          boards: filteredBoards.slice(0, 5),
          items: filteredItems.slice(0, 5)
        });
      } catch (error) {
        console.error("Error en búsqueda:", error);
      }
      setIsLoading(false);
    }, 300);

    return () => clearTimeout(searchTimeout);
  }, [query]);

  const handleResultClick = (type, id) => {
    if (type === 'board') {
      navigate(createPageUrl(`BoardDetail?id=${id}`));
    }
    onClose();
    setQuery("");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden p-0">
        <DialogHeader className="px-6 pt-6 pb-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Buscar tableros, tareas..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-10 h-12 text-lg border-0 focus-visible:ring-0 shadow-none"
              autoFocus
            />
          </div>
        </DialogHeader>

        <div className="overflow-y-auto max-h-[60vh] px-6 pb-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
            </div>
          ) : query.trim() === "" ? (
            <div className="text-center py-12 text-gray-500">
              <Search className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>Escribe para buscar en tus tableros y tareas</p>
            </div>
          ) : results.boards.length === 0 && results.items.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Search className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>No se encontraron resultados para "{query}"</p>
            </div>
          ) : (
            <div className="space-y-6">
              {results.boards.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-500 mb-3 uppercase tracking-wide">
                    Tableros ({results.boards.length})
                  </h3>
                  <div className="space-y-2">
                    {results.boards.map((board) => (
                      <button
                        key={board.id}
                        onClick={() => handleResultClick('board', board.id)}
                        className="w-full flex items-start gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors text-left"
                      >
                        <div
                          className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: board.color || '#0073EA' }}
                        >
                          <Folder className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-gray-900 truncate">
                            {board.title}
                          </h4>
                          {board.description && (
                            <p className="text-sm text-gray-500 truncate">
                              {board.description}
                            </p>
                          )}
                          <p className="text-xs text-gray-400 mt-1">
                            Actualizado {formatDistanceToNow(new Date(board.updated_date), { 
                              addSuffix: true,
                              locale: es 
                            })}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {results.items.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-500 mb-3 uppercase tracking-wide">
                    Tareas ({results.items.length})
                  </h3>
                  <div className="space-y-2">
                    {results.items.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => handleResultClick('item', item.id)}
                        className="w-full flex items-start gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors text-left"
                      >
                        <div className="w-10 h-10 rounded-lg bg-gray-200 flex items-center justify-center flex-shrink-0">
                          <FileText className="w-5 h-5 text-gray-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-gray-900 truncate">
                            {item.name}
                          </h4>
                          <p className="text-xs text-gray-400 mt-1">
                            Actualizado {formatDistanceToNow(new Date(item.updated_date), { 
                              addSuffix: true,
                              locale: es 
                            })}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
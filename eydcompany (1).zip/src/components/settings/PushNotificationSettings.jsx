import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bell, BellOff, Smartphone, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { 
  requestNotificationPermission, 
  subscribeToPushNotifications, 
  unsubscribeFromPushNotifications, 
  isPushNotificationSubscribed, 
  showTestNotification,
  registerServiceWorker
} from '../utils/pushNotifications';
import { base44 } from '@/api/base44Client';

export default function PushNotificationSettings() {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [permission, setPermission] = useState('default');
  const [isSupported, setIsSupported] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    checkStatus();
  }, []);

  const checkStatus = async () => {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      setIsSupported(false);
      return;
    }

    setPermission(Notification.permission);
    const subscribed = await isPushNotificationSubscribed();
    setIsSubscribed(subscribed);
  };

  const handleSubscribe = async () => {
    setIsLoading(true);
    try {
      // Asegurar que SW está registrado
      await registerServiceWorker();

      const perm = await requestNotificationPermission();
      setPermission(perm);

      if (perm === 'granted') {
        const user = await base44.auth.me();
        await subscribeToPushNotifications(user);
        setIsSubscribed(true);
        toast({
          title: "✓ Notificaciones Activadas",
          description: "Ahora recibirás notificaciones push en este dispositivo."
        });
        
        // Prueba automática
        setTimeout(() => showTestNotification(), 1000);
      } else {
        toast({
          title: "Permiso denegado",
          description: "Necesitas dar permiso para recibir notificaciones.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "No se pudo activar las notificaciones.",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  const handleUnsubscribe = async () => {
    setIsLoading(true);
    try {
      await unsubscribeFromPushNotifications();
      setIsSubscribed(false);
      toast({
        title: "Notificaciones Desactivadas",
        description: "Ya no recibirás notificaciones push en este dispositivo."
      });
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "No se pudo desactivar las notificaciones.",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  const handleTest = async () => {
    try {
      await showTestNotification();
      toast({
        title: "Prueba Enviada",
        description: "Deberías ver una notificación en breve."
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo enviar la prueba.",
        variant: "destructive"
      });
    }
  };

  if (!isSupported) {
    return (
      <Card className="bg-gray-50">
        <CardHeader>
          <CardTitle className="text-gray-500 flex items-center gap-2">
            <AlertCircle className="w-5 h-5" />
            No Soportado
          </CardTitle>
          <CardDescription>
            Tu navegador no soporta notificaciones push.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            Notificaciones Push
          </div>
          {isSubscribed ? (
            <Badge className="bg-green-600 hover:bg-green-700">Activo</Badge>
          ) : (
            <Badge variant="secondary">Inactivo</Badge>
          )}
        </CardTitle>
        <CardDescription>
          Recibe alertas importantes incluso cuando la app está cerrada.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between p-4 border rounded-lg bg-white">
          <div className="space-y-1">
            <h4 className="font-medium text-sm">Estado del Dispositivo</h4>
            <p className="text-xs text-gray-500">
              {isSubscribed 
                ? "Este dispositivo está recibiendo notificaciones." 
                : "Activa las notificaciones para estar al día."}
            </p>
            {permission === 'denied' && (
              <p className="text-xs text-red-500 font-medium">
                Permiso bloqueado en el navegador.
              </p>
            )}
          </div>
          
          <div className="flex gap-2 w-full sm:w-auto">
            {!isSubscribed ? (
              <Button 
                onClick={handleSubscribe} 
                disabled={isLoading || permission === 'denied'}
                className="bg-[#0073EA] hover:bg-[#0056B3] flex-1 sm:flex-none"
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bell className="w-4 h-4 mr-2" />}
                Activar
              </Button>
            ) : (
              <>
                <Button 
                  variant="outline" 
                  onClick={handleTest}
                  className="flex-1 sm:flex-none"
                >
                  Probar
                </Button>
                <Button 
                  variant="outline" 
                  onClick={handleUnsubscribe}
                  disabled={isLoading}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50 flex-1 sm:flex-none"
                >
                  {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <BellOff className="w-4 h-4 mr-2" />}
                  Desactivar
                </Button>
              </>
            )}
          </div>
        </div>
        
        <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-100">
          <h4 className="text-sm font-medium text-blue-900 mb-2">Instalación en Móvil (PWA)</h4>
          <ul className="text-xs text-blue-800 space-y-1 list-disc pl-4">
            <li><strong>Android (Chrome):</strong> Menú &rarr; Instalar aplicación</li>
            <li><strong>iOS (Safari):</strong> Compartir &rarr; Agregar a Inicio</li>
            <li>Es necesario instalar la app para recibir notificaciones estables en segundo plano.</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Play, Pause, Trash2, Clock, CheckCircle2, Calendar as CalendarIcon } from "lucide-react";
import { format } from "date-fns";

export default function EventDetailsModal({ isOpen, onClose, event, onUpdate, onDelete, isTask = false }) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [timerStart, setTimerStart] = useState(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  
  const [formData, setFormData] = useState({});

  useEffect(() => {
    if (event) {
      setFormData({
        ...event,
        // Ensure dates are in correct format for inputs if editing
      });
      
      // Simple timer simulation logic (in real app, store timer state in DB or local storage)
      setElapsedSeconds(0);
      setIsTimerRunning(false);
      setTimerStart(null);
    }
  }, [event]);

  useEffect(() => {
    let interval;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setElapsedSeconds(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  const handleSave = async () => {
    setLoading(true);
    try {
      const entity = isTask ? base44.entities.TodoTask : base44.entities.CalendarEvent;
      await entity.update(event.id, formData);
      toast({ title: "Actualizado correctamente" });
      onUpdate();
      setIsEditing(false);
    } catch (error) {
      toast({ title: "Error al actualizar", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm("¿Estás seguro de eliminar esto?")) return;
    setLoading(true);
    try {
      const entity = isTask ? base44.entities.TodoTask : base44.entities.CalendarEvent;
      await entity.delete(event.id);
      toast({ title: "Eliminado correctamente" });
      onDelete();
      onClose();
    } catch (error) {
      toast({ title: "Error al eliminar", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const toggleTimer = async () => {
    if (isTimerRunning) {
      // Stop timer
      setIsTimerRunning(false);
      const hoursToAdd = elapsedSeconds / 3600;
      const newLogged = (Number(formData.logged_hours) || 0) + hoursToAdd;
      
      setFormData(prev => ({ ...prev, logged_hours: newLogged }));
      
      // Save immediately
      try {
        await base44.entities.TodoTask.update(event.id, { logged_hours: newLogged });
        toast({ title: "Tiempo registrado", description: `Se añadieron ${hoursToAdd.toFixed(2)} horas.` });
        onUpdate();
      } catch (e) {
        console.error(e);
      }
    } else {
      // Start timer
      setIsTimerRunning(true);
      setTimerStart(new Date());
    }
  };

  const formatTime = (totalSeconds) => {
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (!event) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <div className="flex items-center justify-between mr-8">
            <DialogTitle className="text-xl font-bold truncate">{isEditing ? 'Editar' : event.title}</DialogTitle>
            {!isEditing && isTask && (
              <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${
                event.status === 'done' ? 'bg-green-100 text-green-700' : 
                event.status === 'in_progress' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'
              }`}>
                {event.status === 'done' ? <CheckCircle2 className="w-4 h-4"/> : <Clock className="w-4 h-4"/>}
                {event.status}
              </div>
            )}
          </div>
        </DialogHeader>

        <div className="py-4 space-y-4">
          {isEditing ? (
            <>
              <div className="space-y-2">
                <Label>Título</Label>
                <Input value={formData.title} onChange={(e) => setFormData({...formData, title: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Descripción</Label>
                <Textarea value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})} />
              </div>
              {isTask && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Estado</Label>
                    <Select value={formData.status} onValueChange={(val) => setFormData({...formData, status: val})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todo">Por hacer</SelectItem>
                        <SelectItem value="in_progress">En progreso</SelectItem>
                        <SelectItem value="review">Revisión</SelectItem>
                        <SelectItem value="done">Completado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Prioridad</Label>
                    <Select value={formData.priority} onValueChange={(val) => setFormData({...formData, priority: val})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Baja</SelectItem>
                        <SelectItem value="medium">Media</SelectItem>
                        <SelectItem value="high">Alta</SelectItem>
                        <SelectItem value="urgent">Urgente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              {event.description && (
                <div className="bg-gray-50 p-3 rounded-md text-gray-700 text-sm whitespace-pre-wrap">
                  {event.description}
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                {!isTask && (
                  <>
                    <div>
                      <span className="text-gray-500 block">Inicio</span>
                      <span className="font-medium">{format(new Date(event.start_date), "PPP p")}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">Fin</span>
                      <span className="font-medium">{format(new Date(event.end_date), "PPP p")}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">Ubicación</span>
                      <span className="font-medium">{event.location || "-"}</span>
                    </div>
                  </>
                )}
                {isTask && (
                  <>
                    <div>
                      <span className="text-gray-500 block">Fecha límite</span>
                      <span className="font-medium">{event.due_date ? format(new Date(event.due_date), "PPP") : "-"}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">Prioridad</span>
                      <span className="capitalize font-medium">{event.priority}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">Estimado</span>
                      <span className="font-medium">{event.estimated_hours || 0}h</span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">Registrado</span>
                      <span className="font-medium">{(event.logged_hours || 0).toFixed(2)}h</span>
                    </div>
                  </>
                )}
              </div>

              {/* Time Tracking for Tasks */}
              {isTask && (
                <div className="border-t pt-4 mt-2">
                  <Label className="mb-2 block">Time Tracking</Label>
                  <div className="flex items-center gap-4 bg-blue-50 p-3 rounded-lg border border-blue-100">
                    <div className="flex-1">
                      <div className="text-2xl font-mono font-bold text-blue-700">
                        {formatTime(elapsedSeconds)}
                      </div>
                      <p className="text-xs text-blue-600">
                        {isTimerRunning ? "Registrando tiempo..." : "Temporizador detenido"}
                      </p>
                    </div>
                    <Button 
                      size="sm" 
                      onClick={toggleTimer}
                      className={isTimerRunning ? "bg-red-500 hover:bg-red-600" : "bg-green-600 hover:bg-green-700"}
                    >
                      {isTimerRunning ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                      {isTimerRunning ? "Detener" : "Iniciar"}
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        <DialogFooter className="flex justify-between sm:justify-between gap-2">
          <div className="flex gap-2">
            <Button variant="destructive" size="icon" onClick={handleDelete} disabled={loading}>
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex gap-2">
            {isEditing ? (
              <>
                <Button variant="outline" onClick={() => setIsEditing(false)}>Cancelar</Button>
                <Button onClick={handleSave} disabled={loading}>Guardar</Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={onClose}>Cerrar</Button>
                <Button onClick={() => setIsEditing(true)}>Editar</Button>
              </>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
import React from 'react';
import { Lock } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function ElementLockIndicator({ element, lockedBy, zoom }) {
  if (!lockedBy) return null;

  const getUserInitials = (name) => {
    const parts = name.split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  return (
    <g transform={`translate(${element.position.x}, ${element.position.y})`}>
      {/* Borde pulsante */}
      <rect
        width={element.size?.width || 0}
        height={element.size?.height || 0}
        fill="none"
        stroke={lockedBy.user_color}
        strokeWidth={3 / zoom}
        rx="8"
        className="pointer-events-none"
        style={{
          animation: 'pulse 1.5s infinite'
        }}
      />

      {/* Indicador de bloqueo */}
      <foreignObject
        x={(element.size?.width || 0) - 35}
        y={-10}
        width="35"
        height="35"
      >
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center shadow-lg cursor-pointer"
                style={{ backgroundColor: lockedBy.user_color }}
              >
                <Lock className="w-4 h-4 text-white" />
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p className="font-medium">{lockedBy.user_name} está editando</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </foreignObject>

      <style jsx>{`
        @keyframes pulse {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0.5;
          }
        }
      `}</style>
    </g>
  );
}
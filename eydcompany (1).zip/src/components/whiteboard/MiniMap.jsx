import React from 'react';

export default function MiniMap({ elements, zoom, pan, containerSize, onPanChange }) {
  const miniMapSize = 150;
  const miniMapPadding = 16;

  // Calcular los límites del contenido
  const bounds = elements.reduce(
    (acc, el) => {
      const right = el.position.x + (el.size?.width || 0);
      const bottom = el.position.y + (el.size?.height || 0);
      return {
        minX: Math.min(acc.minX, el.position.x),
        minY: Math.min(acc.minY, el.position.y),
        maxX: Math.max(acc.maxX, right),
        maxY: Math.max(acc.maxY, bottom)
      };
    },
    { minX: 0, minY: 0, maxX: 1000, maxY: 1000 }
  );

  const contentWidth = bounds.maxX - bounds.minX;
  const contentHeight = bounds.maxY - bounds.minY;

  // Escala para el minimapa
  const scale = Math.min(
    miniMapSize / contentWidth,
    miniMapSize / contentHeight,
    0.1
  );

  // Viewport en el minimapa
  const viewportWidth = (containerSize.width / zoom) * scale;
  const viewportHeight = (containerSize.height / zoom) * scale;
  const viewportX = (-pan.x / zoom - bounds.minX) * scale;
  const viewportY = (-pan.y / zoom - bounds.minY) * scale;

  return (
    <div 
      className="absolute bottom-4 right-4 bg-white rounded-lg shadow-lg border border-[#E1E5F3] p-2"
      style={{ width: miniMapSize + miniMapPadding * 2, height: miniMapSize + miniMapPadding * 2 }}
    >
      <svg width={miniMapSize} height={miniMapSize} className="bg-gray-50 rounded">
        {/* Grid background */}
        <pattern id="minimap-grid" width="10" height="10" patternUnits="userSpaceOnUse">
          <circle cx="5" cy="5" r="0.5" fill="#CBD5E1" opacity="0.5" />
        </pattern>
        <rect width={miniMapSize} height={miniMapSize} fill="url(#minimap-grid)" />

        {/* Elements */}
        <g transform={`translate(${-bounds.minX * scale}, ${-bounds.minY * scale})`}>
          {elements.map((el) => {
            const x = el.position.x * scale;
            const y = el.position.y * scale;
            const w = (el.size?.width || 50) * scale;
            const h = (el.size?.height || 50) * scale;

            let color = '#94A3B8';
            if (el.type === 'sticky_note') {
              color = el.properties?.color || '#FFEB3B';
            }

            return (
              <rect
                key={el.id}
                x={x}
                y={y}
                width={w}
                height={h}
                fill={color}
                opacity="0.6"
                stroke="#64748B"
                strokeWidth="0.5"
              />
            );
          })}
        </g>

        {/* Viewport indicator */}
        <rect
          x={Math.max(0, Math.min(miniMapSize - viewportWidth, viewportX))}
          y={Math.max(0, Math.min(miniMapSize - viewportHeight, viewportY))}
          width={Math.min(viewportWidth, miniMapSize)}
          height={Math.min(viewportHeight, miniMapSize)}
          fill="none"
          stroke="#0073EA"
          strokeWidth="2"
          rx="2"
        />
      </svg>
      
      <div className="text-[10px] text-gray-500 text-center mt-1">
        Minimapa
      </div>
    </div>
  );
}
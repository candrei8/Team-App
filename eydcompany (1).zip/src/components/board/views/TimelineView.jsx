import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Calendar } from "lucide-react";
import { format, addDays, subDays, startOfWeek, endOfWeek, eachDayOfInterval, differenceInDays, isWithinInterval, addMonths, subMonths, startOfMonth, endOfMonth } from 'date-fns';
import { es } from 'date-fns/locale';

const TIMELINE_ITEM_HEIGHT = 40;
const DAY_CELL_WIDTH = 50;

const TimelineItemBar = ({ item, board, startDate, endDate, timelineStartDate, zoomLevel, onUpdate }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [dragStartX, setDragStartX] = useState(0);
  const [currentOffset, setCurrentOffset] = useState(0);

  const itemStartDateStr = item.data?.startDate;
  const itemEndDateStr = item.data?.endDate || item.data?.due_date;

  if (!itemStartDateStr || !itemEndDateStr) return null;

  const itemStart = new Date(itemStartDateStr);
  const itemEnd = new Date(itemEndDateStr);

  if (isNaN(itemStart.getTime()) || isNaN(itemEnd.getTime())) return null;
  
  const displayStart = itemStart > itemEnd ? itemEnd : itemStart;
  const displayEnd = itemStart > itemEnd ? itemStart : itemEnd;

  if (!isWithinInterval(displayStart, { start: timelineStartDate, end: endDate }) && 
      !isWithinInterval(displayEnd, { start: timelineStartDate, end: endDate }) &&
      !(displayStart < timelineStartDate && displayEnd > endDate)) {
    return null;
  }

  const offsetDays = Math.max(0, differenceInDays(displayStart, timelineStartDate));
  let durationDays = differenceInDays(displayEnd, displayStart) + 1;
  
  if (displayStart < timelineStartDate) {
    durationDays = differenceInDays(displayEnd, timelineStartDate) + 1;
  }
  if (displayEnd > endDate) {
    durationDays = differenceInDays(endDate, displayStart < timelineStartDate ? timelineStartDate : displayStart) + 1;
  }
  durationDays = Math.max(1, durationDays);

  const cellWidth = zoomLevel === 'week' ? DAY_CELL_WIDTH : (zoomLevel === 'month' ? DAY_CELL_WIDTH * 0.6 : DAY_CELL_WIDTH * 0.4);
  const baseLeft = offsetDays * cellWidth;
  const width = durationDays * cellWidth - 4;

  const priorityColumn = board?.columns?.find(col => col.type === 'priority');
  const priorityValue = item.data?.[priorityColumn?.id];
  const priorityOption = priorityColumn?.options?.choices?.find(c => c.value === priorityValue);
  const barColor = priorityOption?.color || board?.color || '#0073EA';

  const handleMouseDown = (e) => {
    e.preventDefault();
    setIsDragging(true);
    setDragStartX(e.clientX);
    setCurrentOffset(0);
  };

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e) => {
      const deltaX = e.clientX - dragStartX;
      setCurrentOffset(deltaX);
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      
      if (Math.abs(currentOffset) < cellWidth / 2) {
        setCurrentOffset(0);
        return;
      }

      const daysDelta = Math.round(currentOffset / cellWidth);
      
      if (daysDelta !== 0) {
        const newStartDate = addDays(displayStart, daysDelta);
        const newEndDate = addDays(displayEnd, daysDelta);
        
        const startDateColumn = board?.columns?.find(c => c.id === 'startDate' || c.type === 'date');
        const endDateColumn = board?.columns?.find(c => c.id === 'endDate' || c.id === 'due_date');
        
        if (startDateColumn && endDateColumn) {
          onUpdate(item.id, {
            data: {
              ...item.data,
              [startDateColumn.id]: format(newStartDate, 'yyyy-MM-dd'),
              [endDateColumn.id]: format(newEndDate, 'yyyy-MM-dd')
            }
          });
        }
      }
      
      setCurrentOffset(0);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragStartX, currentOffset, cellWidth, displayStart, displayEnd, item, board, onUpdate]);

  return (
    <div
      className={`absolute h-[32px] rounded-lg flex items-center px-3 text-white text-sm font-medium truncate shadow-md transition-all ${
        isDragging ? 'cursor-grabbing scale-105 shadow-xl z-50' : 'cursor-grab hover:shadow-lg hover:scale-102'
      }`}
      style={{
        left: `${baseLeft + currentOffset}px`,
        width: `${width}px`,
        top: '4px',
        backgroundColor: barColor,
        opacity: isDragging ? 0.8 : 0.9,
        transform: isDragging ? 'translateY(-2px)' : 'translateY(0)',
        transition: isDragging ? 'none' : 'all 0.2s ease'
      }}
      onMouseDown={handleMouseDown}
      title={`${item.title} (${format(displayStart, 'MMM d', { locale: es })} - ${format(displayEnd, 'MMM d', { locale: es })})`}
    >
      <span className="truncate">{item.title}</span>
    </div>
  );
};

export default function TimelineView({ board, items, onUpdateItem }) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [zoomLevel, setZoomLevel] = useState('week');
  const [startDateColId, setStartDateColId] = useState(null);
  const [endDateColId, setEndDateColId] = useState(null);

  useEffect(() => {
    const dateCols = board?.columns?.filter(col => col.type === 'date');
    if (dateCols?.length >= 2) {
      setStartDateColId(dateCols[0].id);
      setEndDateColId(dateCols[1].id);
    } else if (dateCols?.length === 1) {
      setStartDateColId(dateCols[0].id);
      setEndDateColId(dateCols[0].id);
    } else {
      const sDate = board?.columns?.find(c => c.id === 'startDate' || c.title.toLowerCase().includes('start'))?.id;
      const eDate = board?.columns?.find(c => c.id === 'endDate' || c.id === 'due_date' || c.title.toLowerCase().includes('end') || c.title.toLowerCase().includes('due'))?.id;
      if (sDate) setStartDateColId(sDate);
      if (eDate) setEndDateColId(eDate);
    }
  }, [board]);

  const { timelineStartDate, timelineEndDate, daysHeader } = useMemo(() => {
    let start, end;
    if (zoomLevel === 'day') {
      start = currentDate;
      end = addDays(currentDate, 6);
    } else if (zoomLevel === 'week') {
      start = startOfWeek(currentDate, { weekStartsOn: 1 });
      end = endOfWeek(currentDate, { weekStartsOn: 1 });
    } else {
      start = startOfMonth(currentDate);
      end = endOfMonth(currentDate);
    }
    const days = eachDayOfInterval({ start, end });
    return { timelineStartDate: start, timelineEndDate: end, daysHeader: days };
  }, [currentDate, zoomLevel]);

  const handlePrev = () => {
    if (zoomLevel === 'day') setCurrentDate(subDays(currentDate, 7));
    else if (zoomLevel === 'week') setCurrentDate(subDays(currentDate, 7));
    else setCurrentDate(subMonths(currentDate, 1));
  };

  const handleNext = () => {
    if (zoomLevel === 'day') setCurrentDate(addDays(currentDate, 7));
    else if (zoomLevel === 'week') setCurrentDate(addDays(currentDate, 7));
    else setCurrentDate(addMonths(currentDate, 1));
  };
  
  const getHeaderLabel = () => {
    if (zoomLevel === 'day') return `${format(timelineStartDate, 'MMM d')} - ${format(timelineEndDate, 'MMM d, yyyy')}`;
    if (zoomLevel === 'week') return `Semana del ${format(timelineStartDate, 'MMM d, yyyy', { locale: es })}`;
    return format(currentDate, 'MMMM yyyy', { locale: es });
  };

  if (!board) return <div className="p-4 text-center text-gray-500">Datos del tablero no disponibles.</div>;

  if (!startDateColId || !endDateColId) {
    return (
      <div className="p-8 text-center">
        <div className="max-w-md mx-auto bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <Calendar className="w-12 h-12 text-yellow-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Vista Gantt no disponible
          </h3>
          <p className="text-sm text-gray-600">
            La vista de línea de tiempo requiere al menos una columna de tipo "Fecha" (idealmente dos para fechas de inicio y fin).
          </p>
        </div>
      </div>
    );
  }

  const displayItems = items.filter(item => item.data?.[startDateColId] && item.data?.[endDateColId || startDateColId]);

  const cellWidth = zoomLevel === 'week' ? DAY_CELL_WIDTH : (zoomLevel === 'month' ? DAY_CELL_WIDTH * 0.6 : DAY_CELL_WIDTH * 0.4);

  return (
    <Card className="shadow-lg border-gray-200 overflow-hidden">
      <CardHeader className="p-4 border-b flex flex-row items-center justify-between sticky top-0 bg-white z-10">
        <CardTitle className="text-lg font-semibold text-gray-900">{getHeaderLabel()}</CardTitle>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" className="h-9 w-9" onClick={handlePrev}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="sm" className="h-9" onClick={() => setCurrentDate(new Date())}>
            Hoy
          </Button>
          <Button variant="outline" size="icon" className="h-9 w-9" onClick={handleNext}>
            <ChevronRight className="w-4 h-4" />
          </Button>
          <select 
            value={zoomLevel} 
            onChange={(e) => setZoomLevel(e.target.value)} 
            className="h-9 border border-gray-300 rounded-md px-3 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="day">Día</option>
            <option value="week">Semana</option>
            <option value="month">Mes</option>
          </select>
        </div>
      </CardHeader>
      <CardContent className="p-0 overflow-x-auto">
        <div className="min-w-max">
          {/* Timeline Header */}
          <div className="flex sticky top-[65px] bg-gray-50 z-[5] border-b">
            <div className="w-[250px] flex-shrink-0 p-3 border-r font-semibold text-sm text-gray-700">
              Tarea
            </div>
            {daysHeader.map(day => (
              <div
                key={day.toString()}
                className="flex-shrink-0 text-center p-2 border-r"
                style={{ width: `${cellWidth}px` }}
              >
                <div className="text-xs text-gray-500 font-medium">
                  {format(day, 'EEE', { locale: es })}
                </div>
                <div className="text-base font-semibold text-gray-900">
                  {format(day, 'd')}
                </div>
              </div>
            ))}
          </div>

          {/* Timeline Rows */}
          <div className="relative">
            {displayItems.map((item, index) => (
              <div 
                key={item.id} 
                className="flex border-b hover:bg-gray-50 transition-colors" 
                style={{ height: `${TIMELINE_ITEM_HEIGHT}px` }}
              >
                <div className="w-[250px] flex-shrink-0 p-3 border-r text-sm font-medium text-gray-900 truncate" title={item.title}>
                  {item.title}
                </div>
                <div className="flex-grow relative h-full">
                  {daysHeader.map((day) => (
                    <div 
                      key={day.toString()} 
                      className="absolute border-r border-gray-100"
                      style={{ 
                        left: `${differenceInDays(day, timelineStartDate) * cellWidth}px`,
                        width: `${cellWidth}px`,
                        height: '100%'
                      }}
                    />
                  ))}
                  <TimelineItemBar 
                    item={item} 
                    board={board}
                    startDate={item.data[startDateColId]} 
                    endDate={item.data[endDateColId || startDateColId]}
                    timelineStartDate={timelineStartDate}
                    timelineEndDate={timelineEndDate}
                    zoomLevel={zoomLevel}
                    onUpdate={onUpdateItem}
                  />
                </div>
              </div>
            ))}
            {displayItems.length === 0 && (
              <div className="p-12 text-center text-gray-500">
                <Calendar className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-base">No hay tareas con fechas válidas para mostrar</p>
                <p className="text-sm text-gray-400 mt-2">
                  Añade fechas de inicio y fin a tus tareas para verlas en el Gantt
                </p>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
import React from 'react';
import { Button } from "@/components/ui/button";
import { 
  MousePointer, 
  Hand, 
  StickyNote, 
  Square, 
  Circle, 
  Type,
  ArrowRight,
  Image,
  Trash2,
  Undo2,
  Redo2
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const COLORS = [
  { name: 'Amarillo', value: '#FFEB3B' },
  { name: 'Rosa', value: '#F48FB1' },
  { name: 'Azul', value: '#64B5F6' },
  { name: 'Verde', value: '#81C784' },
  { name: 'Naranja', value: '#FFB74D' },
  { name: 'Púrpura', value: '#BA68C8' },
];

const TOOLS = [
  { id: 'select', label: 'Seleccionar', icon: MousePointer, shortcut: 'V' },
  { id: 'hand', label: 'Mover canvas', icon: Hand, shortcut: 'H' },
  { id: 'sticky_note', label: 'Nota adhesiva', icon: StickyNote, shortcut: 'N' },
  { id: 'shape', label: 'Forma', icon: Square, shortcut: 'R' },
  { id: 'text', label: 'Texto', icon: Type, shortcut: 'T' },
  { id: 'connector', label: 'Conector', icon: ArrowRight, shortcut: 'C' },
  { id: 'image', label: 'Imagen', icon: Image, shortcut: 'I' },
];

export default function WhiteboardToolbar({ 
  activeTool, 
  onToolChange, 
  activeColor, 
  onColorChange,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  onDelete,
  hasSelection
}) {
  return (
    <TooltipProvider>
      <div className="w-16 bg-white border-r border-[#E1E5F3] flex flex-col items-center py-4 gap-2 shadow-sm">
        {/* Tools */}
        <div className="flex flex-col gap-1">
          {TOOLS.map((tool) => {
            const Icon = tool.icon;
            return (
              <Tooltip key={tool.id}>
                <TooltipTrigger asChild>
                  <Button
                    variant={activeTool === tool.id ? "default" : "ghost"}
                    size="icon"
                    className={`w-12 h-12 rounded-lg transition-all ${
                      activeTool === tool.id 
                        ? 'bg-[#0073EA] text-white hover:bg-[#0056B3]' 
                        : 'hover:bg-gray-100'
                    }`}
                    onClick={() => onToolChange(tool.id)}
                  >
                    <Icon className="w-5 h-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="right">
                  <p>{tool.label} ({tool.shortcut})</p>
                </TooltipContent>
              </Tooltip>
            );
          })}
        </div>

        <div className="my-2 h-px w-10 bg-gray-200"></div>

        {/* Color picker */}
        <div className="flex flex-col gap-1">
          {COLORS.map((color) => (
            <Tooltip key={color.value}>
              <TooltipTrigger asChild>
                <button
                  className={`w-8 h-8 rounded-md border-2 transition-all ${
                    activeColor === color.value 
                      ? 'border-[#0073EA] scale-110 shadow-lg' 
                      : 'border-gray-300 hover:scale-105'
                  }`}
                  style={{ backgroundColor: color.value }}
                  onClick={() => onColorChange(color.value)}
                />
              </TooltipTrigger>
              <TooltipContent side="right">
                <p>{color.name}</p>
              </TooltipContent>
            </Tooltip>
          ))}
        </div>

        <div className="my-2 h-px w-10 bg-gray-200"></div>

        {/* History */}
        <div className="flex flex-col gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-12 h-12 rounded-lg"
                onClick={onUndo}
                disabled={!canUndo}
              >
                <Undo2 className="w-5 h-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="right">
              <p>Deshacer (Ctrl+Z)</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-12 h-12 rounded-lg"
                onClick={onRedo}
                disabled={!canRedo}
              >
                <Redo2 className="w-5 h-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="right">
              <p>Rehacer (Ctrl+Shift+Z)</p>
            </TooltipContent>
          </Tooltip>
        </div>

        <div className="my-2 h-px w-10 bg-gray-200"></div>

        {/* Delete */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="w-12 h-12 rounded-lg text-red-500 hover:text-red-700 hover:bg-red-50"
              onClick={onDelete}
              disabled={!hasSelection}
            >
              <Trash2 className="w-5 h-5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="right">
            <p>Eliminar (Supr)</p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}
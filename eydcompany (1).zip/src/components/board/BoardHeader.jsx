
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  ArrowLeft,
  Star,
  Users,
  Activity,
  Table2,
  ChevronDown,
  TrendingUp,
  Edit3,
  Save,
  UserPlus,
  Mail,
  MessageSquare,
  Zap,
  UserMinus,
  Menu
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";

export default function BoardHeader({
  board,
  items,
  itemsCount,
  selectedCount,
  currentView,
  onViewChange,
  onShowAnalytics,
  onShowIntegrations,
  onShowAutomations
}) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(board?.title || '');
  const [lastSaved, setLastSaved] = useState(new Date());
  const [collaborators, setCollaborators] = useState([
    { id: 1, name: 'John Doe', avatar: 'JD', online: true, role: 'Propietario' },
    { id: 2, name: 'Jane Smith', avatar: 'JS', online: true, role: 'Editor' },
    { id: 3, name: 'Mike Johnson', avatar: 'MJ', online: false, role: 'Visualizador' },
    { id: 4, name: 'Sarah Wilson', avatar: 'SW', online: true, role: 'Editor' },
  ]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setLastSaved(new Date());
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (board?.title) {
      setEditedTitle(board.title);
    }
  }, [board?.title]);

  const boardColor = board?.color || '#0073EA';

  const handleSaveTitle = () => {
    setIsEditing(false);
    console.log('Guardando título:', editedTitle);
  };

  const handleToggleFavorite = () => {
    setIsFavorited(!isFavorited);
  };

  const viewLabels = {
    table: 'Tabla Principal',
    kanban: 'Kanban',
    calendar: 'Calendario',
    timeline: 'Línea de Tiempo',
    unassigned: 'Tareas Sin Asignar'
  };

  return (
    <TooltipProvider>
      <div className="bg-white sticky top-16 z-40 shadow-sm border-b border-[#E1E5F3]">
        <motion.div
          className="absolute top-0 left-0 right-0 h-1"
          style={{ backgroundColor: boardColor }}
          initial={{ scaleX: 0 }}
          animate={{ scaleX: isScrolled ? 1 : 0 }}
          transition={{ duration: 0.3, ease: "easeInOut", originX: 0 }}
        />

        <div className="px-3 md:px-4 lg:px-6 py-2 md:py-3">
          <div className="flex items-center gap-2 md:gap-3 lg:gap-4">
            {/* Left Section - Fixed width elements */}
            <div className="flex items-center gap-2 md:gap-3 flex-shrink-0">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link to={createPageUrl("Boards")}>
                    <Button variant="ghost" size="icon" className="hover:bg-[#E1E5F3] rounded-lg h-8 w-8 md:h-9 md:w-9 flex-shrink-0">
                      <ArrowLeft className="w-4 h-4" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>Volver a Tableros</TooltipContent>
              </Tooltip>

              <motion.div
                className="w-8 h-8 md:w-10 md:h-10 rounded-lg md:rounded-xl flex items-center justify-center shadow-lg relative overflow-hidden flex-shrink-0"
                style={{ backgroundColor: boardColor }}
                whileHover={{ scale: 1.05, rotate: 5 }}
                whileTap={{ scale: 0.95 }}
              >
                <Table2 className="w-4 h-4 md:w-5 md:h-5 text-white" />
                <motion.div
                  className="absolute inset-0 bg-white/20"
                  initial={{ x: '-100%' }}
                  whileHover={{ x: '100%' }}
                  transition={{ duration: 0.6 }}
                />
              </motion.div>
            </div>

            {/* Middle Section - Title and metadata (flexible) */}
            <div className="flex-1 min-w-0 overflow-hidden">
              {isEditing ? (
                <div className="flex items-center gap-2">
                  <Input
                    value={editedTitle}
                    onChange={(e) => setEditedTitle(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSaveTitle();
                      if (e.key === 'Escape') setIsEditing(false);
                    }}
                    className="text-base md:text-xl font-bold h-7 md:h-8 w-full"
                    autoFocus
                  />
                  <Button size="sm" onClick={handleSaveTitle} className="h-7 md:h-8 flex-shrink-0">
                    <Save className="w-3 h-3" />
                  </Button>
                </div>
              ) : (
                <motion.h1
                  className="text-base md:text-xl font-bold text-[#323338] cursor-pointer hover:text-[#0073EA] transition-colors flex items-center gap-2 group truncate"
                  onClick={() => setIsEditing(true)}
                  whileHover={{ scale: 1.02 }}
                >
                  <span className="truncate">{board?.title}</span>
                  <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
                </motion.h1>
              )}

              {/* Metadata Row - Hidden on small screens */}
              <div className="hidden lg:flex items-center gap-3 text-xs mt-1 flex-wrap">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-6 px-2 text-xs text-[#676879] hover:bg-[#E1E5F3] rounded-md flex-shrink-0">
                      <Table2 className="w-3 h-3 mr-1" />
                      <span className="hidden xl:inline">{viewLabels[currentView] || 'Tabla Principal'}</span>
                      <ChevronDown className="w-3 h-3 ml-1" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem onClick={() => onViewChange('table')}>
                      <Table2 className="w-4 h-4 mr-2" />
                      Tabla Principal
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onViewChange('kanban')}>
                      <Table2 className="w-4 h-4 mr-2" />
                      Tablero Kanban
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onViewChange('calendar')}>
                      <Table2 className="w-4 h-4 mr-2" />
                      Vista de Calendario
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onViewChange('timeline')}>
                      <Table2 className="w-4 h-4 mr-2" />
                      Línea de Tiempo
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onViewChange('unassigned')}>
                      <UserMinus className="w-4 h-4 mr-2" />
                      Tareas Sin Asignar
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <span className="text-[#A0A0A0] hidden xl:inline">|</span>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className={`h-6 px-2 text-xs transition-all duration-200 flex-shrink-0 ${isFavorited ? 'text-yellow-500 hover:text-yellow-600' : 'text-[#676879] hover:text-yellow-500'}`}
                      onClick={handleToggleFavorite}
                    >
                      <motion.div
                        whileHover={{ scale: 1.2, rotate: 10 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <Star className={`w-3 h-3 mr-1 ${isFavorited ? 'fill-current' : ''}`} />
                      </motion.div>
                      <span className="hidden xl:inline">{isFavorited ? 'Favorito' : 'Añadir a favoritos'}</span>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    {isFavorited ? 'Quitar de favoritos' : 'Añadir a favoritos'}
                  </TooltipContent>
                </Tooltip>

                <span className="text-[#A0A0A0] hidden xl:inline">|</span>

                <div className="hidden xl:flex items-center gap-2 flex-shrink-0">
                  <span className="text-[#A0A0A0] whitespace-nowrap">{itemsCount} elementos</span>
                  <span className="text-[#A0A0A0]">▪</span>
                  <span className="text-[#A0A0A0] whitespace-nowrap">
                    Guardado {lastSaved.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            </div>

            {/* Right Section - Action buttons (fixed width) */}
            <div className="hidden md:flex items-center gap-2 flex-shrink-0">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 px-2 lg:px-3 text-xs border-[#E1E5F3] hover:border-green-500 hover:text-green-600 flex-shrink-0 whitespace-nowrap"
                    onClick={onShowAnalytics}
                  >
                    <TrendingUp className="w-3 h-3 lg:mr-1" />
                    <span className="hidden lg:inline">Analítica</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Ver analítica del tablero</TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 px-2 lg:px-3 text-xs border-[#E1E5F3] hover:border-blue-500 flex-shrink-0 whitespace-nowrap"
                    onClick={onShowIntegrations}
                  >
                    <Activity className="w-3 h-3 lg:mr-1" />
                    <span className="hidden lg:inline">Integrar</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Conectar herramientas externas</TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 px-2 lg:px-3 text-xs border-[#E1E5F3] hover:border-purple-500 relative flex-shrink-0 whitespace-nowrap"
                    onClick={onShowAutomations}
                  >
                    <Zap className="w-3 h-3 lg:mr-1" />
                    <span className="hidden lg:inline">Automatizar</span>
                    <motion.div
                      className="absolute -top-1 -right-1 w-2 h-2 bg-purple-500 rounded-full"
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 1, repeat: Infinity }}
                    />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Gestionar automatizaciones</TooltipContent>
              </Tooltip>

              <Popover>
                <PopoverTrigger asChild>
                  <div className="flex items-center -space-x-2 cursor-pointer ml-2 flex-shrink-0">
                    {collaborators.slice(0, 3).map((user, index) => (
                      <Tooltip key={user.id}>
                        <TooltipTrigger asChild>
                          <motion.div
                            className={`w-8 h-8 rounded-full border-2 border-white flex items-center justify-center text-white text-xs font-medium relative ${
                              index === 0 ? 'bg-blue-500' : index === 1 ? 'bg-green-500' : 'bg-purple-500'
                            }`}
                            whileHover={{ scale: 1.1, zIndex: 10 }}
                            whileTap={{ scale: 0.95 }}
                          >
                            {user.avatar}
                            {user.online && (
                              <motion.div
                                className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-400 rounded-full border border-white"
                                animate={{ scale: [1, 1.2, 1] }}
                                transition={{ duration: 2, repeat: Infinity }}
                              />
                            )}
                          </motion.div>
                        </TooltipTrigger>
                        <TooltipContent>{user.name} ({user.role})</TooltipContent>
                      </Tooltip>
                    ))}
                    {collaborators.length > 3 && (
                      <div className="w-8 h-8 rounded-full bg-gray-400 border-2 border-white flex items-center justify-center text-white text-xs">
                        +{collaborators.length - 3}
                      </div>
                    )}
                  </div>
                </PopoverTrigger>
                <PopoverContent className="w-80">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">Equipo ({collaborators.length})</h4>
                      <Button size="sm" variant="outline">
                        <UserPlus className="w-3 h-3 mr-1" />
                        Invitar
                      </Button>
                    </div>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {collaborators.map((user) => (
                        <div key={user.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-50">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs relative ${
                              user.id % 3 === 0 ? 'bg-blue-500' : user.id % 3 === 1 ? 'bg-green-500' : 'bg-purple-500'
                            }`}>
                              {user.avatar}
                              {user.online && (
                                <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-green-400 rounded-full border border-white" />
                              )}
                            </div>
                            <div>
                              <p className="text-sm font-medium">{user.name}</p>
                              <p className="text-xs text-gray-500">{user.role}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="icon" className="h-6 w-6">
                              <Mail className="w-3 h-3" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6">
                              <MessageSquare className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
            </div>

            {/* Mobile Menu Button */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden h-8 w-8 flex-shrink-0">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                <div className="space-y-4 py-4">
                  <h3 className="font-semibold text-lg mb-4">Menú del Tablero</h3>

                  <div className="space-y-2">
                    <Button
                      variant="ghost"
                      className="w-full justify-start"
                      onClick={() => {
                        onShowAnalytics();
                        setMobileMenuOpen(false);
                      }}
                    >
                      <TrendingUp className="w-4 h-4 mr-2" />
                      Analítica
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full justify-start"
                      onClick={() => {
                        onShowIntegrations();
                        setMobileMenuOpen(false);
                      }}
                    >
                      <Activity className="w-4 h-4 mr-2" />
                      Integrar
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full justify-start"
                      onClick={() => {
                        onShowAutomations();
                        setMobileMenuOpen(false);
                      }}
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      Automatizar
                    </Button>
                  </div>

                  <div className="border-t pt-4">
                    <h4 className="font-medium mb-2 text-sm">Vista</h4>
                    <div className="space-y-1">
                      {Object.entries(viewLabels).map(([view, label]) => (
                        <Button
                          key={view}
                          variant={currentView === view ? "secondary" : "ghost"}
                          className="w-full justify-start text-sm"
                          onClick={() => {
                            onViewChange(view);
                            setMobileMenuOpen(false);
                          }}
                        >
                          {label}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <h4 className="font-medium mb-2 text-sm">Equipo ({collaborators.length})</h4>
                    <div className="space-y-2">
                      {collaborators.map((user) => (
                        <div key={user.id} className="flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs ${
                            user.id % 3 === 0 ? 'bg-blue-500' : user.id % 3 === 1 ? 'bg-green-500' : 'bg-purple-500'
                          }`}>
                            {user.avatar}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{user.name}</p>
                            <p className="text-xs text-gray-500">{user.role}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Mobile Info Row */}
          <div className="flex md:hidden items-center gap-2 mt-2 text-xs text-[#A0A0A0] flex-wrap">
            <span className="whitespace-nowrap">{itemsCount} elementos</span>
            <span>▪</span>
            <span className="whitespace-nowrap">{viewLabels[currentView]}</span>
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
}

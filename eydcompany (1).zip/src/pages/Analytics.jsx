import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, TrendingDown, CheckCircle, AlertCircle, Clock, Folder, Target } from "lucide-react";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";

export default function AnalyticsPage() {
  const [boards, setBoards] = useState([]);
  const [items, setItems] = useState([]);
  const [user, setUser] = useState(null);
  const [selectedBoard, setSelectedBoard] = useState("all");
  const [timeRange, setTimeRange] = useState("all");
  const [isLoading, setIsLoading] = useState(true);

  // Función para traducir estados al español
  const translateStatus = (status) => {
    const translations = {
      'Done': 'Hecho',
      'Working on it': 'En desarollo',
      'Stuck': 'Atascado',
      'In Progress': 'En Progreso',
      'Not Started': 'Sin Empezar',
      'Completed': 'Completado',
      'Pending': 'Pendiente',
      'On Hold': 'En Espera',
      'Cancelled': 'Cancelado',
      'done': 'Hecho',
      'Hecho': 'Hecho',
      'Completado': 'Completado'
    };
    
    return translations[status] || status || 'Sin estado';
  };

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      // Cargar usuario primero
      const userData = await base44.auth.me();
      setUser(userData);

      // Cargar todos los boards e items
      const [allBoardsData, allItemsData] = await Promise.all([
        base44.entities.Board.list("-updated_date"),
        base44.entities.Item.list("-updated_date")
      ]);

      // Filtrar boards según permisos
      const isAdmin = userData.role === "admin" || userData.custom_role === "admin";

      const visibleBoards = allBoardsData.filter(board => {
        // Admins ven todo
        if (isAdmin) return true;

        // Creador siempre ve su board
        if (board.created_by === userData.email) return true;

        // Boards compartidos son visibles para todos
        if (board.visibility === "shared") return true;

        // Boards privados: verificar permisos
        if (board.visibility === "private") {
          // Verificar participantes
          if (board.participants && board.participants.includes(userData.email)) {
            return true;
          }

          // Verificar departamentos
          if (board.allowed_departments && userData.department && 
              board.allowed_departments.includes(userData.department)) {
            return true;
          }
        }

        return false;
      });

      const myBoards = visibleBoards;
      console.log('📊 Analytics - Proyectos Visibles:', myBoards.length, 'de', allBoardsData.length, 'totales');
      
      // Obtener IDs de mis boards
      const myBoardIds = myBoards.map(board => board.id);
      
      // Filtrar solo los items de mis boards
      const myItems = allItemsData.filter(item => myBoardIds.includes(item.board_id));
      console.log('📊 Analytics - Mis Tareas:', myItems.length, 'de', allItemsData.length, 'totales');

      setBoards(myBoards);
      setItems(myItems);
    } catch (error) {
      console.error("Error al cargar datos:", error);
    }
    setIsLoading(false);
  };

  // Filtrar items según el board seleccionado y el rango de tiempo
  const filteredItems = items.filter(item => {
    if (selectedBoard !== "all" && item.board_id !== selectedBoard) {
      return false;
    }

    if (timeRange !== "all") {
      const itemDate = new Date(item.created_date);
      const now = new Date();
      const diffDays = Math.floor((now - itemDate) / (1000 * 60 * 60 * 24));

      if (timeRange === "week" && diffDays > 7) return false;
      if (timeRange === "month" && diffDays > 30) return false;
      if (timeRange === "quarter" && diffDays > 90) return false;
    }

    return true;
  });

  // Calcular métricas
  const totalTasks = filteredItems.length;
  const completedTasks = filteredItems.filter(item => 
    item.data?.status === 'Hecho' || 
    item.data?.status === 'done' || 
    item.data?.status === 'Done' ||
    item.data?.status === 'Completado' ||
    item.is_completed
  ).length;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  
  const overdueTasks = filteredItems.filter(item => {
    const dueDate = item.data?.due_date || item.data?.fecha;
    if (!dueDate) return false;
    return new Date(dueDate) < new Date() && !item.is_completed;
  }).length;

  // Distribución por estado (con traducción)
  const statusDistribution = filteredItems.reduce((acc, item) => {
    const originalStatus = item.data?.status || 'Sin estado';
    const translatedStatus = translateStatus(originalStatus);
    acc[translatedStatus] = (acc[translatedStatus] || 0) + 1;
    return acc;
  }, {});

  const statusData = Object.entries(statusDistribution).map(([name, value]) => ({
    name,
    value
  }));

  // Distribución por prioridad
  const priorityDistribution = filteredItems.reduce((acc, item) => {
    const priority = item.priority || 'medium';
    acc[priority] = (acc[priority] || 0) + 1;
    return acc;
  }, {});

  const priorityData = Object.entries(priorityDistribution).map(([name, value]) => ({
    name: name === 'low' ? 'Baja' : name === 'medium' ? 'Media' : name === 'high' ? 'Alta' : 'Crítica',
    value
  }));

  // Estadísticas por board (solo mis boards)
  const boardStats = boards.map(board => {
    const boardItems = items.filter(item => item.board_id === board.id);
    const completed = boardItems.filter(item => 
      item.data?.status === 'Hecho' || 
      item.data?.status === 'done' || 
      item.data?.status === 'Done' ||
      item.data?.status === 'Completado' ||
      item.is_completed
    ).length;
    return {
      name: board.title,
      total: boardItems.length,
      completadas: completed,
      pendientes: boardItems.length - completed,
      progreso: boardItems.length > 0 ? Math.round((completed / boardItems.length) * 100) : 0
    };
  }).sort((a, b) => b.total - a.total);

  const COLORS = ['#0073EA', '#00C875', '#FDAB3D', '#E2445C', '#9CD326', '#784BD1'];

  if (isLoading) {
    return (
      <div className="p-6 bg-[#F5F6F8] min-h-screen">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <Skeleton className="h-8 w-48" />
            <div className="flex gap-3">
              <Skeleton className="h-10 w-40" />
              <Skeleton className="h-10 w-40" />
            </div>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array(4).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#F5F6F8] min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold text-[#323338]">Analítica de Mis Proyectos</h1>
            <p className="text-[#676879] mt-1">Métricas y estadísticas de tus proyectos personales</p>
          </div>
          <div className="flex gap-3">
            <Select value={selectedBoard} onValueChange={setSelectedBoard}>
              <SelectTrigger className="w-[200px] bg-white">
                <SelectValue placeholder="Seleccionar proyecto" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos mis proyectos</SelectItem>
                {boards.map(board => (
                  <SelectItem key={board.id} value={board.id}>
                    {board.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[180px] bg-white">
                <SelectValue placeholder="Rango de tiempo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todo el tiempo</SelectItem>
                <SelectItem value="week">Última semana</SelectItem>
                <SelectItem value="month">Último mes</SelectItem>
                <SelectItem value="quarter">Último trimestre</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0 }}
          >
            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 border-0 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100 text-sm font-medium mb-2">Total de Tareas</p>
                    <p className="text-4xl font-bold">{totalTasks}</p>
                  </div>
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <Target className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="bg-gradient-to-br from-green-500 to-green-600 border-0 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100 text-sm font-medium mb-2">Tasa de Completitud</p>
                    <p className="text-4xl font-bold">{completionRate}%</p>
                  </div>
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gradient-to-br from-amber-500 to-orange-500 border-0 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-amber-100 text-sm font-medium mb-2">Tareas Vencidas</p>
                    <p className="text-4xl font-bold">{overdueTasks}</p>
                  </div>
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gradient-to-br from-purple-500 to-purple-600 border-0 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100 text-sm font-medium mb-2">Mis Proyectos</p>
                    <p className="text-4xl font-bold">{selectedBoard === 'all' ? boards.length : 1}</p>
                  </div>
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <Folder className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Empty State */}
        {boards.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-16"
          >
            <div className="w-24 h-24 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
              <Folder className="w-12 h-12 text-blue-500" />
            </div>
            <h3 className="text-xl font-semibold text-[#323338] mb-2">
              Aún no tienes proyectos
            </h3>
            <p className="text-[#676879] mb-6">
              Crea tu primer proyecto para comenzar a ver analíticas
            </p>
          </motion.div>
        )}

        {/* Charts */}
        {boards.length > 0 && (
          <>
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Status Distribution */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Distribución por Estado</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={statusData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {statusData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Priority Distribution */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Distribución por Prioridad</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={priorityData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="value" fill="#0073EA" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* Board Performance */}
            {selectedBoard === 'all' && boardStats.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Rendimiento por Proyecto</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart data={boardStats}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="completadas" fill="#00C875" name="Completadas" />
                        <Bar dataKey="pendientes" fill="#FDAB3D" name="Pendientes" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Bell, Shield, Settings as SettingsIcon, Save, CheckCircle2, Key, Mail } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import PushNotificationSettings from "@/components/settings/PushNotificationSettings";

export default function Settings() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  const [notificationPreferences, setNotificationPreferences] = useState({
    task_updates: true,
    task_assigned: true,
    mentions: true,
    deadlines: true,
    comments: true,
    status_changes: true,
    deadline_days_before: 1,
    email_notifications: false,
    push_notifications: true,
  });

  const [generalPreferences, setGeneralPreferences] = useState({
    theme: "light",
    language: "es",
  });

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    setIsLoading(true);
    try {
      const userData = await base44.auth.me();
      setUser(userData);

      if (userData.notification_preferences) {
        setNotificationPreferences({
          ...notificationPreferences,
          ...userData.notification_preferences,
        });
      }
    } catch (error) {
      console.error("Error al cargar datos del usuario:", error);
      toast({
        title: "Error",
        description: "No se pudieron cargar tus datos",
        variant: "destructive",
      });
    }
    setIsLoading(false);
  };

  const handleSaveNotifications = async () => {
    setIsSaving(true);
    try {
      await base44.auth.updateMe({
        notification_preferences: notificationPreferences,
      });

      toast({
        title: "✓ Preferencias actualizadas",
        description: "Tus preferencias de notificación han sido guardadas",
      });
    } catch (error) {
      console.error("Error al guardar notificaciones:", error);
      toast({
        title: "Error",
        description: "No se pudieron guardar tus preferencias",
        variant: "destructive",
      });
    }
    setIsSaving(false);
  };

  const handleSavePreferences = async () => {
    setIsSaving(true);
    try {
      toast({
        title: "✓ Preferencias guardadas",
        description: "Tus preferencias generales han sido actualizadas",
      });
    } catch (error) {
      console.error("Error:", error);
    }
    setIsSaving(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F6F8]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0073EA] mx-auto mb-4"></div>
          <p className="text-[#676879]">Cargando configuración...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F6F8] p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-[#323338] mb-2">Ajustes de Cuenta</h1>
          <p className="text-[#676879]">Administra las configuraciones y seguridad de tu cuenta</p>
        </div>

        {/* Seguridad */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Seguridad de la Cuenta
            </CardTitle>
            <CardDescription>
              Administra la seguridad y privacidad de tu cuenta
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium text-green-900">Cuenta Protegida</p>
                  <p className="text-sm text-green-700">
                    Tu cuenta está protegida con autenticación segura
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                <Mail className="w-5 h-5 text-[#0073EA] mt-0.5" />
                <div className="flex-1">
                  <Label className="text-sm font-medium">Correo Electrónico</Label>
                  <p className="text-sm text-[#676879] mt-1">{user?.email}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Tu email principal para acceder a la cuenta
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                <Key className="w-5 h-5 text-[#0073EA] mt-0.5" />
                <div className="flex-1">
                  <Label className="text-sm font-medium">Contraseña</Label>
                  <p className="text-sm text-[#676879] mt-1">
                    ••••••••
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    La gestión de contraseña está protegida por el sistema de autenticación
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                <Shield className="w-5 h-5 text-[#0073EA] mt-0.5" />
                <div className="flex-1">
                  <Label className="text-sm font-medium">Nivel de Acceso</Label>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant={user?.role === "admin" ? "default" : "secondary"}>
                      {user?.role === "admin" ? "Administrador" : "Usuario"}
                    </Badge>
                    <span className="text-xs text-gray-500">
                      {user?.role === "admin" 
                        ? "Acceso completo al sistema" 
                        : "Acceso estándar a funcionalidades"}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-900">
                ℹ️ Para cambiar tu email o contraseña, contacta con el administrador del sistema o utiliza las opciones de recuperación de cuenta.
              </p>
            </div>
          </CardContent>
        </Card>

        <PushNotificationSettings />

        {/* Notificaciones */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Preferencias de Notificación
            </CardTitle>
            <CardDescription>
              Controla qué notificaciones deseas recibir y cómo
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-[#323338]">Tipos de Notificación</h3>
              
              <div className="flex items-center justify-between py-3 border-b">
                <div>
                  <Label htmlFor="task_updates" className="font-medium cursor-pointer">
                    Actualizaciones de Tareas
                  </Label>
                  <p className="text-sm text-[#676879]">
                    Recibir notificaciones cuando una tarea es actualizada
                  </p>
                </div>
                <Switch
                  id="task_updates"
                  checked={notificationPreferences.task_updates}
                  onCheckedChange={(checked) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      task_updates: checked,
                    })
                  }
                />
              </div>

              <div className="flex items-center justify-between py-3 border-b">
                <div>
                  <Label htmlFor="task_assigned" className="font-medium cursor-pointer">
                    Asignación de Tareas
                  </Label>
                  <p className="text-sm text-[#676879]">
                    Notificar cuando te asignen una nueva tarea
                  </p>
                </div>
                <Switch
                  id="task_assigned"
                  checked={notificationPreferences.task_assigned}
                  onCheckedChange={(checked) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      task_assigned: checked,
                    })
                  }
                />
              </div>

              <div className="flex items-center justify-between py-3 border-b">
                <div>
                  <Label htmlFor="mentions" className="font-medium cursor-pointer">
                    Menciones
                  </Label>
                  <p className="text-sm text-[#676879]">
                    Notificar cuando alguien te mencione en comentarios
                  </p>
                </div>
                <Switch
                  id="mentions"
                  checked={notificationPreferences.mentions}
                  onCheckedChange={(checked) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      mentions: checked,
                    })
                  }
                />
              </div>

              <div className="flex items-center justify-between py-3 border-b">
                <div>
                  <Label htmlFor="deadlines" className="font-medium cursor-pointer">
                    Fechas Límite
                  </Label>
                  <p className="text-sm text-[#676879]">
                    Alertas sobre tareas que se acercan a su fecha límite
                  </p>
                </div>
                <Switch
                  id="deadlines"
                  checked={notificationPreferences.deadlines}
                  onCheckedChange={(checked) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      deadlines: checked,
                    })
                  }
                />
              </div>

              <div className="flex items-center justify-between py-3 border-b">
                <div>
                  <Label htmlFor="comments" className="font-medium cursor-pointer">
                    Comentarios
                  </Label>
                  <p className="text-sm text-[#676879]">
                    Notificar sobre nuevos comentarios en tus tareas
                  </p>
                </div>
                <Switch
                  id="comments"
                  checked={notificationPreferences.comments}
                  onCheckedChange={(checked) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      comments: checked,
                    })
                  }
                />
              </div>

              <div className="flex items-center justify-between py-3 border-b">
                <div>
                  <Label htmlFor="status_changes" className="font-medium cursor-pointer">
                    Cambios de Estado
                  </Label>
                  <p className="text-sm text-[#676879]">
                    Notificar cuando cambie el estado de una tarea
                  </p>
                </div>
                <Switch
                  id="status_changes"
                  checked={notificationPreferences.status_changes}
                  onCheckedChange={(checked) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      status_changes: checked,
                    })
                  }
                />
              </div>
            </div>

            {notificationPreferences.deadlines && (
              <div className="space-y-3 pt-4">
                <Label>Anticipación de Fecha Límite</Label>
                <p className="text-sm text-[#676879]">
                  Notificar {notificationPreferences.deadline_days_before} día(s) antes de la fecha límite
                </p>
                <Slider
                  value={[notificationPreferences.deadline_days_before]}
                  onValueChange={(value) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      deadline_days_before: value[0],
                    })
                  }
                  min={1}
                  max={7}
                  step={1}
                  className="max-w-md"
                />
                <div className="flex justify-between text-xs text-[#676879] max-w-md">
                  <span>1 día</span>
                  <span>7 días</span>
                </div>
              </div>
            )}

            <div className="space-y-4 pt-4 border-t">
              <h3 className="text-sm font-semibold text-[#323338]">Canales de Notificación</h3>
              
              <div className="flex items-center justify-between py-3">
                <div>
                  <Label htmlFor="push_notifications" className="font-medium cursor-pointer">
                    Notificaciones Push
                  </Label>
                  <p className="text-sm text-[#676879]">
                    Recibir notificaciones en tiempo real dentro de la aplicación
                  </p>
                </div>
                <Switch
                  id="push_notifications"
                  checked={notificationPreferences.push_notifications}
                  onCheckedChange={(checked) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      push_notifications: checked,
                    })
                  }
                />
              </div>

              <div className="flex items-center justify-between py-3">
                <div>
                  <Label htmlFor="email_notifications" className="font-medium cursor-pointer">
                    Notificaciones por Email
                  </Label>
                  <p className="text-sm text-[#676879]">
                    Recibir resumen de notificaciones por correo electrónico
                  </p>
                </div>
                <Switch
                  id="email_notifications"
                  checked={notificationPreferences.email_notifications}
                  onCheckedChange={(checked) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      email_notifications: checked,
                    })
                  }
                />
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <Button onClick={handleSaveNotifications} disabled={isSaving} className="bg-[#0073EA] hover:bg-[#0056B3]">
                {isSaving ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Guardando...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Guardar Preferencias
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Preferencias Generales */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <SettingsIcon className="w-5 h-5" />
              Preferencias Generales
            </CardTitle>
            <CardDescription>
              Personaliza tu experiencia en la aplicación
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="theme">Tema de la Aplicación</Label>
              <p className="text-sm text-[#676879]">
                Actualmente: Tema Claro
              </p>
              <Badge variant="outline">Próximamente</Badge>
            </div>

            <div className="space-y-2">
              <Label htmlFor="language">Idioma</Label>
              <p className="text-sm text-[#676879]">
                Idioma actual: Español
              </p>
              <Badge>Español (ES)</Badge>
            </div>

            <div className="pt-4 flex justify-end">
              <Button onClick={handleSavePreferences} disabled={isSaving} className="bg-[#0073EA] hover:bg-[#0056B3]">
                {isSaving ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Guardando...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Guardar Preferencias
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
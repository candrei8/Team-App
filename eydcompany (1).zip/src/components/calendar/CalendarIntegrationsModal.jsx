import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { CheckCircle2, XCircle, RefreshCw, ExternalLink, Calendar, Loader2 } from "lucide-react";
import { format } from "date-fns";

export default function CalendarIntegrationsModal({ isOpen, onClose, currentUser }) {
  const { toast } = useToast();
  const [integrations, setIntegrations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);

  useEffect(() => {
    if (isOpen && currentUser) {
      loadIntegrations();
    }
  }, [isOpen, currentUser]);

  const loadIntegrations = async () => {
    setLoading(true);
    try {
      const data = await base44.entities.CalendarIntegration.filter({ user_email: currentUser.email });
      setIntegrations(data);
    } catch (error) {
      console.error("Error loading integrations:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async (provider) => {
    setActionLoading(provider);
    try {
      const redirectUri = window.location.origin + window.location.pathname;
      const { data } = await base44.functions.invoke('calendarAuth', { 
        action: 'get_url', 
        provider,
        redirect_uri: redirectUri
      });
      
      if (data.url) {
        window.location.href = data.url;
      } else {
        throw new Error("No se pudo obtener la URL de autorización");
      }
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "No se pudo iniciar la conexión. Verifica tus credenciales.",
        variant: "destructive"
      });
      setActionLoading(null);
    }
  };

  const handleDisconnect = async (integration) => {
    if (!confirm("¿Estás seguro? Se dejarán de sincronizar los eventos.")) return;
    
    setActionLoading(integration.provider);
    try {
      await base44.entities.CalendarIntegration.update(integration.id, {
        is_connected: false,
        sync_enabled: false,
        access_token: "",
        refresh_token: ""
      });
      await loadIntegrations();
      toast({ title: "Desconectado correctamente" });
    } catch (error) {
      console.error(error);
    } finally {
      setActionLoading(null);
    }
  };

  const toggleSync = async (integration) => {
    try {
      await base44.entities.CalendarIntegration.update(integration.id, {
        sync_enabled: !integration.sync_enabled
      });
      setIntegrations(prev => prev.map(i => 
        i.id === integration.id ? { ...i, sync_enabled: !i.sync_enabled } : i
      ));
    } catch (error) {
      toast({ title: "Error al actualizar", variant: "destructive" });
    }
  };

  const getProviderInfo = (provider) => {
    if (provider === 'google') {
      return {
        name: 'Google Calendar',
        icon: (props) => (
          <svg {...props} viewBox="0 0 24 24" width="24" height="24" xmlns="http://www.w3.org/2000/svg">
            <g transform="matrix(1, 0, 0, 1, 27.009001, -39.238998)">
              <path fill="#4285F4" d="M -3.264 51.509 C -3.264 50.719 -3.334 49.969 -3.454 49.239 L -14.754 49.239 L -14.754 53.749 L -8.284 53.749 C -8.574 55.229 -9.424 56.479 -10.684 57.329 L -10.684 60.329 L -6.824 60.329 C -4.564 58.239 -3.264 55.159 -3.264 51.509 Z" />
              <path fill="#34A853" d="M -14.754 63.239 C -11.514 63.239 -8.804 62.159 -6.824 60.329 L -10.684 57.329 C -11.764 58.049 -13.134 58.489 -14.754 58.489 C -17.884 58.489 -20.534 56.379 -21.484 53.529 L -25.464 53.529 L -25.464 56.619 C -23.494 60.539 -19.444 63.239 -14.754 63.239 Z" />
              <path fill="#FBBC05" d="M -21.484 53.529 C -21.734 52.809 -21.864 52.039 -21.864 51.239 C -21.864 50.439 -21.724 49.669 -21.484 48.949 L -21.484 45.859 L -25.464 45.859 C -26.284 47.479 -26.754 49.299 -26.754 51.239 C -26.754 53.179 -26.284 54.999 -25.464 56.619 L -21.484 53.529 Z" />
              <path fill="#EA4335" d="M -14.754 43.989 C -12.984 43.989 -11.404 44.599 -10.154 45.789 L -6.734 42.369 C -8.804 40.429 -11.514 39.239 -14.754 39.239 C -19.444 39.239 -23.494 41.939 -25.464 45.859 L -21.484 48.949 C -20.534 46.099 -17.884 43.989 -14.754 43.989 Z" />
            </g>
          </svg>
        ),
        description: "Sincroniza eventos bidireccionalmente con tu calendario de Google."
      };
    } else {
      return {
        name: 'Microsoft 365',
        icon: (props) => (
          <svg {...props} viewBox="0 0 24 24" width="24" height="24" xmlns="http://www.w3.org/2000/svg">
             <rect x="1" y="1" width="10" height="10" fill="#f25022"/>
             <rect x="13" y="1" width="10" height="10" fill="#7fba00"/>
             <rect x="1" y="13" width="10" height="10" fill="#00a4ef"/>
             <rect x="13" y="13" width="10" height="10" fill="#ffb900"/>
          </svg>
        ),
        description: "Conecta Outlook y Teams para sincronizar tus reuniones automáticamente."
      };
    }
  };

  const IntegrationCard = ({ provider }) => {
    const info = getProviderInfo(provider);
    const integration = integrations.find(i => i.provider === provider && i.is_connected);
    const isConnecting = actionLoading === provider;

    return (
      <div className="flex items-start space-x-4 p-4 border rounded-xl bg-white hover:border-blue-200 transition-colors">
        <div className="p-2 bg-gray-50 rounded-lg">
          <info.icon className="w-8 h-8" />
        </div>
        <div className="flex-1 space-y-1">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold text-gray-900">{info.name}</h4>
            {integration ? (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 gap-1">
                <CheckCircle2 className="w-3 h-3" /> Conectado
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-gray-50 text-gray-500 border-gray-200 gap-1">
                <XCircle className="w-3 h-3" /> Desconectado
              </Badge>
            )}
          </div>
          <p className="text-sm text-gray-500">{info.description}</p>
          
          {integration && (
            <div className="flex items-center gap-2 text-xs text-gray-400 mt-2 bg-gray-50 p-2 rounded">
              <span className="truncate max-w-[180px]">{integration.account_email}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <RefreshCw className="w-3 h-3" /> 
                {integration.last_synced ? format(new Date(integration.last_synced), "HH:mm") : "Nunca"}
              </span>
            </div>
          )}

          <div className="pt-3 flex items-center justify-between">
            {integration ? (
              <div className="flex items-center gap-4">
                <Button 
                   variant="outline" 
                   size="sm" 
                   className="h-8"
                   onClick={async () => {
                     setActionLoading(provider);
                     try {
                       await base44.functions.invoke('calendarSync', {});
                       toast({ title: "Sincronización iniciada" });
                       await loadIntegrations();
                     } catch(e) { 
                       toast({ title: "Error al sincronizar", variant: "destructive" }); 
                     } finally {
                       setActionLoading(null);
                     }
                   }}
                   disabled={isConnecting}
                >
                  <RefreshCw className={`w-3 h-3 mr-2 ${isConnecting ? 'animate-spin' : ''}`} />
                  Sincronizar ahora
                </Button>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id={`sync-${provider}`} 
                    checked={integration.sync_enabled}
                    onCheckedChange={() => toggleSync(integration)}
                  />
                  <label htmlFor={`sync-${provider}`} className="text-sm font-medium text-gray-700">
                    Auto
                  </label>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-red-600 hover:text-red-700 h-8"
                  onClick={() => handleDisconnect(integration)}
                  disabled={isConnecting}
                >
                  Desconectar
                </Button>
              </div>
            ) : (
              <Button 
                size="sm" 
                onClick={() => handleConnect(provider)}
                disabled={isConnecting}
                className="bg-slate-900 hover:bg-slate-800 text-white"
              >
                {isConnecting ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <ExternalLink className="w-4 h-4 mr-2" />
                )}
                {isConnecting ? "Conectando..." : "Conectar Cuenta"}
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-600" />
            Integraciones de Calendario
          </DialogTitle>
          <DialogDescription>
            Conecta tus calendarios externos para sincronizar eventos y evitar conflictos de horarios.
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <IntegrationCard provider="google" />
          <IntegrationCard provider="microsoft" />
        </div>

        <div className="bg-blue-50 p-4 rounded-lg flex gap-3 text-sm text-blue-800">
          <div className="mt-0.5">ℹ️</div>
          <div>
            <p className="font-semibold mb-1">Sobre la sincronización</p>
            <p className="opacity-90">
              Los eventos creados aquí se añadirán a tus calendarios conectados. 
              Los eventos de tus calendarios externos aparecerán aquí como "Ocupado" para tus compañeros de equipo.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
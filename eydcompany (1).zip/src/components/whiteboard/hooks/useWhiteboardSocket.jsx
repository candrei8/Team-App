import { useEffect } from 'react';
import { useWhiteboard } from '@/components/whiteboard/store/WhiteboardContext';

export function useWhiteboardSocket(whiteboardId, user) {
  const { state, dispatch, wsRef } = useWhiteboard();

  useEffect(() => {
    if (!whiteboardId || !user) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/functions/whiteboardWs`;
    
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      console.log("WS Connected");
      ws.send(JSON.stringify({
        type: 'join',
        userId: user.email,
        whiteboardId: whiteboardId
      }));
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'element_update':
          dispatch({ type: 'UPDATE_ELEMENT', payload: { id: data.id, changes: data.changes } });
          break;
        case 'element_create':
          dispatch({ type: 'ADD_ELEMENT', payload: data.element });
          break;
        case 'cursor_move':
          dispatch({ 
            type: 'UPDATE_COLLABORATOR', 
            payload: { 
              userId: data.userId, 
              data: { cursor: data.cursor, color: data.color, name: data.name } 
            } 
          });
          break;
        case 'user_left':
          dispatch({ type: 'REMOVE_COLLABORATOR', payload: data.userId });
          break;
      }
    };

    wsRef.current = ws;

    return () => {
      if (wsRef.current) wsRef.current.close();
    };
  }, [whiteboardId, user, dispatch]);

  const broadcast = (msg) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(msg));
    }
  };

  return { broadcast };
}
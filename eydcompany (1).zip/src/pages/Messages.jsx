import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import ChatLayout from "../components/chat/ChatLayout";
import Sidebar from "../components/chat/Sidebar";
import ChatArea from "../components/chat/ChatArea";
import ThreadView from "../components/chat/ThreadView";
import { Loader2 } from "lucide-react";

export default function MessagesPage() {
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedChannel, setSelectedChannel] = useState(null);
  const [selectedThread, setSelectedThread] = useState(null);
  const queryClient = useQueryClient();

  // Initial Load
  useEffect(() => {
    const init = async () => {
      const user = await base44.auth.me();
      setCurrentUser(user);
    };
    init();
  }, []);

  // Realtime Polling for Channels
  const { data: channels = [] } = useQuery({
    queryKey: ['channels'],
    queryFn: () => base44.entities.Channel.list("-last_message_at"),
    refetchInterval: 5000
  });

  // Realtime Polling for Users (for DM status)
  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    refetchInterval: 30000
  });

  // Realtime Polling for Messages
  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['messages', selectedChannel?.id],
    queryFn: () => selectedChannel 
        ? base44.entities.Message.filter({ channel_id: selectedChannel.id, reply_to: null }, "created_date", 100)
        : [],
    enabled: !!selectedChannel,
    refetchInterval: 2000, // "Realtime" feel
    keepPreviousData: true
  });

  // Auto-select first channel
  useEffect(() => {
    if (!selectedChannel && channels.length > 0) {
        const general = channels.find(c => c.name === 'general') || channels[0];
        setSelectedChannel(general);
    }
  }, [channels, selectedChannel]);

  const sendMessageMutation = useMutation({
    mutationFn: async (content) => {
      return await base44.entities.Message.create({
        channel_id: selectedChannel.id,
        user_email: currentUser.email,
        user_name: currentUser.full_name,
        user_avatar: currentUser.avatar_url,
        content: content,
        created_date: new Date().toISOString(),
        reactions: {}
      });
    },
    onMutate: async (newContent) => {
      // Cancel any outgoing refetches (so they don't overwrite our optimistic update)
      await queryClient.cancelQueries({ queryKey: ['messages', selectedChannel?.id] });

      // Snapshot the previous value
      const previousMessages = queryClient.getQueryData(['messages', selectedChannel?.id]);

      // Optimistically update to the new value
      if (previousMessages) {
        const optimisticMessage = {
          id: 'temp-' + Date.now(),
          channel_id: selectedChannel.id,
          user_email: currentUser.email,
          user_name: currentUser.full_name,
          user_avatar: currentUser.avatar_url,
          content: newContent,
          created_date: new Date().toISOString(),
          reactions: {},
          isPending: true
        };
        
        queryClient.setQueryData(['messages', selectedChannel?.id], (old) => [...(old || []), optimisticMessage]);
      }

      // Return a context object with the snapshotted value
      return { previousMessages };
    },
    onError: (err, newContent, context) => {
      queryClient.setQueryData(['messages', selectedChannel?.id], context.previousMessages);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['messages', selectedChannel?.id] });
      // Update channel last message
      base44.entities.Channel.update(selectedChannel.id, { last_message_at: new Date().toISOString() });
    }
  });

  const deleteMessageMutation = useMutation({
    mutationFn: (messageId) => base44.entities.Message.delete(messageId),
    onSuccess: () => queryClient.invalidateQueries(['messages', selectedChannel?.id])
  });

  const reactMutation = useMutation({
    mutationFn: async ({ messageId, emoji }) => {
      // Fetch current message to get reactions
      // Note: Ideally use optimistic updates or backend logic
      // For simplicity in frontend-only logic:
      const msgs = await base44.entities.Message.filter({ id: messageId });
      if (!msgs.length) return;
      
      const msg = msgs[0];
      const currentReactions = msg.reactions || {};
      const userList = currentReactions[emoji] || [];
      
      let newReactions = { ...currentReactions };
      
      if (userList.includes(currentUser.email)) {
        // Remove reaction
        newReactions[emoji] = userList.filter(e => e !== currentUser.email);
        if (newReactions[emoji].length === 0) delete newReactions[emoji];
      } else {
        // Add reaction
        newReactions[emoji] = [...userList, currentUser.email];
      }

      // Also create MessageReaction entity if we want to be strict with the schema requested
      // But for UI speed/simplicity we just update the message JSON field
      return await base44.entities.Message.update(messageId, { reactions: newReactions });
    },
    onSuccess: () => queryClient.invalidateQueries(['messages', selectedChannel?.id])
  });

  if (!currentUser) return <div className="h-screen flex items-center justify-center"><Loader2 className="animate-spin" /></div>;

  return (
    <ChatLayout
      sidebar={
        <Sidebar 
            channels={channels}
            selectedChannelId={selectedChannel?.id}
            onSelectChannel={setSelectedChannel}
            currentUser={currentUser}
            users={users}
        />
      }
      chat={
        <ChatArea
            channel={selectedChannel}
            messages={messages}
            currentUser={currentUser}
            loading={messagesLoading}
            onSendMessage={(content) => sendMessageMutation.mutateAsync(content)}
            onReply={(msg) => setSelectedThread(msg)}
            onReact={(messageId, emoji) => reactMutation.mutate({ messageId, emoji })}
            onDeleteMessage={(id) => deleteMessageMutation.mutate(id)}
        />
      }
      thread={
        <ThreadView
            parentMessage={selectedThread}
            onClose={() => setSelectedThread(null)}
            currentUser={currentUser}
        />
      }
      showThread={!!selectedThread}
    />
  );
}
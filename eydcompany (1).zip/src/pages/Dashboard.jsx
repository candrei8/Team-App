import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Plus, 
  Folder, 
  Clock, 
  Users, 
  CheckCircle2,
  TrendingUp,
  Calendar,
  BarChart3,
  ArrowRight,
  Sparkles,
  AlertCircle,
  RefreshCw,
  Shield,
  UserCheck,
  Brain,
  Megaphone,
  Globe,
  Crown,
  Palette,
  Cog,
  DollarSign,
  Heart,
  Code,
  Briefcase
} from "lucide-react";
import { motion } from "framer-motion";

import StatsOverview from "../components/dashboard/StatsOverview";
import RecentBoards from "../components/dashboard/RecentBoards";
import ActivityFeed from "../components/dashboard/ActivityFeed";
import QuickActions from "../components/dashboard/QuickActions";
import SphereImageGrid from "../components/ui/img-sphere";
import AnnounceModal from "../components/admin/AnnounceModal";
import { useToast } from "@/components/ui/use-toast";

export default function Dashboard() {
  const [boards, setBoards] = useState([]);
  const [recentBoards, setRecentBoards] = useState([]);
  const [items, setItems] = useState([]);
  const [todoTasks, setTodoTasks] = useState([]);
  const [recentItems, setRecentItems] = useState([]);
  const [users, setUsers] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAnnounceModal, setShowAnnounceModal] = useState(false);

  const { toast } = useToast();

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      console.log('🔄 Cargando datos del Dashboard...');
      
      // Cargar usuario primero
      const userData = await base44.auth.me();
      console.log('✅ Usuario cargado:', userData);
      setUser(userData);
      
      // Cargar todos los boards, items y tareas
      const [allBoardsData, allItemsData, allTasksData] = await Promise.all([
        base44.entities.Board.list("-updated_date"),
        base44.entities.Item.list("-updated_date"),
        base44.entities.TodoTask.list("-due_date")
      ]);

      // Filtrar boards según permisos
      const isAdmin = userData.role === "admin" || userData.custom_role === "admin";

      const visibleBoards = allBoardsData.filter(board => {
        // Admins ven todo
        if (isAdmin) return true;

        // Creador siempre ve su board
        if (board.created_by === userData.email) return true;

        // Boards compartidos son visibles para todos
        if (board.visibility === "shared") return true;

        // Boards privados: verificar permisos
        if (board.visibility === "private") {
          // Verificar participantes
          if (board.participants && board.participants.includes(userData.email)) {
            return true;
          }

          // Verificar departamentos
          if (board.allowed_departments && userData.department && 
              board.allowed_departments.includes(userData.department)) {
            return true;
          }
        }

        return false;
      });

      const myBoards = visibleBoards;
      console.log('✅ Proyectos Visibles:', myBoards.length, 'de', allBoardsData.length, 'totales');
      
      // Obtener IDs de mis boards
      const myBoardIds = myBoards.map(board => board.id);
      
      // Filtrar solo los items de mis boards
      const myItems = allItemsData.filter(item => myBoardIds.includes(item.board_id));
      
      // Filtrar mis tareas personales
      const myTasks = allTasksData.filter(task => task.assigned_to === userData.email);

      console.log('✅ Mis Tareas (Board):', myItems.length);
      console.log('✅ Mis Tareas (Personal):', myTasks.length);
      
      setBoards(myBoards);
      setRecentBoards(myBoards.slice(0, 10));
      setItems(myItems);
      setTodoTasks(myTasks);
      setRecentItems(myItems.slice(0, 20));
      
      // Intentar cargar usuarios (no crítico)
      try {
        const allUsersData = await base44.entities.User.list("-created_date");
        console.log('✅ Usuarios cargados:', allUsersData.length);
        setUsers(allUsersData);
      } catch (userError) {
        console.warn('⚠️ No se pudieron cargar usuarios (puede ser por permisos):', userError);
        // No establecer error, solo dejar users vacío
        setUsers([]);
      }
      
    } catch (error) {
      console.error("❌ Error al cargar datos del panel:", error);
      setError(error.message || "Error al cargar datos");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateBoard = async (boardData) => {
    try {
      console.log('📝 Creando nuevo proyecto...', boardData);
      const newBoard = await base44.entities.Board.create(boardData);
      console.log('✅ Proyecto creado:', newBoard);
      
      setBoards(prev => [newBoard, ...prev]);
      setRecentBoards(prev => [newBoard, ...prev.slice(0, 9)]);
    } catch (error) {
      console.error("❌ Error al crear proyecto:", error);
      alert("Error al crear proyecto: " + (error.message || "Error desconocido"));
    }
  };

  const handleSendAnnouncement = async (announcementData) => {
    try {
      const { title, message, sendEmail, targetType, targetValue, attachments } = announcementData;

      // Determinar usuarios objetivo
      let targetUsers = [];
      if (targetType === "all") {
        const allUsers = await base44.entities.User.list();
        targetUsers = allUsers.filter(u => u.status === "active");
      } else if (targetType === "user") {
        const targetUser = await base44.entities.User.filter({ email: targetValue });
        targetUsers = targetUser;
      } else if (targetType === "department") {
        const deptUsers = await base44.entities.User.filter({ department: targetValue });
        targetUsers = deptUsers.filter(u => u.status === "active");
      }

      // Enviar notificaciones push
      let successCount = 0;
      let failCount = 0;

      for (const targetUser of targetUsers) {
        try {
          await base44.entities.Notification.create({
            user_email: targetUser.email,
            title: title,
            message: message,
            type: "system",
            priority: "high",
            metadata: {
              sender: user.full_name || user.email,
              attachments: attachments || []
            }
          });
          successCount++;
        } catch (error) {
          console.error(`Error al enviar notificación a ${targetUser.email}:`, error);
          failCount++;
        }
      }

      // Enviar emails si está habilitado
      if (sendEmail) {
        for (const targetUser of targetUsers) {
          try {
            await base44.integrations.Core.SendEmail({
              to: targetUser.email,
              from_name: user.full_name || "Sistema",
              subject: title,
              body: message
            });
          } catch (error) {
            console.error(`Error al enviar email a ${targetUser.email}:`, error);
          }
        }
      }

      toast({
        title: "✓ Anuncio enviado",
        description: `Notificaciones enviadas: ${successCount}. Fallidas: ${failCount}${sendEmail ? '. Correos enviados.' : ''}`,
      });
    } catch (error) {
      console.error("Error al enviar anuncio:", error);
      toast({
        title: "Error",
        description: "No se pudo enviar el anuncio",
        variant: "destructive"
      });
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Buenos días";
    if (hour < 18) return "Buenas tardes";
    return "Buenas noches";
  };

  const getUserInitials = (name) => {
    if (!name) return "U";
    const names = name.split(" ");
    if (names.length >= 2) {
      return `${names[0][0]}${names[1][0]}`.toUpperCase();
    }
    return names[0][0].toUpperCase();
  };

  const getDepartmentBadge = (department) => {
    if (!department) {
      return (
        <Badge variant="outline" className="text-gray-500 text-xs">
          <Briefcase className="w-3 h-3 mr-1" />
          Sin departamento
        </Badge>
      );
    }

    const departmentConfig = {
      "IA": { gradient: "from-purple-500 to-indigo-600", icon: Brain, label: "IA" },
      "Marketing": { gradient: "from-pink-500 to-rose-600", icon: Megaphone, label: "Marketing" },
      "Relaciones Internacionales": { gradient: "from-blue-500 to-cyan-600", icon: Globe, label: "Rel. Int." },
      "Dirección": { gradient: "from-indigo-500 to-purple-600", icon: Crown, label: "Dirección" },
      "Diseñador": { gradient: "from-orange-500 to-amber-600", icon: Palette, label: "Diseñador" },
      "Operaciones": { gradient: "from-green-500 to-emerald-600", icon: Cog, label: "Operaciones" },
      "Finanzas": { gradient: "from-emerald-500 to-teal-600", icon: DollarSign, label: "Finanzas" },
      "Recursos Humanos": { gradient: "from-amber-500 to-orange-600", icon: Heart, label: "RRHH" },
      "Tecnología": { gradient: "from-cyan-500 to-blue-600", icon: Code, label: "Tecnología" },
      "Ventas": { gradient: "from-red-500 to-pink-600", icon: TrendingUp, label: "Ventas" },
      "Otro": { gradient: "from-gray-500 to-gray-600", icon: Briefcase, label: "Otro" }
    };

    const config = departmentConfig[department] || departmentConfig["Otro"];
    const Icon = config.icon;

    return (
      <Badge className={`bg-gradient-to-r ${config.gradient} text-white border-0 shadow-sm text-xs`}>
        <Icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  const pendingBoardItems = items.filter(item => !item.data?.status || item.data?.status !== 'Hecho').length;
  const pendingTodoTasks = todoTasks.filter(task => task.status !== 'done' && task.status !== 'Completado').length;
  const pendingTasks = pendingBoardItems + pendingTodoTasks;
  const activeUsers = users.filter(u => u.status === "active");
  const recentUsers = users.slice(0, 8);

  // Generar imágenes de la esfera 3D desde los usuarios del equipo
  const sphereImages = users.map((user) => ({
    id: `user-${user.id}`,
    src: user.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.full_name || 'U')}&background=0073EA&color=fff&size=200&bold=true`,
    alt: user.full_name || "Usuario",
    title: user.full_name || "Usuario",
    description: user.department ? `${user.department}${user.role === 'admin' ? ' - Admin' : ''}` : (user.role === 'admin' ? 'Administrador' : 'Usuario')
  }));

  // Mostrar error si hay
  if (error && !isLoading) {
    return (
      <div className="p-4 md:p-8 bg-[#F5F6F8] min-h-screen">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-16"
          >
            <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertCircle className="w-10 h-10 text-red-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-3">
              Error al cargar el Dashboard
            </h2>
            <p className="text-gray-600 mb-6 max-w-md mx-auto">
              {error}
            </p>
            <Button 
              onClick={loadDashboardData}
              className="bg-[#0073EA] hover:bg-[#0056B3]"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Reintentar
            </Button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-[#F5F6F8] min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Hero Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden"
        >
          <div className="bg-gradient-to-br from-white via-white to-blue-50/30 rounded-2xl p-6 md:p-8 shadow-sm border border-white/60">
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold text-[#323338] leading-tight">
                    ¡{getGreeting()}, {user?.full_name?.split(' ')[0] || 'Usuario'}!
                  </h1>
                  <p className="text-[#676879] text-base mt-1">
                    {isLoading ? (
                      "Cargando tus datos..."
                    ) : (
                      <>
                        ¿Listo para ser productivo hoy? 
                        {pendingTasks > 0 && ` Tienes ${pendingTasks} tarea${pendingTasks !== 1 ? 's' : ''} pendiente${pendingTasks !== 1 ? 's' : ''}.`}
                        {pendingTasks === 0 && boards.length > 0 && " ¡Excelente trabajo!"}
                      </>
                    )}
                  </p>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-3 mt-6">
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Link to={createPageUrl("Boards")}>
                    <Button className="bg-[#0073EA] hover:bg-[#0056B3] text-white rounded-xl h-10 px-5 font-medium shadow-lg hover:shadow-xl transition-all duration-200">
                      <Folder className="w-4 h-4 mr-2" />
                      Ver Mis Proyectos
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </motion.div>
                
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Link to={createPageUrl("Analytics")}>
                    <Button variant="outline" className="border-2 border-[#E1E5F3] hover:border-[#0073EA] hover:bg-[#0073EA]/5 rounded-xl h-10 px-5 font-medium transition-all duration-200">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Ver Analítica
                    </Button>
                  </Link>
                </motion.div>

                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button 
                    onClick={() => setShowAnnounceModal(true)}
                    className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl h-10 px-5 font-medium shadow-lg hover:shadow-xl transition-all duration-200"
                  >
                    <Megaphone className="w-4 h-4 mr-2" />
                    Enviar Anuncio
                  </Button>
                </motion.div>

                {!isLoading && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={loadDashboardData}
                    className="rounded-xl h-10 w-10 hover:bg-white/80"
                    title="Refrescar datos"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
            
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-blue-500/10 to-transparent rounded-full -translate-y-12 translate-x-12"></div>
            <div className="absolute bottom-0 left-0 w-20 h-20 bg-gradient-to-tr from-blue-500/5 to-transparent rounded-full translate-y-10 -translate-x-10"></div>
          </div>
        </motion.div>

        {/* Resumen de Estadísticas */}
        <StatsOverview 
          boards={boards}
          items={items}
          todoTasks={todoTasks}
          isLoading={isLoading}
        />

        {/* Grid de Contenido Principal */}
        <div className="grid xl:grid-cols-4 gap-8">
          {/* Columna Izquierda - Proyectos */}
          <div className="xl:col-span-3 space-y-8">
            <RecentBoards 
              boards={recentBoards}
              isLoading={isLoading}
              onCreateBoard={handleCreateBoard}
            />

            {/* Sección de Equipo con Esfera 3D */}
            {users.length > 0 && sphereImages.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Card className="bg-white shadow-sm border border-gray-200">
                  <CardHeader className="flex flex-row items-center justify-between pb-3">
                    <div className="flex items-center gap-2">
                      <Users className="w-5 h-5 text-[#0073EA]" />
                      <CardTitle className="text-lg">Equipo</CardTitle>
                    </div>
                    <Link to={createPageUrl("Users")}>
                      <Button variant="ghost" size="sm" className="text-[#0073EA] hover:text-[#0056B3]">
                        Ver todos
                        <ArrowRight className="w-4 h-4 ml-1" />
                      </Button>
                    </Link>
                  </CardHeader>
                  <CardContent className="flex justify-center items-center py-8">
                    {isLoading ? (
                      <div className="flex justify-center items-center h-[400px]">
                        <div className="animate-pulse">
                          <div className="w-[400px] h-[400px] bg-gray-200 rounded-full"></div>
                        </div>
                      </div>
                    ) : (
                      <SphereImageGrid
                        images={sphereImages}
                        containerSize={500}
                        sphereRadius={200}
                        dragSensitivity={0.8}
                        momentumDecay={0.96}
                        maxRotationSpeed={6}
                        baseImageScale={0.15}
                        hoverScale={1.3}
                        perspective={1000}
                        autoRotate={true}
                        autoRotateSpeed={0.2}
                      />
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>

          {/* Barra Lateral Derecha */}
          <div className="space-y-8">
            <QuickActions onCreateBoard={handleCreateBoard} />
            <ActivityFeed 
              items={recentItems.slice(0, 5)}
              isLoading={isLoading}
            />
          </div>
        </div>
        
        {/* Debug info */}
        {!isLoading && boards.length === 0 && items.length === 0 && (
          <div className="text-center py-8">
            <p className="text-sm text-gray-500">
              No hay datos que mostrar. Crea tu primer proyecto para comenzar.
            </p>
          </div>
        )}
      </div>

      {/* Modal de Anuncios */}
      <AnnounceModal
        isOpen={showAnnounceModal}
        onClose={() => setShowAnnounceModal(false)}
        onSubmit={handleSendAnnouncement}
      />
    </div>
  );
}
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, CheckCircle2, AlertCircle, Activity, User } from "lucide-react";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";
import { format, formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";

export default function ActivityFeed({ items, isLoading }) {
  const getStatusIcon = (status) => {
    const statusLower = status?.toLowerCase() || '';
    if (statusLower === 'hecho' || statusLower === 'done' || statusLower === 'completado') {
      return CheckCircle2;
    }
    if (statusLower === 'trabajando' || statusLower === 'working' || statusLower === 'en progreso') {
      return Clock;
    }
    if (statusLower === 'bloqueado' || statusLower === 'stuck') {
      return AlertCircle;
    }
    return Clock;
  };

  const getStatusColor = (status) => {
    const statusLower = status?.toLowerCase() || '';
    if (statusLower === 'hecho' || statusLower === 'done' || statusLower === 'completado') {
      return 'text-white bg-gradient-to-r from-green-500 to-emerald-500';
    }
    if (statusLower === 'trabajando' || statusLower === 'working' || statusLower === 'en progreso') {
      return 'text-white bg-gradient-to-r from-amber-500 to-orange-500';
    }
    if (statusLower === 'bloqueado' || statusLower === 'stuck') {
      return 'text-white bg-gradient-to-r from-red-500 to-pink-500';
    }
    return 'text-white bg-gradient-to-r from-gray-500 to-slate-500';
  };

  const getUserInitials = (email) => {
    if (!email) return 'U';
    const namePart = email.split('@')[0];
    const parts = namePart.split(/[._-]/);
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return namePart.substring(0, 2).toUpperCase();
  };

  const getUserColor = (email) => {
    if (!email) return '#9CA3AF';
    const colors = [
      '#3B82F6', '#10B981', '#F59E0B', '#EF4444',
      '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'
    ];
    let hash = 0;
    for (let i = 0; i < email.length; i++) {
      hash = email.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  const getFormattedDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);

    // Si fue hace menos de 24 horas, mostrar tiempo relativo
    if (diffInHours < 24) {
      return formatDistanceToNow(date, { 
        addSuffix: true, 
        locale: es 
      });
    }

    // Si fue hoy, mostrar "Hoy a las HH:mm"
    if (date.toDateString() === now.toDateString()) {
      return `Hoy a las ${format(date, 'HH:mm')}`;
    }

    // Si fue ayer, mostrar "Ayer a las HH:mm"
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
      return `Ayer a las ${format(date, 'HH:mm')}`;
    }

    // Para fechas más antiguas, mostrar fecha completa
    return format(date, "d 'de' MMM 'a las' HH:mm", { locale: es });
  };

  return (
    <Card className="border-0 shadow-lg bg-gradient-to-br from-white via-white to-green-50/30 backdrop-blur-sm">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
            <Activity className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-lg font-bold text-[#323338]">
              Actividad Reciente
            </CardTitle>
            <p className="text-sm text-[#676879]">Últimas actualizaciones</p>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="flex items-center gap-3">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div className="flex-1">
                  <Skeleton className="h-3 w-full mb-2" />
                  <Skeleton className="h-2 w-20" />
                </div>
              </div>
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-12 h-12 bg-gradient-to-br from-gray-100 to-gray-200 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Activity className="w-6 h-6 text-gray-400" />
            </div>
            <p className="text-[#676879] text-sm">Sin actividad reciente</p>
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((item, index) => {
              const StatusIcon = getStatusIcon(item.data?.status);
              const statusColor = getStatusColor(item.data?.status);
              const userEmail = item.created_by || 'usuario@email.com';
              const userInitials = getUserInitials(userEmail);
              const userColor = getUserColor(userEmail);
              
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ scale: 1.02 }}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-gradient-to-r hover:from-blue-50/50 hover:to-green-50/50 transition-all duration-200 cursor-pointer border border-transparent hover:border-blue-100"
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shadow-lg ${statusColor}`}>
                    <StatusIcon className="w-4 h-4" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-[#323338] truncate mb-1">
                      {item.title}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-[#676879]">
                      <div 
                        className="w-5 h-5 rounded-full flex items-center justify-center text-white text-[10px] font-bold shadow-sm"
                        style={{ backgroundColor: userColor }}
                        title={userEmail}
                      >
                        {userInitials}
                      </div>
                      <span className="truncate max-w-[150px]" title={userEmail}>
                        {userEmail.split('@')[0]}
                      </span>
                      <span className="text-gray-400">•</span>
                      <span className="whitespace-nowrap">
                        {getFormattedDate(item.updated_date)}
                      </span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
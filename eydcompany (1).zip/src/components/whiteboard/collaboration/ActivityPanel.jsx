import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Activity, StickyNote, Square, Type, Trash2, MessageSquare, UserPlus, UserMinus, AtSign } from "lucide-react";
import { format, formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';

const ACTION_ICONS = {
  create: StickyNote,
  update: Square,
  delete: Trash2,
  comment: MessageSquare,
  mention: AtSign,
  join: UserPlus,
  leave: UserMinus
};

const ACTION_COLORS = {
  create: 'text-green-600',
  update: 'text-blue-600',
  delete: 'text-red-600',
  comment: 'text-purple-600',
  mention: 'text-yellow-600',
  join: 'text-gray-600',
  leave: 'text-gray-400'
};

export default function ActivityPanel({ 
  activities, 
  currentUserEmail, 
  onActivityClick 
}) {
  const [filter, setFilter] = useState('all');
  const [isOpen, setIsOpen] = useState(false);

  const filteredActivities = activities.filter(activity => {
    if (filter === 'mentions') {
      return activity.action_type === 'mention' && 
             activity.metadata?.mentioned_users?.includes(currentUserEmail);
    }
    if (filter === 'mine') {
      return activity.user_email === currentUserEmail;
    }
    return true;
  });

  const getUserInitials = (name) => {
    const parts = name.split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  const getActionDescription = (activity) => {
    switch (activity.action_type) {
      case 'create':
        return `creó ${activity.element_type || 'un elemento'}`;
      case 'update':
        return `editó ${activity.element_type || 'un elemento'}`;
      case 'delete':
        return `eliminó ${activity.element_type || 'un elemento'}`;
      case 'comment':
        return 'añadió un comentario';
      case 'mention':
        return 'te mencionó';
      case 'join':
        return 'se unió al whiteboard';
      case 'leave':
        return 'salió del whiteboard';
      default:
        return activity.description || 'realizó una acción';
    }
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <Activity className="w-4 h-4" />
        </Button>
      </SheetTrigger>
      <SheetContent className="w-96">
        <SheetHeader>
          <SheetTitle>Actividad Reciente</SheetTitle>
        </SheetHeader>

        <div className="mt-4 space-y-4">
          {/* Filtros */}
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toda la actividad</SelectItem>
              <SelectItem value="mentions">Solo menciones a mí</SelectItem>
              <SelectItem value="mine">Solo mis acciones</SelectItem>
            </SelectContent>
          </Select>

          {/* Lista de actividades */}
          <ScrollArea className="h-[calc(100vh-200px)]">
            <div className="space-y-3 pr-4">
              {filteredActivities.map((activity) => {
                const Icon = ACTION_ICONS[activity.action_type] || Activity;
                const colorClass = ACTION_COLORS[activity.action_type] || 'text-gray-600';
                const isClickable = activity.element_id && activity.action_type !== 'delete';

                return (
                  <div
                    key={activity.id}
                    onClick={() => isClickable && onActivityClick(activity)}
                    className={`flex items-start gap-3 p-3 rounded-lg border transition-all ${
                      isClickable 
                        ? 'hover:bg-gray-50 hover:border-gray-300 cursor-pointer' 
                        : 'bg-gray-50'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                      {getUserInitials(activity.user_name)}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Icon className={`w-4 h-4 flex-shrink-0 ${colorClass}`} />
                        <p className="text-sm text-gray-900">
                          <span className="font-medium">{activity.user_name}</span>
                          {' '}
                          <span className="text-gray-600">
                            {getActionDescription(activity)}
                          </span>
                        </p>
                      </div>

                      <p className="text-xs text-gray-500">
                        {formatDistanceToNow(new Date(activity.created_date), { 
                          addSuffix: true, 
                          locale: es 
                        })}
                      </p>

                      {activity.action_type === 'mention' && (
                        <Badge className="mt-2 bg-yellow-100 text-yellow-800 text-xs">
                          Te mencionó
                        </Badge>
                      )}
                    </div>

                    {isClickable && (
                      <div className="text-gray-400">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </div>
                    )}
                  </div>
                );
              })}

              {filteredActivities.length === 0 && (
                <div className="text-center py-12 text-gray-500">
                  <Activity className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-sm">No hay actividad reciente</p>
                  {filter !== 'all' && (
                    <p className="text-xs text-gray-400 mt-1">
                      Prueba cambiar el filtro
                    </p>
                  )}
                </div>
              )}
            </div>
          </ScrollArea>
        </div>
      </SheetContent>
    </Sheet>
  );
}
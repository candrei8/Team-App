import React, { useRef, useState, useEffect, useCallback } from 'react';
import { useWhiteboard, generateId } from './store/WhiteboardContext';
import { useWhiteboardSocket } from './hooks/useWhiteboardSocket';
import Element from './CanvasElement';
import { motion } from 'framer-motion';
import { ZoomIn, ZoomOut, MousePointer2 } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function WhiteboardCanvas({ whiteboardId, user }) {
  const { state, dispatch } = useWhiteboard();
  const { broadcast } = useWhiteboardSocket(whiteboardId, user);
  const svgRef = useRef(null);
  
  const [dragStart, setDragStart] = useState(null);
  const [isSpacePressed, setIsSpacePressed] = useState(false);
  
  // Temporary drawing state
  const [drawingEl, setDrawingEl] = useState(null);
  const [movingEl, setMovingEl] = useState(null);

  // Viewport transform helpers
  const toScreen = (x, y) => ({
    x: x * state.viewport.zoom + state.viewport.x,
    y: y * state.viewport.zoom + state.viewport.y
  });
  
  const toWorld = (x, y) => ({
    x: (x - state.viewport.x) / state.viewport.zoom,
    y: (y - state.viewport.y) / state.viewport.zoom
  });

  const getMousePos = (e) => {
    const rect = svgRef.current.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  // Event Handlers
  const handleWheel = useCallback((e) => {
    e.preventDefault();
    if (e.ctrlKey || e.metaKey) {
      // Zoom
      const zoomSensitivity = 0.001;
      const newZoom = Math.max(0.1, Math.min(5, state.viewport.zoom - e.deltaY * zoomSensitivity));
      
      // Zoom towards mouse
      const mouse = getMousePos(e);
      const worldMouse = toWorld(mouse.x, mouse.y);
      
      const newX = mouse.x - worldMouse.x * newZoom;
      const newY = mouse.y - worldMouse.y * newZoom;
      
      dispatch({ type: 'SET_VIEWPORT', payload: { x: newX, y: newY, zoom: newZoom } });
    } else {
      // Pan
      dispatch({ type: 'SET_VIEWPORT', payload: { x: state.viewport.x - e.deltaX, y: state.viewport.y - e.deltaY } });
    }
  }, [state.viewport, dispatch]);

  const handlePointerDown = (e) => {
    const mouse = getMousePos(e);
    const world = toWorld(mouse.x, mouse.y);
    
    // Space pan
    if (isSpacePressed || state.tool === 'hand') {
      setDragStart({ type: 'pan', startX: mouse.x, startY: mouse.y, initialViewport: { ...state.viewport } });
      return;
    }

    // Drawing
    if (['rect', 'circle', 'diamond', 'text', 'sticky'].includes(state.tool)) {
      const id = generateId();
      const newEl = {
        id,
        type: state.tool,
        x: world.x,
        y: world.y,
        width: 0,
        height: 0,
        fill: state.tool === 'sticky' ? '#FFF9C4' : '#ffffff',
        stroke: '#000000',
        strokeWidth: 2,
        text: state.tool === 'text' ? 'Texto' : (state.tool === 'sticky' ? 'Nota' : '')
      };
      setDrawingEl(newEl);
      return;
    }
    
    // Selecting
    if (state.tool === 'select') {
      // If clicked on element (handled in Element component), but here we handle background click
      // We'll check if e.target is the svg background
      if (e.target === svgRef.current) {
        dispatch({ type: 'SET_SELECTION', payload: [] });
        // Selection box logic could go here
      }
    }
  };

  const handlePointerMove = (e) => {
    const mouse = getMousePos(e);
    const world = toWorld(mouse.x, mouse.y);
    
    // Broadcast cursor
    // Throttle this in real app
    broadcast({ 
      type: 'cursor_move', 
      userId: user?.email, 
      name: user?.full_name || 'Anon', 
      color: '#f00', 
      cursor: world 
    });

    if (dragStart) {
      if (dragStart.type === 'pan') {
        const dx = mouse.x - dragStart.startX;
        const dy = mouse.y - dragStart.startY;
        dispatch({ 
          type: 'SET_VIEWPORT', 
          payload: { 
            x: dragStart.initialViewport.x + dx, 
            y: dragStart.initialViewport.y + dy 
          } 
        });
      }
    } else if (drawingEl) {
      // Update drawing element size
      const w = world.x - drawingEl.x;
      const h = world.y - drawingEl.y;
      
      // For circle/diamond, we might want centered or specific logic, keeping it simple
      setDrawingEl({
        ...drawingEl,
        width: Math.abs(w),
        height: Math.abs(h),
        x: w < 0 ? world.x : drawingEl.x, // Handle negative drag
        y: h < 0 ? world.y : drawingEl.y
      });
    } else if (movingEl) {
        // Logic for moving elements would go here if we handled drag on elements in this handler
        // But we handle "element drag" slightly differently usually (in Element onPointerDown)
        // For simplicity in this scratchpad, we'll omit complex move logic here
    }
  };

  const handlePointerUp = () => {
    if (drawingEl) {
      // Finalize create
      if (drawingEl.width > 5 || drawingEl.height > 5 || drawingEl.type === 'text') {
        // Default size for click-to-create
        const finalEl = { 
          ...drawingEl, 
          width: Math.max(drawingEl.width, 50), 
          height: Math.max(drawingEl.height, 50) 
        };
        
        dispatch({ type: 'ADD_ELEMENT', payload: finalEl });
        broadcast({ type: 'element_create', element: finalEl });
        
        // Reset tool to select after draw usually
        dispatch({ type: 'SET_TOOL', payload: 'select' });
      }
      setDrawingEl(null);
    }
    setDragStart(null);
  };

  // Handle space key for panning
  useEffect(() => {
    const down = (e) => { if(e.code === 'Space') setIsSpacePressed(true); };
    const up = (e) => { if(e.code === 'Space') setIsSpacePressed(false); };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
    };
  }, []);

  // Listen for wheel on SVG with { passive: false } to prevent browser zoom
  useEffect(() => {
    const el = svgRef.current;
    if (el) el.addEventListener('wheel', handleWheel, { passive: false });
    return () => { if (el) el.removeEventListener('wheel', handleWheel); };
  }, [handleWheel]);

  // Background grid pattern
  const gridSize = 20 * state.viewport.zoom;
  const gridOpacity = 0.1;

  return (
    <div className="w-full h-full overflow-hidden bg-[#F5F6F8] relative cursor-crosshair">
      <svg
        ref={svgRef}
        className="w-full h-full touch-none"
        style={{ 
          cursor: isSpacePressed || state.tool === 'hand' || dragStart?.type === 'pan' ? 'grab' : 'default' 
        }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
      >
        <defs>
          <pattern id="grid" width={gridSize} height={gridSize} patternUnits="userSpaceOnUse">
            <circle cx={gridSize/2} cy={gridSize/2} r={1 * state.viewport.zoom} fill="#000" opacity={gridOpacity} />
          </pattern>
        </defs>
        
        <rect x="0" y="0" width="100%" height="100%" fill="url(#grid)" style={{ transform: `translate(${state.viewport.x % gridSize}px, ${state.viewport.y % gridSize}px)` }} />

        <g transform={`translate(${state.viewport.x}, ${state.viewport.y}) scale(${state.viewport.zoom})`}>
          {state.elements.map(el => (
             <Element 
               key={el.id} 
               el={el} 
               isSelected={state.selection.includes(el.id)} 
               onSelect={(id, multi) => {
                 if (state.tool === 'select') {
                   dispatch({ type: 'SET_SELECTION', payload: multi ? [...state.selection, id] : [id] });
                 }
               }}
             />
          ))}
          {drawingEl && (
             <Element el={drawingEl} isSelected={true} onSelect={() => {}} />
          )}
          
          {/* Collaborator Cursors */}
          {Object.entries(state.collaborators).map(([uid, data]) => (
             data.cursor && (
               <g key={uid} transform={`translate(${data.cursor.x}, ${data.cursor.y})`}>
                 <MousePointer2 className="w-4 h-4" fill={data.color} color={data.color} style={{ marginLeft: '-3px', marginTop: '-2px' }} />
                 <text x="12" y="16" fontSize="12" fill={data.color} fontWeight="bold">{data.name}</text>
               </g>
             )
          ))}
        </g>
      </svg>

      {/* Quick Zoom Controls */}
      <div className="absolute bottom-6 right-6 flex gap-2">
        <Button 
          variant="secondary" size="icon" className="rounded-xl shadow-sm bg-white"
          onClick={() => dispatch({ type: 'SET_VIEWPORT', payload: { ...state.viewport, zoom: state.viewport.zoom - 0.1 } })}
        >
          <ZoomOut className="w-4 h-4" />
        </Button>
        <div className="bg-white px-3 py-2 rounded-xl shadow-sm text-sm font-medium border flex items-center">
          {Math.round(state.viewport.zoom * 100)}%
        </div>
        <Button 
          variant="secondary" size="icon" className="rounded-xl shadow-sm bg-white"
          onClick={() => dispatch({ type: 'SET_VIEWPORT', payload: { ...state.viewport, zoom: state.viewport.zoom + 0.1 } })}
        >
          <ZoomIn className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
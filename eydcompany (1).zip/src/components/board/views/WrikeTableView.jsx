import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  MoreHorizontal,
  Trash2,
  GripVertical
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import TaskEditModal from "../TaskEditModal";
import StatusCell from "../cells/StatusCell";
import PeopleCell from "../cells/PeopleCell";
import DateCell from "../cells/DateCell";
import NumberCell from "../cells/NumberCell";
import PriorityCell from "../cells/PriorityCell";
import TextCell from "../cells/TextCell";

// Componente de fila de tarea
const TaskRow = ({ item, columns, board, onUpdate, onDelete, isSelected, onSelect }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);

  const handleCellUpdate = (columnId, value) => {
    const updatedData = { ...item.data, [columnId]: value };
    onUpdate(item.id, { data: updatedData });
  };

  const renderCell = (column) => {
    const value = item.data?.[column.id];

    switch (column.type) {
      case 'status':
        return (
          <StatusCell
            value={value}
            options={column.options}
            onUpdate={(newValue) => handleCellUpdate(column.id, newValue)}
          />
        );
      
      case 'people':
        return (
          <PeopleCell
            value={value}
            onUpdate={(newValue) => handleCellUpdate(column.id, newValue)}
          />
        );
      
      case 'date':
        return (
          <DateCell
            value={value}
            onUpdate={(newValue) => handleCellUpdate(column.id, newValue)}
          />
        );
      
      case 'number':
        return (
          <NumberCell
            value={value}
            onUpdate={(newValue) => handleCellUpdate(column.id, newValue)}
          />
        );
      
      case 'priority':
        return (
          <PriorityCell
            value={value}
            options={column.options}
            onUpdate={(newValue) => handleCellUpdate(column.id, newValue)}
          />
        );
      
      case 'text':
      default:
        return (
          <TextCell
            value={value || ''}
            onUpdate={(newValue) => handleCellUpdate(column.id, newValue)}
          />
        );
    }
  };

  return (
    <>
      <tr
        className={`border-b hover:bg-gray-50 transition-colors group ${isSelected ? 'bg-blue-50' : ''}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Checkbox */}
        <td className="w-10 px-2 sticky left-0 bg-white group-hover:bg-gray-50 z-10">
          <div className="flex items-center justify-center">
            {(isHovered || isSelected) && (
              <Checkbox
                checked={isSelected}
                onCheckedChange={onSelect}
              />
            )}
            {!isHovered && !isSelected && (
              <span className="text-xs text-gray-400">{item.order_index + 1}</span>
            )}
          </div>
        </td>

        {/* Task Name */}
        <td 
          className="px-4 py-3 sticky left-10 bg-white group-hover:bg-gray-50 z-10 cursor-pointer"
          onClick={() => setShowEditModal(true)}
        >
          <div className="flex items-center gap-2">
            <GripVertical className="w-4 h-4 text-gray-400 opacity-0 group-hover:opacity-100" />
            <span className="font-medium text-gray-900">{item.title}</span>
          </div>
        </td>

        {/* Dynamic columns */}
        {columns.filter(col => col.id !== 'task').map((column) => (
          <td key={column.id} className="px-4 py-3 text-sm">
            {renderCell(column)}
          </td>
        ))}

        {/* Actions */}
        <td className="w-10 px-2 sticky right-0 bg-white group-hover:bg-gray-50 z-10">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 opacity-0 group-hover:opacity-100"
              >
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setShowEditModal(true)}>
                Editar
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="text-red-600"
                onClick={() => {
                  if (window.confirm('¿Eliminar esta tarea?')) {
                    onDelete(item.id);
                  }
                }}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Eliminar
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </td>
      </tr>

      {showEditModal && (
        <TaskEditModal
          isOpen={showEditModal}
          onClose={() => setShowEditModal(false)}
          task={item}
          board={board}
          onUpdate={onUpdate}
          onDelete={onDelete}
        />
      )}
    </>
  );
};

// Componente principal
export default function WrikeTableView({
  board,
  items,
  onAddItem,
  onUpdateItem,
  onDeleteItem,
  onAddColumn,
  onUpdateColumn,
  onDeleteColumn,
  isLoading,
  searchQuery,
  onSearchChange
}) {
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [selectedItems, setSelectedItems] = useState(new Set());

  if (!board) return null;

  const handleAddTask = async (e) => {
    e.preventDefault();
    if (newTaskTitle.trim()) {
      await onAddItem(null, newTaskTitle.trim());
      setNewTaskTitle('');
      setIsAddingTask(false);
    }
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      setSelectedItems(new Set(items.map(item => item.id)));
    } else {
      setSelectedItems(new Set());
    }
  };

  const handleSelectItem = (itemId, checked) => {
    const newSelected = new Set(selectedItems);
    if (checked) {
      newSelected.add(itemId);
    } else {
      newSelected.delete(itemId);
    }
    setSelectedItems(newSelected);
  };

  // Obtener columnas (excluyendo 'task' que va al principio)
  const visibleColumns = (board.columns || []).filter(col => col.id !== 'task');

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      {/* Tabla */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              {/* Checkbox header */}
              <th className="w-10 px-2 py-3 sticky left-0 bg-gray-50 z-20">
                <Checkbox
                  checked={items.length > 0 && selectedItems.size === items.length}
                  onCheckedChange={handleSelectAll}
                />
              </th>

              {/* Name column */}
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 sticky left-10 bg-gray-50 z-20">
                Nombre
              </th>

              {/* Dynamic columns */}
              {visibleColumns.map((column) => (
                <th 
                  key={column.id}
                  className="px-4 py-3 text-left text-sm font-semibold text-gray-700 whitespace-nowrap"
                  style={{ minWidth: column.width || 150 }}
                >
                  <div className="flex items-center gap-2">
                    <span>{column.title}</span>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-5 w-5 opacity-0 hover:opacity-100">
                          <MoreHorizontal className="w-3 h-3" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => onDeleteColumn(column.id)}>
                          <Trash2 className="w-4 h-4 mr-2" />
                          Eliminar columna
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </th>
              ))}

              {/* Actions column */}
              <th className="w-10 px-2 py-3 sticky right-0 bg-gray-50 z-20">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={onAddColumn}
                  title="Añadir columna"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </th>
            </tr>
          </thead>

          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={visibleColumns.length + 3} className="px-4 py-8 text-center">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </td>
              </tr>
            ) : items.length === 0 ? (
              <tr>
                <td colSpan={visibleColumns.length + 3} className="px-4 py-8 text-center text-gray-500">
                  No hay tareas. Haz clic en "+" para añadir una.
                </td>
              </tr>
            ) : (
              items.map((item) => (
                <TaskRow
                  key={item.id}
                  item={item}
                  columns={board.columns}
                  board={board}
                  onUpdate={onUpdateItem}
                  onDelete={onDeleteItem}
                  isSelected={selectedItems.has(item.id)}
                  onSelect={(checked) => handleSelectItem(item.id, checked)}
                />
              ))
            )}

            {/* Add task row */}
            {isAddingTask ? (
              <tr className="border-b">
                <td className="w-10 px-2 sticky left-0 bg-white"></td>
                <td className="px-4 py-3 sticky left-10 bg-white" colSpan={visibleColumns.length + 2}>
                  <form onSubmit={handleAddTask} className="flex items-center gap-2">
                    <Input
                      autoFocus
                      value={newTaskTitle}
                      onChange={(e) => setNewTaskTitle(e.target.value)}
                      onBlur={() => {
                        if (!newTaskTitle.trim()) {
                          setIsAddingTask(false);
                        }
                      }}
                      placeholder="Nombre de la tarea"
                      className="h-8 flex-1"
                      onKeyDown={(e) => {
                        if (e.key === 'Escape') {
                          setIsAddingTask(false);
                          setNewTaskTitle('');
                        }
                      }}
                    />
                  </form>
                </td>
              </tr>
            ) : (
              <tr className="border-b hover:bg-gray-50">
                <td className="w-10 px-2 sticky left-0 bg-white"></td>
                <td className="px-4 py-3 sticky left-10 bg-white" colSpan={visibleColumns.length + 2}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-500 hover:text-gray-700"
                    onClick={() => setIsAddingTask(true)}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Añadir tarea
                  </Button>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Footer con información */}
      {items.length > 0 && (
        <div className="border-t bg-gray-50 px-4 py-2 text-sm text-gray-600">
          {items.length} tarea{items.length !== 1 ? 's' : ''}
          {selectedItems.size > 0 && ` • ${selectedItems.size} seleccionada${selectedItems.size !== 1 ? 's' : ''}`}
        </div>
      )}
    </div>
  );
}
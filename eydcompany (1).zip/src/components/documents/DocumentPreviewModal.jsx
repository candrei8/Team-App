import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, Download, FileText, AlertCircle } from "lucide-react";

export default function DocumentPreviewModal({ isOpen, onClose, document }) {
  if (!document) return null;

  const isImage = document.file_type?.startsWith('image/');
  const isPDF = document.file_type?.includes('pdf');
  const isText = document.file_type?.includes('text/') || document.file_type?.includes('json') || document.file_extension === 'txt' || document.file_extension === 'md';
  const canPreview = isImage || isPDF || isText;

  const handleDownload = () => {
    window.open(document.file_url, '_blank');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] sm:max-w-4xl max-h-[90vh] p-0">
        <DialogHeader className="px-4 sm:px-6 py-3 sm:py-4 border-b pr-12">
          <div className="flex items-center justify-between gap-3">
            <DialogTitle className="text-base sm:text-lg font-semibold text-gray-900 truncate flex-1">
              {document.name}
            </DialogTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownload}
              className="h-8 sm:h-9 flex-shrink-0"
            >
              <Download className="w-4 h-4 mr-1.5" />
              <span className="hidden sm:inline">Descargar</span>
            </Button>
          </div>
        </DialogHeader>

        <div className="p-4 sm:p-6 overflow-y-auto max-h-[calc(90vh-80px)]">
          {isImage ? (
            <div className="flex items-center justify-center bg-gray-50 rounded-lg p-4">
              <img
                src={document.file_url}
                alt={document.name}
                className="max-w-full max-h-[70vh] object-contain rounded-lg shadow-lg"
              />
            </div>
          ) : isPDF ? (
            <div className="w-full h-[70vh] bg-gray-50 rounded-lg overflow-hidden">
              <iframe
                src={document.file_url}
                className="w-full h-full border-0"
                title={document.name}
              />
            </div>
          ) : isText ? (
            <div className="w-full h-[70vh] bg-white rounded-lg overflow-hidden border border-gray-200">
              <iframe
                src={document.file_url}
                className="w-full h-full border-0 bg-white p-4 font-mono text-sm"
                title={document.name}
              />
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <FileText className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Vista previa no disponible
              </h3>
              <p className="text-sm text-gray-500 mb-6 max-w-md">
                Este tipo de archivo no se puede previsualizar en el navegador.
                Descárgalo para verlo.
              </p>
              <Button
                onClick={handleDownload}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Download className="w-4 h-4 mr-2" />
                Descargar Archivo
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
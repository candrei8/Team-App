import React, { createContext, useContext, useReducer, useCallback, useRef } from 'react';

const WhiteboardContext = createContext();

const initialState = {
  elements: [], // { id, type, x, y, width, height, fill, stroke, ... }
  viewport: { x: 0, y: 0, zoom: 1 },
  selection: [], // array of selected element ids
  tool: 'select', // select, hand, rect, circle, diamond, text, sticky, connector, image
  isDragging: false,
  collaborators: {}, // { userId: { cursor: {x,y}, color, name } }
  currentUser: null
};

// Helper: Generate ID
const generateId = () => `el_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

function reducer(state, action) {
  switch (action.type) {
    case 'SET_VIEWPORT':
      return { ...state, viewport: { ...state.viewport, ...action.payload } };
    case 'SET_TOOL':
      return { ...state, tool: action.payload, selection: [] };
    case 'ADD_ELEMENT':
      return { ...state, elements: [...state.elements, action.payload] };
    case 'UPDATE_ELEMENT':
      return {
        ...state,
        elements: state.elements.map(el => 
          el.id === action.payload.id ? { ...el, ...action.payload.changes } : el
        )
      };
    case 'UPDATE_ELEMENTS_BULK': // For remote updates
      const updates = action.payload; // map or array
      return {
        ...state,
        elements: state.elements.map(el => {
          const update = updates[el.id];
          return update ? { ...el, ...update } : el;
        })
      };
    case 'DELETE_ELEMENTS':
      const idsToDelete = new Set(action.payload);
      return { ...state, elements: state.elements.filter(el => !idsToDelete.has(el.id)), selection: [] };
    case 'SET_SELECTION':
      return { ...state, selection: action.payload };
    case 'UPDATE_COLLABORATOR':
      return {
        ...state,
        collaborators: {
          ...state.collaborators,
          [action.payload.userId]: { ...state.collaborators[action.payload.userId], ...action.payload.data }
        }
      };
    case 'REMOVE_COLLABORATOR':
      const newCollaborators = { ...state.collaborators };
      delete newCollaborators[action.payload];
      return { ...state, collaborators: newCollaborators };
    case 'SET_ELEMENTS':
      return { ...state, elements: action.payload };
    case 'SET_USER':
      return { ...state, currentUser: action.payload };
    default:
      return state;
  }
}

export function WhiteboardProvider({ children, initialData = {} }) {
  const [state, dispatch] = useReducer(reducer, { ...initialState, ...initialData });
  const wsRef = useRef(null);

  return (
    <WhiteboardContext.Provider value={{ state, dispatch, wsRef }}>
      {children}
    </WhiteboardContext.Provider>
  );
}

export function useWhiteboard() {
  return useContext(WhiteboardContext);
}

export { generateId };
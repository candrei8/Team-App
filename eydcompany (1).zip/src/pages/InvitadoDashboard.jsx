import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Briefcase, 
  DollarSign, 
  Upload, 
  AlertCircle, 
  CheckCircle2, 
  TrendingUp,
  UserCheck
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";

export default function InvitadoDashboard() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [invoices, setInvoices] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);

      const [profileData, invoicesData, submissionsData] = await Promise.all([
        base44.entities.GuestProfile.filter({ user_email: userData.email }),
        base44.entities.GuestInvoice.filter({ user_email: userData.email }),
        base44.entities.GuestSubmission.filter({ user_email: userData.email })
      ]);

      setProfile(profileData[0] || {});
      setInvoices(invoicesData);
      setSubmissions(submissionsData);
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  const calculateProfileCompletion = () => {
    if (!profile) return 0;
    const fields = ['bio', 'phone', 'address', 'tax_id', 'bank_account', 'specialty'];
    const filled = fields.filter(field => profile[field]).length;
    return Math.round((filled / fields.length) * 100);
  };

  const pendingInvoices = invoices.filter(inv => inv.status === 'pending');
  const paidInvoices = invoices.filter(inv => inv.status === 'paid');
  const totalEarned = paidInvoices.reduce((sum, inv) => sum + (inv.amount || 0), 0);

  // Mock data for chart if not enough real data
  const chartData = [
    { name: 'Ene', amount: 0 },
    { name: 'Feb', amount: 0 },
    { name: 'Mar', amount: 0 },
    { name: 'Abr', amount: 0 },
    { name: 'May', amount: 0 },
    { name: 'Jun', amount: 0 },
  ];

  // Fill chart data with real invoices
  paidInvoices.forEach(inv => {
    if (inv.date) {
      const month = new Date(inv.date).getMonth();
      if (month < 6) chartData[month].amount += inv.amount;
    }
  });

  if (loading) return <div className="p-8 text-center">Cargando panel...</div>;

  return (
    <div className="space-y-6">
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Hola, {user?.full_name?.split(' ')[0]} 👋</h1>
        <p className="text-gray-500">Bienvenido a tu panel de colaborador. Aquí tienes un resumen de tu actividad.</p>
      </header>

      {/* Profile Completion Widget */}
      <Card className="bg-white shadow-sm border-gray-200">
        <CardContent className="p-6 flex items-center gap-6">
          <div className="flex-1">
            <div className="flex justify-between mb-2">
              <span className="font-medium text-gray-700">Estado de tu perfil</span>
              <span className="text-indigo-600 font-bold">{calculateProfileCompletion()}%</span>
            </div>
            <Progress value={calculateProfileCompletion()} className="h-2 bg-gray-100" indicatorClassName="bg-indigo-600" />
            <p className="text-sm text-gray-500 mt-2">
              {calculateProfileCompletion() < 100 
                ? "Completa tu información para agilizar pagos y asignaciones." 
                : "¡Tu perfil está completo y listo!"}
            </p>
          </div>
          <Link to={createPageUrl("InvitadoProfile")}>
            <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50">
              {calculateProfileCompletion() < 100 ? "Completar Perfil" : "Editar Perfil"}
            </Button>
          </Link>
        </CardContent>
      </Card>

      {/* Quick Stats & Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white shadow-sm border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-gray-500">Facturas Pendientes</h3>
              <AlertCircle className={`w-5 h-5 ${pendingInvoices.length > 0 ? "text-amber-500" : "text-gray-300"}`} />
            </div>
            <div className="text-2xl font-bold text-gray-900">{pendingInvoices.length}</div>
            <p className="text-xs text-gray-500 mt-1">
              {pendingInvoices.length > 0 ? "Pagos en proceso" : "Todo al día"}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-gray-500">Entregas Activas</h3>
              <Briefcase className="w-5 h-5 text-blue-500" />
            </div>
            <div className="text-2xl font-bold text-gray-900">
              {submissions.filter(s => s.status === 'reviewing').length}
            </div>
            <p className="text-xs text-gray-500 mt-1">En revisión por el equipo</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-gray-500">Ingresos (Año)</h3>
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <div className="text-2xl font-bold text-gray-900">{totalEarned}€</div>
            <p className="text-xs text-gray-500 mt-1">Total facturado y pagado</p>
          </CardContent>
        </Card>
      </div>

      {/* Actions & Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 bg-white shadow-sm border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Resumen de Ingresos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F3F4F6" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#9CA3AF', fontSize: 12}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#9CA3AF', fontSize: 12}} />
                  <Tooltip 
                    cursor={{fill: '#F9FAFB'}}
                    contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                  />
                  <Bar dataKey="amount" fill="#4F46E5" radius={[4, 4, 0, 0]} barSize={30} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Accesos Rápidos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link to={createPageUrl("InvitadoWork")}>
              <Button className="w-full justify-start h-12 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 shadow-sm">
                <Upload className="w-5 h-5 mr-3 text-indigo-600" />
                Subir Nueva Entrega
              </Button>
            </Link>
            <Link to={createPageUrl("InvitadoInvoices")}>
              <Button className="w-full justify-start h-12 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 shadow-sm">
                <DollarSign className="w-5 h-5 mr-3 text-green-600" />
                Subir Factura
              </Button>
            </Link>
            <Link to={createPageUrl("InvitadoProfile")}>
              <Button className="w-full justify-start h-12 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 shadow-sm">
                <UserCheck className="w-5 h-5 mr-3 text-blue-600" />
                Actualizar Datos Fiscales
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Camera, Save, Mail, User as UserIcon, Calendar, Shield, Briefcase, Grid2x2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";
import { es } from 'date-fns/locale';

export default function Profile() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const { toast } = useToast();

  const [profileData, setProfileData] = useState({
    full_name: "",
    avatar_url: "",
    bio: "",
    phone: "",
    location: "",
    job_title: "",
    department: "",
  });

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    setIsLoading(true);
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      setProfileData({
        full_name: userData.full_name || "",
        avatar_url: userData.avatar_url || "",
        bio: userData.bio || "",
        phone: userData.phone || "",
        location: userData.location || "",
        job_title: userData.job_title || "",
        department: userData.department || "",
      });
    } catch (error) {
      console.error("Error al cargar datos del usuario:", error);
      toast({
        title: "Error",
        description: "No se pudieron cargar tus datos",
        variant: "destructive",
      });
    }
    setIsLoading(false);
  };

  const handleSaveProfile = async () => {
    setIsSaving(true);
    try {
      // Detectar cambios
      const changes = [];
      if (profileData.full_name !== user.full_name) changes.push(`nombre a "${profileData.full_name}"`);
      if (profileData.job_title !== user.job_title) changes.push(`cargo a "${profileData.job_title}"`);
      if (profileData.department !== user.department) changes.push(`departamento a "${profileData.department}"`);
      if (profileData.phone !== user.phone) changes.push(`teléfono`);
      if (profileData.location !== user.location) changes.push(`ubicación`);
      if (profileData.bio !== user.bio) changes.push(`biografía`);

      await base44.auth.updateMe(profileData);

      // Registrar en auditoría si hubo cambios
      if (changes.length > 0) {
        try {
          await base44.entities.UserAuditLog.create({
            user_email: user.email,
            user_id: user.id,
            user_name: user.full_name || user.email,
            action_type: "profile_update",
            action_description: `Actualizó su perfil: ${changes.join(', ')}`,
            target_type: "user",
            target_id: user.id,
            target_name: user.full_name || user.email,
          });
        } catch (auditError) {
          console.error("Error al registrar auditoría:", auditError);
        }
      }

      toast({
        title: "✓ Perfil actualizado",
        description: "Tus cambios han sido guardados exitosamente",
      });
      
      await loadUserData();
    } catch (error) {
      console.error("Error al guardar perfil:", error);
      toast({
        title: "Error",
        description: "No se pudo guardar tu perfil",
        variant: "destructive",
      });
    }
    setIsSaving(false);
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validar tamaño (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Archivo muy grande",
        description: "La imagen debe ser menor a 5MB",
        variant: "destructive",
      });
      return;
    }

    setIsUploadingPhoto(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      await base44.auth.updateMe({
        avatar_url: file_url
      });

      toast({
        title: "✓ Foto actualizada",
        description: "Tu foto de perfil se ha actualizado correctamente",
      });
      
      // Recargar la página para actualizar el avatar en todos lados
      window.location.reload();
    } catch (error) {
      console.error("Error al subir foto:", error);
      toast({
        title: "Error",
        description: "No se pudo subir la foto",
        variant: "destructive",
      });
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  const getUserInitials = () => {
    if (!profileData.full_name) return "U";
    const names = profileData.full_name.split(" ");
    if (names.length >= 2) {
      return `${names[0][0]}${names[1][0]}`.toUpperCase();
    }
    return names[0][0].toUpperCase();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F6F8]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0073EA] mx-auto mb-4"></div>
          <p className="text-[#676879]">Cargando perfil...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F6F8] p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header con foto de perfil */}
        <Card className="mb-6 overflow-hidden">
          <div className="h-32 bg-gradient-to-r from-[#0073EA] to-[#0056B3] flex items-center justify-center">
            <div className="flex items-center gap-3">
              <Grid2x2 className="w-8 h-8 text-white" />
              <h2 className="text-2xl font-bold text-white">E&D Company</h2>
            </div>
          </div>
          <CardContent className="relative pt-0 pb-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4 -mt-16">
              {/* Avatar */}
              <div className="relative">
                {profileData.avatar_url ? (
                  <img
                    src={profileData.avatar_url}
                    alt="Avatar"
                    className="w-32 h-32 rounded-full border-4 border-white shadow-xl object-cover"
                  />
                ) : (
                  <div className="w-32 h-32 rounded-full border-4 border-white shadow-xl bg-gradient-to-r from-[#0073EA] to-[#00C875] flex items-center justify-center">
                    <span className="text-white text-4xl font-bold">{getUserInitials()}</span>
                  </div>
                )}
                
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                  id="avatar-upload"
                  disabled={isUploadingPhoto}
                />
                <label
                  htmlFor="avatar-upload"
                  className="absolute bottom-0 right-0 bg-white rounded-full p-2 shadow-lg cursor-pointer hover:bg-gray-50 transition-colors"
                >
                  {isUploadingPhoto ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-[#0073EA]"></div>
                  ) : (
                    <Camera className="w-5 h-5 text-[#0073EA]" />
                  )}
                </label>
              </div>

              {/* Nombre y rol */}
              <div className="flex-1 sm:ml-4 mt-4 sm:mb-4">
                <h1 className="text-2xl sm:text-3xl font-bold text-[#323338]">
                  {profileData.full_name || "Sin nombre"}
                </h1>
                <p className="text-[#676879] mt-1">{profileData.job_title || "Sin cargo"}</p>
                <div className="flex gap-2 mt-2 flex-wrap">
                  <Badge variant={user?.role === "admin" ? "default" : "secondary"}>
                    {user?.role === "admin" ? "Administrador" : "Usuario"}
                  </Badge>
                  {profileData.department && (
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Briefcase className="w-3 h-3" />
                      {profileData.department}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Información del perfil */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserIcon className="w-5 h-5" />
              Información Personal
            </CardTitle>
            <CardDescription>
              Actualiza tu información personal y cómo otros te ven en el equipo
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="full_name">Nombre Completo</Label>
                <Input
                  id="full_name"
                  value={profileData.full_name}
                  onChange={(e) =>
                    setProfileData({ ...profileData, full_name: e.target.value })
                  }
                  placeholder="Tu nombre completo"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="job_title">Cargo</Label>
                <Input
                  id="job_title"
                  value={profileData.job_title}
                  onChange={(e) =>
                    setProfileData({ ...profileData, job_title: e.target.value })
                  }
                  placeholder="Ej: Gerente de Proyectos"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="department">Departamento</Label>
                <Select
                  value={profileData.department}
                  onValueChange={(value) =>
                    setProfileData({ ...profileData, department: value })
                  }
                >
                  <SelectTrigger id="department">
                    <SelectValue placeholder="Selecciona tu departamento" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="IA">IA</SelectItem>
                    <SelectItem value="Marketing">Marketing</SelectItem>
                    <SelectItem value="Relaciones Internacionales">Relaciones Internacionales</SelectItem>
                    <SelectItem value="Dirección">Dirección</SelectItem>
                    <SelectItem value="Diseñador">Diseñador</SelectItem>
                    <SelectItem value="Operaciones">Operaciones</SelectItem>
                    <SelectItem value="Finanzas">Finanzas</SelectItem>
                    <SelectItem value="Recursos Humanos">Recursos Humanos</SelectItem>
                    <SelectItem value="Tecnología">Tecnología</SelectItem>
                    <SelectItem value="Ventas">Ventas</SelectItem>
                    <SelectItem value="Otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Teléfono</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={profileData.phone}
                  onChange={(e) =>
                    setProfileData({ ...profileData, phone: e.target.value })
                  }
                  placeholder="+34 600 000 000"
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="location">Ubicación</Label>
                <Input
                  id="location"
                  value={profileData.location}
                  onChange={(e) =>
                    setProfileData({ ...profileData, location: e.target.value })
                  }
                  placeholder="Ciudad, País"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="bio">Biografía</Label>
              <textarea
                id="bio"
                value={profileData.bio}
                onChange={(e) =>
                  setProfileData({ ...profileData, bio: e.target.value })
                }
                placeholder="Cuéntanos un poco sobre ti..."
                className="w-full min-h-24 px-3 py-2 text-sm rounded-md border border-input bg-background ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                maxLength={500}
              />
              <p className="text-xs text-gray-500 text-right">
                {profileData.bio?.length || 0}/500 caracteres
              </p>
            </div>

            <div className="pt-4 flex justify-end">
              <Button 
                onClick={handleSaveProfile} 
                disabled={isSaving} 
                className="bg-[#0073EA] hover:bg-[#0056B3]"
              >
                {isSaving ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Guardando...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Guardar Cambios
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Información de la cuenta */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Información de la Cuenta
            </CardTitle>
            <CardDescription>
              Datos sobre tu cuenta y acceso a la plataforma
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
              <Mail className="w-5 h-5 text-[#0073EA] mt-0.5" />
              <div className="flex-1">
                <Label className="text-sm font-medium">Email</Label>
                <p className="text-sm text-[#676879] mt-1">{user?.email}</p>
                <p className="text-xs text-gray-500 mt-1">
                  Tu email no puede ser modificado desde aquí
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
              <Calendar className="w-5 h-5 text-[#0073EA] mt-0.5" />
              <div className="flex-1">
                <Label className="text-sm font-medium">Miembro desde</Label>
                <p className="text-sm text-[#676879] mt-1">
                  {user?.created_date ? format(new Date(user.created_date), "d 'de' MMMM 'de' yyyy", { locale: es }) : "Fecha desconocida"}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
              <Shield className="w-5 h-5 text-[#0073EA] mt-0.5" />
              <div className="flex-1">
                <Label className="text-sm font-medium">Rol</Label>
                <p className="text-sm text-[#676879] mt-1">
                  {user?.role === "admin" ? "Administrador - Acceso completo al sistema" : "Usuario - Acceso estándar"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
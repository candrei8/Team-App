import { base44 } from './base44Client';


export const calendarAuth = base44.functions.calendarAuth;

export const calendarSync = base44.functions.calendarSync;

export const whiteboardWs = base44.functions.whiteboardWs;


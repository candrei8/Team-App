import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, FolderPlus } from "lucide-react";

export default function NewTaskModal({ isOpen, onClose, board, onSubmit }) {
  const [taskData, setTaskData] = useState({
    title: '',
    groupId: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showNewGroupInput, setShowNewGroupInput] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');

  useEffect(() => {
    if (isOpen && board?.groups?.length > 0) {
      setTaskData({
        title: '',
        groupId: board.groups[0].id
      });
    }
  }, [isOpen, board]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!taskData.title.trim() || !taskData.groupId) return;

    setIsSubmitting(true);
    try {
      await onSubmit(taskData.groupId, taskData.title);
      setTaskData({ title: '', groupId: board?.groups?.[0]?.id || '' });
      onClose();
    } catch (error) {
      console.error('Error al crear tarea:', error);
    }
    setIsSubmitting(false);
  };

  const handleCreateNewGroup = () => {
    if (!newGroupName.trim()) return;
    
    // Aquí necesitarías una función para crear el grupo
    // Por ahora solo cerraremos el input
    setShowNewGroupInput(false);
    setNewGroupName('');
  };

  const availableGroups = board?.groups || [];
  const hasGroups = availableGroups.length > 0;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-[#323338]">
            Crear Nueva Tarea
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-[#323338] font-medium">
              Título de la Tarea *
            </Label>
            <Input
              id="title"
              value={taskData.title}
              onChange={(e) => setTaskData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Ingresa el título de la tarea..."
              className="rounded-xl border-[#E1E5F3] h-12 focus:ring-2 focus:ring-[#0073EA]/20"
              required
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-[#323338] font-medium">Grupo *</Label>
              {hasGroups && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-7 text-xs text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                  onClick={() => setShowNewGroupInput(!showNewGroupInput)}
                >
                  <Plus className="w-3 h-3 mr-1" />
                  Nuevo grupo
                </Button>
              )}
            </div>

            {showNewGroupInput && (
              <div className="flex gap-2 mb-2">
                <Input
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="Nombre del nuevo grupo..."
                  className="flex-1 h-9 text-sm"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleCreateNewGroup();
                    }
                    if (e.key === 'Escape') {
                      setShowNewGroupInput(false);
                      setNewGroupName('');
                    }
                  }}
                />
                <Button
                  type="button"
                  size="sm"
                  className="h-9"
                  onClick={handleCreateNewGroup}
                >
                  Crear
                </Button>
              </div>
            )}

            {hasGroups ? (
              <Select
                value={taskData.groupId}
                onValueChange={(value) => setTaskData(prev => ({ ...prev, groupId: value }))}
              >
                <SelectTrigger className="rounded-xl border-[#E1E5F3] h-12">
                  <SelectValue placeholder="Seleccionar grupo" />
                </SelectTrigger>
                <SelectContent>
                  {availableGroups.map((group) => (
                    <SelectItem key={group.id} value={group.id}>
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: group.color || '#0073EA' }}
                        />
                        <span>{group.title || 'Sin título'}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <div className="text-center py-8 px-4 bg-gray-50 rounded-xl border-2 border-dashed border-gray-200">
                <FolderPlus className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p className="text-sm text-gray-600 mb-4">
                  No hay grupos disponibles. Crea uno desde la vista de tabla.
                </p>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="rounded-xl h-12 px-6"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={!taskData.title.trim() || !taskData.groupId || isSubmitting || !hasGroups}
              className="bg-[#0073EA] hover:bg-[#0056B3] text-white rounded-xl h-12 px-6 font-medium disabled:opacity-50"
            >
              {isSubmitting ? 'Creando...' : 'Crear Tarea'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
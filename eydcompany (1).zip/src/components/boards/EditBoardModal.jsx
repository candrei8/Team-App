import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { Lock, Globe, Users, X, UserPlus, Building2 } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

const colorOptions = [
  { name: 'Azul Océano', value: '#0073EA' },
  { name: 'Verde Éxito', value: '#00C875' },
  { name: 'Naranja Advertencia', value: '#FFCB00' },
  { name: 'Rojo Peligro', value: '#E2445C' },
  { name: 'Púrpura', value: '#A25DDC' },
  { name: 'Verde Azulado', value: '#00D9FF' }
];

export default function EditBoardModal({ isOpen, onClose, onSubmit, board }) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    color: '#0073EA',
    visibility: 'private',
    participants: [],
    allowed_departments: []
  });

  const departments = [
    "IA", "Marketing", "Relaciones Internacionales", "Dirección",
    "Diseñador", "Operaciones", "Finanzas", "Recursos Humanos",
    "Tecnología", "Ventas", "Otro"
  ];
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [users, setUsers] = useState([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (board) {
      setFormData({
        title: board.title || '',
        description: board.description || '',
        color: board.color || '#0073EA',
        visibility: board.visibility || 'private',
        participants: board.participants || [],
        allowed_departments: board.allowed_departments || []
      });
    }
  }, [board]);

  const toggleDepartment = (dept) => {
    setFormData(prev => ({
      ...prev,
      allowed_departments: prev.allowed_departments.includes(dept)
        ? prev.allowed_departments.filter(d => d !== dept)
        : [...prev.allowed_departments, dept]
    }));
  };

  useEffect(() => {
    if (isOpen) {
      loadUsers();
    }
  }, [isOpen]);

  const loadUsers = async () => {
    setIsLoadingUsers(true);
    try {
      const allUsers = await base44.entities.User.filter({ status: 'active' });
      setUsers(allUsers.filter(u => u.email !== board?.created_by));
    } catch (error) {
      console.error("Error al cargar usuarios:", error);
    }
    setIsLoadingUsers(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim() || !board) return;

    setIsSubmitting(true);
    try {
      await onSubmit(board.id, formData);
      onClose();
    } catch (error) {
      console.error('Error al actualizar el proyecto:', error);
    }
    setIsSubmitting(false);
  };

  const addParticipant = (userEmail) => {
    if (!formData.participants.includes(userEmail)) {
      setFormData(prev => ({
        ...prev,
        participants: [...prev.participants, userEmail]
      }));
    }
    setOpen(false);
  };

  const removeParticipant = (userEmail) => {
    setFormData(prev => ({
      ...prev,
      participants: prev.participants.filter(email => email !== userEmail)
    }));
  };

  const getParticipantInfo = (email) => {
    const user = users.find(u => u.email === email);
    return user ? user.full_name || user.email : email;
  };

  const getUserInitials = (name) => {
    if (!name) return "?";
    const names = name.split(" ");
    if (names.length >= 2) {
      return `${names[0][0]}${names[1][0]}`.toUpperCase();
    }
    return names[0][0].toUpperCase();
  };

  const availableUsers = users.filter(user => 
    !formData.participants.includes(user.email)
  );

  if (!board) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-[#323338]">
            Editar Proyecto: {board.title}
          </DialogTitle>
          <DialogDescription>
            Actualiza los detalles de tu proyecto.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-[#323338] font-medium">
              Título del Proyecto *
            </Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Ingresa el título del proyecto..."
              className="rounded-xl border-[#E1E5F3] h-12 focus:ring-2 focus:ring-[#0073EA]/20"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-[#323338] font-medium">
              Descripción
            </Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="¿De qué trata este proyecto?"
              className="rounded-xl border-[#E1E5F3] min-h-20 focus:ring-2 focus:ring-[#0073EA]/20"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-[#323338] font-medium">Color del Proyecto</Label>
            <div className="flex gap-2 flex-wrap">
              {colorOptions.map((color) => (
                <button
                  key={color.value}
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, color: color.value }))}
                  className={`w-8 h-8 rounded-lg border-2 transition-all ${
                    formData.color === color.value 
                      ? 'border-[#323338] scale-110' 
                      : 'border-transparent hover:scale-105'
                  }`}
                  style={{ backgroundColor: color.value }}
                  title={color.name}
                />
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-[#323338] font-medium">Visibilidad</Label>
            <Select
              value={formData.visibility}
              onValueChange={(value) => setFormData(prev => ({ ...prev, visibility: value }))}
            >
              <SelectTrigger className="rounded-xl border-[#E1E5F3] h-12">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="private">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    <span>Privado</span>
                  </div>
                </SelectItem>
                <SelectItem value="shared">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    <span>Compartido</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Participantes Section */}
          <div className="space-y-3">
            <Label className="text-[#323338] font-medium flex items-center gap-2">
              <Users className="w-4 h-4" />
              Participantes del Proyecto
            </Label>
            
            {/* Lista de participantes actuales */}
            {formData.participants.length > 0 && (
              <div className="flex flex-wrap gap-2 p-3 bg-gray-50 rounded-lg">
                {formData.participants.map((email) => {
                  const user = users.find(u => u.email === email);
                  return (
                    <Badge 
                      key={email} 
                      variant="secondary"
                      className="flex items-center gap-2 pr-1 pl-2 py-1"
                    >
                      <div className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-xs font-semibold">
                        {getUserInitials(user?.full_name || email)}
                      </div>
                      <span className="text-sm">{getParticipantInfo(email)}</span>
                      <button
                        type="button"
                        onClick={() => removeParticipant(email)}
                        className="hover:bg-gray-300 rounded-full p-0.5 transition-colors"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  );
                })}
              </div>
            )}

            {/* Botón para agregar participantes */}
            <Popover open={open} onOpenChange={setOpen}>
              <PopoverTrigger asChild>
                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full justify-start h-12 rounded-xl border-dashed"
                  disabled={isLoadingUsers || availableUsers.length === 0}
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  {isLoadingUsers 
                    ? "Cargando usuarios..." 
                    : availableUsers.length === 0 
                      ? "No hay más usuarios disponibles"
                      : "Agregar participante"
                  }
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[300px] p-0" align="start">
                <Command>
                  <CommandInput placeholder="Buscar usuario..." />
                  <CommandEmpty>No se encontraron usuarios.</CommandEmpty>
                  <CommandGroup className="max-h-64 overflow-y-auto">
                    {availableUsers.map((user) => (
                      <CommandItem
                        key={user.id}
                        onSelect={() => addParticipant(user.email)}
                        className="flex items-center gap-3 cursor-pointer"
                      >
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-xs font-semibold">
                          {getUserInitials(user.full_name)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">
                            {user.full_name || 'Sin nombre'}
                          </p>
                          <p className="text-xs text-gray-500 truncate">
                            {user.email}
                          </p>
                        </div>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </Command>
              </PopoverContent>
            </Popover>

            {formData.participants.length === 0 && (
              <p className="text-xs text-gray-500 text-center py-2">
                No hay participantes agregados. Haz clic en "Agregar participante" para incluir miembros del equipo.
              </p>
            )}
          </div>

          {/* Departamentos con acceso (solo para proyectos privados) */}
          {formData.visibility === "private" && (
            <div className="space-y-3">
              <Label className="text-[#323338] font-medium flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                Departamentos con Acceso
              </Label>
              
              <div className="grid grid-cols-2 gap-3 p-3 bg-gray-50 rounded-lg border">
                {departments.map((dept) => (
                  <div key={dept} className="flex items-center space-x-2">
                    <Checkbox
                      id={`dept-edit-${dept}`}
                      checked={formData.allowed_departments.includes(dept)}
                      onCheckedChange={() => toggleDepartment(dept)}
                    />
                    <Label
                      htmlFor={`dept-edit-${dept}`}
                      className="text-sm font-normal cursor-pointer"
                    >
                      {dept}
                    </Label>
                  </div>
                ))}
              </div>

              {formData.allowed_departments.length === 0 && (
                <p className="text-xs text-gray-500 text-center py-2">
                  No hay departamentos seleccionados. Todos los usuarios de un departamento marcado podrán ver este proyecto.
                </p>
              )}
            </div>
          )}

          <DialogFooter className="pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="rounded-xl h-12 px-6"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={!formData.title.trim() || isSubmitting}
              className="bg-[#0073EA] hover:bg-[#0056B3] text-white rounded-xl h-12 px-6 font-medium"
            >
              {isSubmitting ? 'Guardando...' : 'Guardar Cambios'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
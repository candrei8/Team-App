import { base44 } from '@/api/base44Client';

/**
 * Servicio para enviar notificaciones push locales
 * Cuando el usuario está en la app o tiene la PWA instalada
 */
class NotificationService {
  constructor() {
    this.permission = 'default';
    this.checkPermission();
  }

  checkPermission() {
    if ('Notification' in window) {
      this.permission = Notification.permission;
    }
  }

  /**
   * Verificar si se pueden enviar notificaciones
   */
  canSendNotifications() {
    return 'Notification' in window && this.permission === 'granted';
  }

  /**
   * Enviar una notificación local del navegador
   */
  async sendBrowserNotification({ title, body, icon, tag, data, onClick }) {
    if (!this.canSendNotifications()) {
      console.log('Notificaciones no disponibles o no permitidas');
      return null;
    }

    try {
      const notification = new Notification(title, {
        body,
        icon: icon || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691331048c912041d25cea34/d90f3652c_E-DLOGOAZUL-640w.png',
        badge: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691331048c912041d25cea34/d90f3652c_E-DLOGOAZUL-640w.png',
        tag: tag || `notification-${Date.now()}`,
        requireInteraction: false,
        data: data || {}
      });

      if (onClick) {
        notification.onclick = onClick;
      }

      return notification;
    } catch (error) {
      console.error('Error al enviar notificación:', error);
      return null;
    }
  }

  /**
   * Notificar cuando un usuario es activado
   */
  async notifyUserActivated(userEmail, userName) {
    return this.sendBrowserNotification({
      title: '✅ Cuenta Activada',
      body: `${userName} ha sido activado y puede acceder a la aplicación`,
      tag: 'user-activated'
    });
  }

  /**
   * Notificar cuando un usuario es suspendido
   */
  async notifyUserSuspended(userEmail, userName) {
    return this.sendBrowserNotification({
      title: '🚫 Usuario Suspendido',
      body: `${userName} ha sido suspendido`,
      tag: 'user-suspended'
    });
  }

  /**
   * Notificar nuevo usuario pendiente (solo para admins)
   */
  async notifyNewUserPending(userName, userEmail) {
    return this.sendBrowserNotification({
      title: '👤 Nuevo Usuario Pendiente',
      body: `${userName} (${userEmail}) requiere tu aprobación`,
      tag: 'user-pending',
      requireInteraction: true
    });
  }

  /**
   * Notificar tarea asignada
   */
  async notifyTaskAssigned(taskTitle, boardName) {
    return this.sendBrowserNotification({
      title: '📋 Nueva Tarea Asignada',
      body: `"${taskTitle}" en ${boardName}`,
      tag: 'task-assigned'
    });
  }

  /**
   * Notificar cambio de estado de tarea
   */
  async notifyTaskStatusChanged(taskTitle, newStatus) {
    return this.sendBrowserNotification({
      title: '🔄 Estado de Tarea Actualizado',
      body: `"${taskTitle}" → ${newStatus}`,
      tag: 'task-status-change'
    });
  }

  /**
   * Notificar mención en comentario
   */
  async notifyMentioned(mentionerName, context) {
    return this.sendBrowserNotification({
      title: '💬 Te han mencionado',
      body: `${mentionerName} te mencionó en ${context}`,
      tag: 'mention',
      requireInteraction: true
    });
  }

  /**
   * Notificar fecha límite próxima
   */
  async notifyDeadlineApproaching(taskTitle, daysLeft) {
    return this.sendBrowserNotification({
      title: '⏰ Fecha Límite Próxima',
      body: `"${taskTitle}" vence en ${daysLeft} día${daysLeft !== 1 ? 's' : ''}`,
      tag: 'deadline-approaching',
      requireInteraction: true
    });
  }

  /**
   * Notificar comentario nuevo
   */
  async notifyNewComment(commenterName, itemTitle) {
    return this.sendBrowserNotification({
      title: '💬 Nuevo Comentario',
      body: `${commenterName} comentó en "${itemTitle}"`,
      tag: 'new-comment'
    });
  }

  /**
   * Verificar si el usuario tiene suscripción activa
   */
  async hasActiveSubscription(userEmail) {
    try {
      const subscriptions = await base44.entities.PushSubscription.filter({
        user_email: userEmail,
        is_active: true
      });
      return subscriptions.length > 0;
    } catch (error) {
      console.error('Error al verificar suscripción:', error);
      return false;
    }
  }

  /**
   * Guardar notificación en la base de datos y enviar push si está disponible
   */
  async notifyUser({ userEmail, title, message, type, priority, linkUrl, metadata }) {
    try {
      // Crear notificación en la base de datos (aparecerá en el panel)
      await base44.entities.Notification.create({
        user_email: userEmail,
        title,
        message,
        type: type || 'system',
        priority: priority || 'medium',
        is_read: false,
        link_url: linkUrl,
        metadata: metadata || {}
      });

      // Si el usuario tiene notificaciones push activadas, enviar también
      const hasSubscription = await this.hasActiveSubscription(userEmail);
      
      if (hasSubscription) {
        await this.sendBrowserNotification({
          title,
          body: message,
          tag: `notification-${Date.now()}`,
          data: { type, linkUrl, metadata }
        });
      }

      return true;
    } catch (error) {
      console.error('Error al notificar usuario:', error);
      return false;
    }
  }
}

// Exportar una instancia singleton
export const notificationService = new NotificationService();
export default notificationService;
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { CheckCircle } from "lucide-react";

export default function CreateTodoModal({ isOpen, onClose, onSubmit }) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    due_date: "",
    priority: "medium",
    category: "",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
    setFormData({
      title: "",
      description: "",
      due_date: "",
      priority: "medium",
      category: "",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#0D1117] border-blue-900/30 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-blue-100">Nueva Tarea</DialogTitle>
          <DialogDescription className="text-blue-400">
            Añade una nueva tarea a tu lista
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-blue-200">Título *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="bg-[#0A0E1A] border-blue-900/40 text-white focus:border-blue-600"
              placeholder="Completar informe..."
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-blue-200">Descripción</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="bg-[#0A0E1A] border-blue-900/40 text-white min-h-[80px] focus:border-blue-600"
              placeholder="Detalles de la tarea..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="due_date" className="text-blue-200">Fecha Vencimiento</Label>
              <Input
                id="due_date"
                type="datetime-local"
                value={formData.due_date}
                onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                className="bg-[#0A0E1A] border-blue-900/40 text-white focus:border-blue-600"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority" className="text-blue-200">Prioridad</Label>
              <Select
                value={formData.priority}
                onValueChange={(value) => setFormData({ ...formData, priority: value })}
              >
                <SelectTrigger className="bg-[#0A0E1A] border-blue-900/40 text-white focus:border-blue-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#0D1117] border-blue-800/50">
                  <SelectItem value="low">Baja</SelectItem>
                  <SelectItem value="medium">Media</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                  <SelectItem value="urgent">Urgente</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category" className="text-blue-200">Categoría</Label>
            <Input
              id="category"
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              className="bg-[#0A0E1A] border-blue-900/40 text-white focus:border-blue-600"
              placeholder="Personal, Trabajo..."
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} className="border-blue-800/50 text-blue-300 hover:bg-blue-900/30">
              Cancelar
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-[#0073EA] to-[#0056B3] hover:from-[#0056B3] hover:to-[#004494] text-white">
              <CheckCircle className="w-4 h-4 mr-2" />
              Crear Tarea
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
import React, { useState, useRef, useEffect } from 'react';

export default function WhiteboardElement({ element, isSelected, onSelect, onUpdate, zoom }) {
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [resizeHandle, setResizeHandle] = useState(null);
  const [dragStart, setDragStart] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const textAreaRef = useRef(null);

  // Validar que element tenga todas las propiedades necesarias
  if (!element || !element.position || !element.size || !element.properties) {
    console.error('Elemento inválido:', element);
    return null;
  }

  const handleMouseDown = (e) => {
    e.stopPropagation();
    
    const multi = e.shiftKey;
    onSelect(element.id, multi);

    if (element.locked) return;

    setIsDragging(true);
    setDragStart({
      x: e.clientX,
      y: e.clientY,
      elementX: element.position.x,
      elementY: element.position.y
    });
  };

  const handleMouseMove = (e) => {
    if (!isDragging || !dragStart || element.locked) return;

    const dx = (e.clientX - dragStart.x) / zoom;
    const dy = (e.clientY - dragStart.y) / zoom;

    onUpdate(element.id, {
      position: {
        x: dragStart.elementX + dx,
        y: dragStart.elementY + dy
      }
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setDragStart(null);
    setIsResizing(false);
    setResizeHandle(null);
  };

  useEffect(() => {
    if (isDragging || isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, isResizing, dragStart]);

  useEffect(() => {
    if (isEditing && textAreaRef.current) {
      textAreaRef.current.focus();
      textAreaRef.current.select();
    }
  }, [isEditing]);

  const handleDoubleClick = (e) => {
    e.stopPropagation();
    if (element.type === 'sticky_note' || element.type === 'text' || element.type === 'shape') {
      setIsEditing(true);
    }
  };

  const handleTextChange = (e) => {
    const newText = e.target.value;
    if (newText.length <= 1000) {
      onUpdate(element.id, {
        properties: {
          ...element.properties,
          text: newText
        }
      });
    }
  };

  const handleTextBlur = () => {
    setIsEditing(false);
  };

  const handleTextKeyDown = (e) => {
    if (e.key === 'Escape') {
      setIsEditing(false);
      e.preventDefault();
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      setIsEditing(false);
      e.preventDefault();
    }
    e.stopPropagation();
  };

  const renderElement = () => {
    const { type, position, size, properties } = element;

    // Validaciones adicionales de seguridad
    const safeSize = size || { width: 100, height: 100 };
    const safePosition = position || { x: 0, y: 0 };
    const safeProperties = properties || {};

    switch (type) {
      case 'sticky_note':
        return (
          <g transform={`translate(${safePosition.x}, ${safePosition.y})`}>
            <rect
              width={safeSize.width}
              height={safeSize.height}
              fill={safeProperties.color || '#FFEB3B'}
              stroke={isSelected ? '#0073EA' : 'rgba(0,0,0,0.1)'}
              strokeWidth={isSelected ? 3 / zoom : 1 / zoom}
              rx="8"
              filter="drop-shadow(0 2px 4px rgba(0,0,0,0.1))"
              style={{ cursor: element.locked ? 'default' : 'move' }}
              onMouseDown={handleMouseDown}
              onDoubleClick={handleDoubleClick}
            />
            
            <line
              x1="0"
              y1="30"
              x2={safeSize.width}
              y2="30"
              stroke="rgba(0,0,0,0.1)"
              strokeWidth={1 / zoom}
            />
            
            {!isEditing ? (
              <foreignObject width={safeSize.width} height={safeSize.height - 30} y="30">
                <div 
                  className="w-full h-full p-3 text-gray-800 overflow-auto whitespace-pre-wrap break-words"
                  style={{ 
                    fontSize: safeProperties.fontSize || 14,
                    pointerEvents: 'none',
                    fontFamily: "'Segoe UI', 'Inter', 'Helvetica Neue', Arial, sans-serif",
                    lineHeight: '1.5',
                    letterSpacing: '0.01em'
                  }}
                >
                  {safeProperties.text || ''}
                </div>
              </foreignObject>
            ) : (
              <foreignObject width={safeSize.width} height={safeSize.height - 30} y="30">
                <textarea
                  ref={textAreaRef}
                  className="w-full h-full p-3 bg-transparent border-none outline-none resize-none text-gray-800 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-transparent hover:scrollbar-thumb-gray-400"
                  style={{ 
                    fontSize: safeProperties.fontSize || 14,
                    fontFamily: "'Segoe UI', 'Inter', 'Helvetica Neue', Arial, sans-serif",
                    lineHeight: '1.5',
                    letterSpacing: '0.01em',
                    wordWrap: 'break-word',
                    overflowWrap: 'break-word'
                  }}
                  value={safeProperties.text || ''}
                  onChange={handleTextChange}
                  onBlur={handleTextBlur}
                  onKeyDown={handleTextKeyDown}
                  placeholder="Escribe aquí... (Presiona Esc o Ctrl+Enter para guardar)"
                  maxLength={1000}
                  autoFocus
                />
              </foreignObject>
            )}

            {!isEditing && !safeProperties.text && (
              <foreignObject width={safeSize.width} height={safeSize.height - 30} y="30">
                <div 
                  className="w-full h-full flex flex-col items-center justify-center text-gray-400 italic gap-1"
                  style={{ 
                    fontSize: 12,
                    pointerEvents: 'none'
                  }}
                >
                  <span>✍️ Doble click para escribir</span>
                  <span className="text-xs text-gray-300">Texto fluido y multilinea</span>
                </div>
              </foreignObject>
            )}

            {isEditing && (
              <foreignObject width={safeSize.width} height={20} y={safeSize.height - 20}>
                <div 
                  className="w-full h-full flex justify-end items-center pr-2 text-xs"
                  style={{ 
                    color: (safeProperties.text?.length || 0) > 900 ? '#E2445C' : '#9CA3AF',
                    pointerEvents: 'none'
                  }}
                >
                  {safeProperties.text?.length || 0}/1000
                </div>
              </foreignObject>
            )}

            {isSelected && !element.locked && (
              <>
                {[
                  { x: 0, y: 0, cursor: 'nwse-resize' },
                  { x: safeSize.width, y: 0, cursor: 'nesw-resize' },
                  { x: 0, y: safeSize.height, cursor: 'nesw-resize' },
                  { x: safeSize.width, y: safeSize.height, cursor: 'nwse-resize' }
                ].map((handle, i) => (
                  <circle
                    key={i}
                    cx={handle.x}
                    cy={handle.y}
                    r={4 / zoom}
                    fill="white"
                    stroke="#0073EA"
                    strokeWidth={2 / zoom}
                    style={{ cursor: handle.cursor }}
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      setIsResizing(true);
                      setResizeHandle(i);
                      setDragStart({
                        x: e.clientX,
                        y: e.clientY,
                        width: safeSize.width,
                        height: safeSize.height,
                        posX: safePosition.x,
                        posY: safePosition.y
                      });
                    }}
                  />
                ))}
              </>
            )}
          </g>
        );

      case 'shape':
        const { shape, fill, stroke, strokeWidth, text } = safeProperties;
        return (
          <g transform={`translate(${safePosition.x}, ${safePosition.y})`}>
            {shape === 'rectangle' && (
              <rect
                width={safeSize.width}
                height={safeSize.height}
                fill={fill || '#ffffff'}
                stroke={isSelected ? '#0073EA' : (stroke || '#000000')}
                strokeWidth={isSelected ? 3 / zoom : (strokeWidth || 2)}
                rx="4"
                style={{ cursor: element.locked ? 'default' : 'move' }}
                onMouseDown={handleMouseDown}
                onDoubleClick={handleDoubleClick}
              />
            )}
            {shape === 'circle' && (
              <ellipse
                cx={safeSize.width / 2}
                cy={safeSize.height / 2}
                rx={safeSize.width / 2}
                ry={safeSize.height / 2}
                fill={fill || '#ffffff'}
                stroke={isSelected ? '#0073EA' : (stroke || '#000000')}
                strokeWidth={isSelected ? 3 / zoom : (strokeWidth || 2)}
                style={{ cursor: element.locked ? 'default' : 'move' }}
                onMouseDown={handleMouseDown}
                onDoubleClick={handleDoubleClick}
              />
            )}
            {shape === 'triangle' && (
              <polygon
                points={`${safeSize.width / 2},0 ${safeSize.width},${safeSize.height} 0,${safeSize.height}`}
                fill={fill || '#ffffff'}
                stroke={isSelected ? '#0073EA' : (stroke || '#000000')}
                strokeWidth={isSelected ? 3 / zoom : (strokeWidth || 2)}
                style={{ cursor: element.locked ? 'default' : 'move' }}
                onMouseDown={handleMouseDown}
                onDoubleClick={handleDoubleClick}
              />
            )}
            {shape === 'diamond' && (
              <polygon
                points={`${safeSize.width / 2},0 ${safeSize.width},${safeSize.height / 2} ${safeSize.width / 2},${safeSize.height} 0,${safeSize.height / 2}`}
                fill={fill || '#ffffff'}
                stroke={isSelected ? '#0073EA' : (stroke || '#000000')}
                strokeWidth={isSelected ? 3 / zoom : (strokeWidth || 2)}
                style={{ cursor: element.locked ? 'default' : 'move' }}
                onMouseDown={handleMouseDown}
                onDoubleClick={handleDoubleClick}
              />
            )}
            
            {!isEditing && text && (
              <text
                x={safeSize.width / 2}
                y={safeSize.height / 2}
                textAnchor="middle"
                dominantBaseline="middle"
                fill="#000"
                fontSize={14}
                style={{ pointerEvents: 'none' }}
              >
                {text}
              </text>
            )}
            
            {isEditing && (
              <foreignObject x="0" y="0" width={safeSize.width} height={safeSize.height}>
                <div className="w-full h-full flex items-center justify-center p-2">
                  <input
                    ref={textAreaRef}
                    type="text"
                    className="w-full text-center bg-transparent border-none outline-none"
                    style={{ fontSize: 14 }}
                    value={safeProperties.text || ''}
                    onChange={handleTextChange}
                    onBlur={handleTextBlur}
                    onKeyDown={handleTextKeyDown}
                    placeholder="Escribe..."
                    autoFocus
                  />
                </div>
              </foreignObject>
            )}

            {isSelected && !element.locked && (
              <>
                {[
                  { x: 0, y: 0 },
                  { x: safeSize.width, y: 0 },
                  { x: 0, y: safeSize.height },
                  { x: safeSize.width, y: safeSize.height }
                ].map((handle, i) => (
                  <circle
                    key={i}
                    cx={handle.x}
                    cy={handle.y}
                    r={4 / zoom}
                    fill="white"
                    stroke="#0073EA"
                    strokeWidth={2 / zoom}
                    style={{ cursor: 'nwse-resize' }}
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      setIsResizing(true);
                      setResizeHandle(i);
                    }}
                  />
                ))}
              </>
            )}
          </g>
        );

      case 'text':
        return (
          <g transform={`translate(${safePosition.x}, ${safePosition.y})`}>
            <rect
              width={safeSize.width}
              height={safeSize.height}
              fill="transparent"
              stroke={isSelected ? '#0073EA' : 'transparent'}
              strokeWidth={isSelected ? 2 / zoom : 0}
              style={{ cursor: element.locked ? 'default' : 'move' }}
              onMouseDown={handleMouseDown}
              onDoubleClick={handleDoubleClick}
            />
            {!isEditing ? (
              <text
                x={safeProperties.align === 'center' ? safeSize.width / 2 : safeProperties.align === 'right' ? safeSize.width : 0}
                y={20}
                fill={safeProperties.color || '#000000'}
                fontSize={safeProperties.fontSize || 18}
                fontWeight={safeProperties.bold ? 'bold' : 'normal'}
                fontStyle={safeProperties.italic ? 'italic' : 'normal'}
                textAnchor={safeProperties.align === 'center' ? 'middle' : safeProperties.align === 'right' ? 'end' : 'start'}
                style={{ pointerEvents: 'none' }}
              >
                {safeProperties.text || 'Texto'}
              </text>
            ) : (
              <foreignObject width={safeSize.width} height={safeSize.height}>
                <input
                  ref={textAreaRef}
                  type="text"
                  className="w-full h-full bg-transparent border-none outline-none"
                  style={{ 
                    fontSize: safeProperties.fontSize || 18,
                    color: safeProperties.color || '#000000',
                    textAlign: safeProperties.align || 'left'
                  }}
                  value={safeProperties.text || ''}
                  onChange={handleTextChange}
                  onBlur={handleTextBlur}
                  onKeyDown={handleTextKeyDown}
                  autoFocus
                />
              </foreignObject>
            )}
          </g>
        );

      case 'connector':
        const { startPoint, endPoint, arrowStart, arrowEnd } = safeProperties;
        const safeStartPoint = startPoint || { x: 0, y: 0 };
        const safeEndPoint = endPoint || { x: 200, y: 0 };
        
        return (
          <g transform={`translate(${safePosition.x}, ${safePosition.y})`}>
            <line
              x1={safeStartPoint.x}
              y1={safeStartPoint.y}
              x2={safeEndPoint.x}
              y2={safeEndPoint.y}
              stroke={isSelected ? '#0073EA' : (safeProperties.stroke || '#000000')}
              strokeWidth={isSelected ? 3 / zoom : (safeProperties.strokeWidth || 2)}
              markerEnd={arrowEnd ? 'url(#arrowhead)' : ''}
              markerStart={arrowStart ? 'url(#arrowhead-start)' : ''}
              style={{ cursor: element.locked ? 'default' : 'move' }}
              onMouseDown={handleMouseDown}
            />
            <defs>
              <marker
                id="arrowhead"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon points="0 0, 10 3, 0 6" fill={safeProperties.stroke || '#000000'} />
              </marker>
              <marker
                id="arrowhead-start"
                markerWidth="10"
                markerHeight="10"
                refX="1"
                refY="3"
                orient="auto"
              >
                <polygon points="10 0, 0 3, 10 6" fill={safeProperties.stroke || '#000000'} />
              </marker>
            </defs>
          </g>
        );

      case 'image':
        return (
          <g transform={`translate(${safePosition.x}, ${safePosition.y})`}>
            <rect
              width={safeSize.width}
              height={safeSize.height}
              fill="white"
              stroke={isSelected ? '#0073EA' : '#ddd'}
              strokeWidth={isSelected ? 3 / zoom : 1 / zoom}
              rx="4"
              style={{ cursor: element.locked ? 'default' : 'move' }}
              onMouseDown={handleMouseDown}
            />
            {safeProperties.url ? (
              <image
                href={safeProperties.url}
                x="0"
                y="0"
                width={safeSize.width}
                height={safeSize.height}
                preserveAspectRatio="xMidYMid slice"
                clipPath="inset(0 round 4px)"
              />
            ) : (
              <text
                x={safeSize.width / 2}
                y={safeSize.height / 2}
                textAnchor="middle"
                dominantBaseline="middle"
                fill="#999"
                fontSize={14}
                style={{ pointerEvents: 'none' }}
              >
                🖼️ Imagen
              </text>
            )}
            
            {isSelected && !element.locked && (
              <>
                {[
                  { x: 0, y: 0 },
                  { x: safeSize.width, y: 0 },
                  { x: 0, y: safeSize.height },
                  { x: safeSize.width, y: safeSize.height }
                ].map((handle, i) => (
                  <circle
                    key={i}
                    cx={handle.x}
                    cy={handle.y}
                    r={4 / zoom}
                    fill="white"
                    stroke="#0073EA"
                    strokeWidth={2 / zoom}
                    style={{ cursor: 'nwse-resize' }}
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      setIsResizing(true);
                      setResizeHandle(i);
                    }}
                  />
                ))}
              </>
            )}
          </g>
        );

      default:
        return null;
    }
  };

  return renderElement();
}
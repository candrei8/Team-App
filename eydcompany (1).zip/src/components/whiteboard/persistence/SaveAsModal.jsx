import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Copy, Loader2 } from 'lucide-react';

export default function SaveAsModal({ 
  isOpen, 
  onClose, 
  currentTitle,
  onSaveAs 
}) {
  const [title, setTitle] = useState(`Copia de ${currentTitle}`);
  const [description, setDescription] = useState('');
  const [keepCollaborators, setKeepCollaborators] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsCreating(true);
    try {
      await onSaveAs({
        title: title.trim(),
        description: description.trim(),
        keepCollaborators
      });
      onClose();
    } catch (error) {
      console.error('Error al crear copia:', error);
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Copy className="w-5 h-5" />
            Guardar como nueva copia
          </DialogTitle>
          <DialogDescription>
            Crea una copia de este whiteboard con un nuevo nombre
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Nombre del whiteboard *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Nombre de la copia"
              maxLength={100}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descripción (opcional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe el propósito de este whiteboard..."
              rows={3}
              maxLength={500}
            />
            <p className="text-xs text-gray-500">
              {description.length}/500 caracteres
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="collaborators"
              checked={keepCollaborators}
              onCheckedChange={setKeepCollaborators}
            />
            <Label 
              htmlFor="collaborators"
              className="text-sm font-normal cursor-pointer"
            >
              Mantener colaboradores actuales
            </Label>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isCreating}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={!title.trim() || isCreating}
              className="bg-[#0073EA] hover:bg-[#0056B3]"
            >
              {isCreating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creando copia...
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Crear copia
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
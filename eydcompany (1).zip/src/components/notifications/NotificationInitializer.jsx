import { useEffect } from 'react';
import pushNotificationService from './PushNotificationService';

/**
 * Componente que inicializa el servicio de notificaciones push automáticamente
 * Se debe agregar en el Layout para que se ejecute en toda la app
 */
export default function NotificationInitializer() {
  useEffect(() => {
    // Inicializar servicio de notificaciones al cargar la app
    const initNotifications = async () => {
      try {
        await pushNotificationService.initialize();
      } catch (error) {
        console.error('Error initializing notifications:', error);
      }
    };

    // Esperar un poco para no interferir con la carga inicial
    const timer = setTimeout(() => {
      initNotifications();
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  // Este componente no renderiza nada
  return null;
}
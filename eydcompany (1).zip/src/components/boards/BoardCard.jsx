import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Folder, Users, Lock, Globe, MoreHorizontal, Calendar, Trash2, Edit3, UserCircle } from "lucide-react";
import { motion } from "framer-motion";
import { format, formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

export default function BoardCard({ board, viewMode, index, onDelete, onEdit }) {
  const [ownerName, setOwnerName] = useState('');
  const [participants, setParticipants] = useState([]);

  useEffect(() => {
    loadOwnerAndParticipants();
  }, [board]);

  const loadOwnerAndParticipants = async () => {
    try {
      // Cargar el propietario
      if (board.created_by) {
        const users = await base44.entities.User.filter({ email: board.created_by });
        if (users.length > 0) {
          setOwnerName(users[0].full_name || users[0].email);
        }
      }

      // Cargar participantes
      if (board.participants && board.participants.length > 0) {
        const participantEmails = board.participants.filter(email => email !== board.created_by);
        if (participantEmails.length > 0) {
          const allUsers = await base44.entities.User.list();
          const participantUsers = allUsers.filter(user => 
            participantEmails.includes(user.email)
          );
          setParticipants(participantUsers);
        }
      }
    } catch (error) {
      console.error("Error al cargar propietario y participantes:", error);
    }
  };

  const handleDelete = (e) => {
    e.preventDefault(); 
    e.stopPropagation(); 
    if (window.confirm(`¿Estás seguro de que deseas eliminar el proyecto "${board.title}"? Esta acción no se puede deshacer.`)) {
      onDelete(board.id);
    }
  };

  const handleEdit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    onEdit(board);
  };

  const getUserInitials = (name) => {
    if (!name) return "?";
    const names = name.split(" ");
    if (names.length >= 2) {
      return `${names[0][0]}${names[1][0]}`.toUpperCase();
    }
    return names[0][0].toUpperCase();
  };

  const boardColor = board.color || '#0073EA';

  if (viewMode === "list") {
    return (
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: index * 0.05 }}
      >
        <Card className="bg-white border border-gray-200 hover:shadow-md transition-all duration-200 group rounded-lg overflow-hidden">
          <div className="flex items-center">
            <div
              className="w-1.5 h-16 flex-shrink-0"
              style={{ backgroundColor: boardColor }}
            />
            <CardContent className="p-3 flex-1">
              <div className="flex items-center justify-between">
                <Link to={createPageUrl(`Board?id=${board.id}`)} className="flex items-center gap-3 flex-grow min-w-0">
                  <div 
                    className="w-9 h-9 rounded-md flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${boardColor}20` }}
                  >
                    <Folder 
                      className="w-4 h-4"
                      style={{ color: boardColor }}
                    />
                  </div>
                  <div className="flex-grow min-w-0">
                    <h3 className="font-semibold text-gray-800 group-hover:text-[${boardColor}] transition-colors text-sm truncate">
                      {board.title}
                    </h3>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-gray-500 text-xs truncate">
                        {board.description || 'Sin descripción'}
                      </p>
                      {ownerName && (
                        <>
                          <span className="text-gray-300">•</span>
                          <div className="flex items-center gap-1 text-xs text-gray-500">
                            <UserCircle className="w-3 h-3" />
                            <span className="truncate">{ownerName}</span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </Link>
                <div className="flex items-center gap-2 flex-shrink-0 ml-3">
                  {/* Participantes */}
                  {participants.length > 0 && (
                    <div className="flex -space-x-2">
                      {participants.slice(0, 3).map((participant, idx) => (
                        <div
                          key={participant.id}
                          className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-xs font-semibold border-2 border-white"
                          title={participant.full_name || participant.email}
                        >
                          {getUserInitials(participant.full_name)}
                        </div>
                      ))}
                      {participants.length > 3 && (
                        <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 text-xs font-semibold border-2 border-white">
                          +{participants.length - 3}
                        </div>
                      )}
                    </div>
                  )}

                  <Badge 
                    variant="outline" 
                    className={`border-none text-xs px-2 py-0.5 rounded-full ${
                      board.visibility === 'private' 
                        ? 'bg-rose-100 text-rose-700' 
                        : 'bg-emerald-100 text-emerald-700'
                    }`}
                  >
                    {board.visibility === 'private' ? (
                      <Lock className="w-2.5 h-2.5 mr-1" />
                    ) : (
                      <Globe className="w-2.5 h-2.5 mr-1" />
                    )}
                    {board.visibility === 'private' ? 'Privado' : 'Compartido'}
                  </Badge>
                  <div className="text-right hidden sm:block">
                    <p className="text-xs text-gray-400">
                      {formatDistanceToNow(new Date(board.updated_date), { addSuffix: true, locale: es })}
                    </p>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-gray-500 hover:bg-gray-100 rounded-md" onClick={(e) => {e.preventDefault(); e.stopPropagation();}}>
                        <MoreHorizontal className="w-3.5 h-3.5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={handleEdit}>
                        <Edit3 className="w-3.5 h-3.5 mr-2" />
                        Editar Proyecto
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={handleDelete} className="text-red-600 focus:text-red-600 focus:bg-red-50">
                        <Trash2 className="w-3.5 h-3.5 mr-2" />
                        Eliminar Proyecto
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </div>
        </Card>
      </motion.div>
    );
  }

  // Vista de Cuadrícula
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="h-full"
    >
      <Card 
        className="bg-white border border-gray-200 hover:shadow-lg transition-all duration-300 group h-full flex flex-col rounded-xl overflow-hidden"
      >
        <div 
            className="h-2 w-full"
            style={{backgroundColor: boardColor}}
        />
        <Link to={createPageUrl(`Board?id=${board.id}`)} className="flex-grow block p-5">
          <div className="flex items-start justify-between mb-4">
            <div 
              className="w-10 h-10 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: `${boardColor}20` }}
            >
              <Folder 
                className="w-5 h-5"
                style={{ color: boardColor }}
              />
            </div>
            <Badge 
              variant="outline" 
              className={`border-none text-xs px-2.5 py-1 rounded-full ${
                board.visibility === 'private' 
                  ? 'bg-rose-100 text-rose-700' 
                  : 'bg-emerald-100 text-emerald-700'
              }`}
            >
              {board.visibility === 'private' ? (
                <Lock className="w-3 h-3 mr-1.5" />
              ) : (
                <Globe className="w-3 h-3 mr-1.5" />
              )}
              {board.visibility === 'private' ? 'Privado' : 'Compartido'}
            </Badge>
          </div>
          
          <h3 className="font-semibold text-gray-800 text-lg mb-2 group-hover:text-[${boardColor}] transition-colors">
            {board.title}
          </h3>
          
          <p className="text-gray-600 text-sm mb-3 line-clamp-2">
            {board.description || 'Sin descripción proporcionada.'}
          </p>

          {/* Propietario */}
          {ownerName && (
            <div className="flex items-center gap-2 mb-3 text-sm text-gray-600">
              <UserCircle className="w-4 h-4" />
              <span className="truncate">{ownerName}</span>
            </div>
          )}

          {/* Participantes */}
          {participants.length > 0 && (
            <div className="flex items-center gap-2 mb-4">
              <Users className="w-4 h-4 text-gray-500" />
              <div className="flex -space-x-2">
                {participants.slice(0, 5).map((participant, idx) => (
                  <div
                    key={participant.id}
                    className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-xs font-semibold border-2 border-white"
                    title={participant.full_name || participant.email}
                  >
                    {getUserInitials(participant.full_name)}
                  </div>
                ))}
                {participants.length > 5 && (
                  <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 text-xs font-semibold border-2 border-white">
                    +{participants.length - 5}
                  </div>
                )}
              </div>
            </div>
          )}
          
          <div className="flex items-center justify-between text-xs text-gray-500 mt-auto pt-4 border-t border-gray-100">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              <span>{formatDistanceToNow(new Date(board.updated_date), { addSuffix: true, locale: es })}</span>
            </div>
          </div>
        </Link>
        <div className="p-2 border-t border-gray-100 bg-gray-50/50">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="w-full justify-center text-xs text-gray-600 hover:bg-gray-200/70 hover:text-gray-800">
                  <MoreHorizontal className="w-4 h-4 mr-1.5" /> Opciones
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-white shadow-lg rounded-md">
                <DropdownMenuItem onClick={handleEdit} className="text-gray-700 hover:bg-gray-100">
                  <Edit3 className="w-3.5 h-3.5 mr-2" />
                  Editar Proyecto
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleDelete} className="text-red-600 hover:text-red-700 hover:bg-red-50 focus:text-red-600 focus:bg-red-50">
                  <Trash2 className="w-3.5 h-3.5 mr-2" />
                  Eliminar Proyecto
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
        </div>
      </Card>
    </motion.div>
  );
}
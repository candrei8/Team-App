import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { 
  Hash, 
  Lock, 
  Plus, 
  Circle, 
  ChevronDown, 
  MessageSquare 
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Sidebar({ 
  channels, 
  selectedChannelId, 
  onSelectChannel, 
  currentUser,
  users 
}) {
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [newChannelName, setNewChannelName] = useState("");
  const [newChannelType, setNewChannelType] = useState("general");

  const publicChannels = channels.filter(c => !c.is_private && c.type !== 'direct');
  const privateChannels = channels.filter(c => c.is_private && c.type !== 'direct');
  const directMessages = channels.filter(c => c.type === 'direct');

  const handleCreateChannel = async () => {
    try {
      await base44.entities.Channel.create({
        name: newChannelName.toLowerCase().replace(/\s+/g, '-'),
        type: newChannelType,
        is_private: newChannelType === 'private',
        created_by: currentUser.email,
        last_message_at: new Date().toISOString()
      });
      setCreateModalOpen(false);
      setNewChannelName("");
    } catch (error) {
      console.error("Error creating channel:", error);
    }
  };

  const ChannelItem = ({ channel, icon: Icon }) => (
    <button
      onClick={() => onSelectChannel(channel)}
      className={cn(
        "w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-sm transition-colors mb-0.5",
        selectedChannelId === channel.id 
          ? "bg-[#E1E5F3] text-[#0073EA] font-medium" 
          : "text-gray-600 hover:bg-gray-200 hover:text-gray-900"
      )}
    >
      <Icon className="w-4 h-4 opacity-70" />
      <span className="truncate">{channel.name}</span>
    </button>
  );

  const DMItem = ({ channel }) => {
    // Find the other user in the DM
    const otherUserEmail = channel.allowed_users?.find(email => email !== currentUser.email);
    const otherUser = users.find(u => u.email === otherUserEmail);
    const displayName = otherUser?.full_name || otherUserEmail || channel.name;
    const isOnline = Math.random() > 0.5; // Mock presence for now

    return (
      <button
        onClick={() => onSelectChannel(channel)}
        className={cn(
          "w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-sm transition-colors mb-0.5",
          selectedChannelId === channel.id 
            ? "bg-[#E1E5F3] text-[#0073EA] font-medium" 
            : "text-gray-600 hover:bg-gray-200 hover:text-gray-900"
        )}
      >
        <div className="relative">
            <div className="w-4 h-4 rounded-sm bg-gradient-to-tr from-blue-500 to-purple-500 flex items-center justify-center text-[8px] text-white font-bold uppercase">
                {displayName.substring(0,1)}
            </div>
            <div className={cn(
                "absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full border border-[#F5F7FA]",
                isOnline ? "bg-green-500" : "bg-gray-400"
            )} />
        </div>
        <span className="truncate">{displayName}</span>
      </button>
    );
  };

  return (
    <div className="flex flex-col h-full py-4 px-3">
      <div className="mb-6 px-2">
        <h2 className="text-lg font-bold text-gray-800 tracking-tight">Chat</h2>
      </div>

      <ScrollArea className="flex-1 -mx-2 px-2">
        {/* Channels */}
        <div className="mb-6">
          <div className="flex items-center justify-between px-2 mb-1 group">
            <button className="flex items-center gap-1 text-xs font-semibold text-gray-500 uppercase tracking-wider hover:text-gray-700">
              <ChevronDown className="w-3 h-3" />
              Canales
            </button>
            <Dialog open={createModalOpen} onOpenChange={setCreateModalOpen}>
              <DialogTrigger asChild>
                <button className="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-gray-900 transition-opacity">
                  <Plus className="w-4 h-4" />
                </button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Crear Canal</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Nombre del canal</Label>
                    <div className="relative">
                        <Hash className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                        <Input 
                            value={newChannelName}
                            onChange={(e) => setNewChannelName(e.target.value)}
                            className="pl-9" 
                            placeholder="proyectos-2024" 
                        />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Tipo</Label>
                    <Select value={newChannelType} onValueChange={setNewChannelType}>
                        <SelectTrigger>
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="general">Público (#)</SelectItem>
                            <SelectItem value="private">Privado (🔒)</SelectItem>
                        </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleCreateChannel}>Crear Canal</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          
          {publicChannels.map(channel => (
            <ChannelItem key={channel.id} channel={channel} icon={Hash} />
          ))}
          {privateChannels.map(channel => (
            <ChannelItem key={channel.id} channel={channel} icon={Lock} />
          ))}
        </div>

        {/* Direct Messages */}
        <div>
          <div className="flex items-center justify-between px-2 mb-1 group">
            <button className="flex items-center gap-1 text-xs font-semibold text-gray-500 uppercase tracking-wider hover:text-gray-700">
              <ChevronDown className="w-3 h-3" />
              Mensajes Directos
            </button>
            <button className="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-gray-900 transition-opacity">
              <Plus className="w-4 h-4" />
            </button>
          </div>
          {directMessages.map(channel => (
            <DMItem key={channel.id} channel={channel} />
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
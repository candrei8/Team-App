import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  FileText,
  Folder,
  FolderPlus,
  Upload,
  Search,
  Download,
  Trash2,
  Image as ImageIcon,
  File,
  Eye,
  Loader2,
  X,
  AlertCircle,
  Grid3x3,
  List,
  ArrowLeft,
  Briefcase,
  Menu,
  Lock,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import DragDropUpload from "../components/documents/DragDropUpload";
import PermissionsModal from "../components/documents/PermissionsModal";
import DocumentPreviewModal from "../components/documents/DocumentPreviewModal";

export default function DocumentsPage() {
  const [folders, setFolders] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [currentFolder, setCurrentFolder] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState("grid");
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);

  // Modals
  const [showCreateFolderModal, setShowCreateFolderModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [previewDocument, setPreviewDocument] = useState(null);
  
  // Upload state
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [uploadedFileData, setUploadedFileData] = useState({
    name: "",
    description: "",
    tags: []
  });

  // Edit permissions state
  const [editingDocument, setEditingDocument] = useState(null);
  const [existingPermissions, setExistingPermissions] = useState([]);

  useEffect(() => {
    loadData();
    loadUser();
  }, [currentFolder]);

  const loadUser = async () => {
    try {
      const user = await base44.auth.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error al cargar usuario:", error);
    }
  };

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [foldersData, documentsData] = await Promise.all([
        base44.entities.DocumentFolder.list("-updated_date"),
        base44.entities.Document.list("-updated_date")
      ]);
      setFolders(foldersData);
      setDocuments(documentsData);
    } catch (error) {
      console.error("Error al cargar documentos:", error);
    }
    setIsLoading(false);
  };

  const handleCreateFolder = async (folderData) => {
    try {
      await base44.entities.DocumentFolder.create({
        ...folderData,
        parent_folder_id: currentFolder?.id || null
      });
      await loadData();
      setShowCreateFolderModal(false);
    } catch (error) {
      console.error("Error al crear carpeta:", error);
    }
  };

  const handleFilesSelected = (files) => {
    setSelectedFiles(files);
    setShowUploadModal(true);
  };

  const handleUploadModalNext = (documentData) => {
    setUploadedFileData(documentData);
    setShowUploadModal(false);
    setShowPermissionsModal(true);
  };

  const handlePermissionsSave = async (permissionsConfig) => {
    setShowPermissionsModal(false);

    // Si estamos editando permisos de un documento existente
    if (editingDocument) {
      setIsUploading(true);
      try {
        // Eliminar permisos existentes
        const currentPermissions = await base44.entities.DocumentPermission.filter({
          document_id: editingDocument.id
        });
        for (const perm of currentPermissions) {
          await base44.entities.DocumentPermission.delete(perm.id);
        }

        // Crear nuevos permisos
        await createDocumentPermissions(editingDocument.id, permissionsConfig);

        // Log activity
        await base44.entities.DocumentActivity.create({
          document_id: editingDocument.id,
          user_email: currentUser.email,
          user_name: currentUser.full_name,
          action: "edit_permissions",
          details: { access_type: permissionsConfig.accessType }
        });

        await loadData();
        setEditingDocument(null);
        setExistingPermissions([]);
      } catch (error) {
        console.error("Error al actualizar permisos:", error);
        alert("Error al actualizar permisos. Intenta de nuevo.");
      }
      setIsUploading(false);
      return;
    }

    // Si estamos subiendo nuevos archivos
    if (!selectedFiles || selectedFiles.length === 0) return;

    setIsUploading(true);

    try {
      for (const file of selectedFiles) {
        setUploadProgress(20);

        // Upload file
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        setUploadProgress(50);

        // Create document record
        const document = await base44.entities.Document.create({
          name: uploadedFileData.name || file.name,
          original_name: file.name,
          description: uploadedFileData.description || "",
          file_url: file_url,
          file_type: file.type,
          file_extension: file.name.split('.').pop(),
          file_size: file.size,
          folder_id: currentFolder?.id || null,
          department_origin: currentUser?.department || "",
          tags: uploadedFileData.tags || []
        });
        setUploadProgress(70);

        // Create permissions based on config
        await createDocumentPermissions(document.id, permissionsConfig);
        
        // Log activity
        await base44.entities.DocumentActivity.create({
          document_id: document.id,
          user_email: currentUser.email,
          user_name: currentUser.full_name,
          action: "upload",
          details: { file_name: file.name, file_size: file.size }
        });

        setUploadProgress(100);
      }

      await loadData();
      setSelectedFiles([]);
      setUploadedFileData({ name: "", description: "", tags: [] });
      setUploadProgress(0);
    } catch (error) {
      console.error("Error al subir documento:", error);
      alert("Error al subir el archivo. Intenta de nuevo.");
    }
    setIsUploading(false);
  };

  const createDocumentPermissions = async (documentId, config) => {
    const { accessType, permissions, selectedDepartments, selectedUsers } = config;

    // Create permissions based on access type
    if (accessType === "only_me") {
      await base44.entities.DocumentPermission.create({
        document_id: documentId,
        permission_type: "user",
        entity_id: currentUser.email,
        ...permissions
      });
    } else if (accessType === "admins_only") {
      await base44.entities.DocumentPermission.create({
        document_id: documentId,
        permission_type: "role",
        entity_id: "admin",
        ...permissions
      });
    } else if (accessType === "my_department") {
      if (currentUser.department) {
        await base44.entities.DocumentPermission.create({
          document_id: documentId,
          permission_type: "department",
          entity_id: currentUser.department,
          ...permissions
        });
      }
    } else if (accessType === "specific_departments") {
      for (const dept of selectedDepartments) {
        await base44.entities.DocumentPermission.create({
          document_id: documentId,
          permission_type: "department",
          entity_id: dept,
          ...permissions
        });
      }
    } else if (accessType === "specific_users") {
      for (const userEmail of selectedUsers) {
        await base44.entities.DocumentPermission.create({
          document_id: documentId,
          permission_type: "user",
          entity_id: userEmail,
          ...permissions
        });
      }
    } else if (accessType === "everyone") {
      await base44.entities.DocumentPermission.create({
        document_id: documentId,
        permission_type: "public",
        entity_id: "all",
        ...permissions
      });
    }
  };

  const handleEditPermissions = async (document) => {
    setEditingDocument(document);
    
    // Cargar permisos existentes
    try {
      const perms = await base44.entities.DocumentPermission.filter({
        document_id: document.id
      });
      setExistingPermissions(perms);
    } catch (error) {
      console.error("Error al cargar permisos:", error);
      setExistingPermissions([]);
    }
    
    setShowPermissionsModal(true);
  };

  const handleDeleteDocument = async (documentId) => {
    if (confirm("¿Estás seguro de eliminar este documento?")) {
      try {
        await base44.entities.Document.delete(documentId);
        await loadData();
      } catch (error) {
        console.error("Error al eliminar documento:", error);
      }
    }
  };

  const handleDeleteFolder = async (folderId) => {
    if (confirm("¿Estás seguro de eliminar esta carpeta?")) {
      try {
        await base44.entities.DocumentFolder.delete(folderId);
        await loadData();
      } catch (error) {
        console.error("Error al eliminar carpeta:", error);
      }
    }
  };

  const handlePreviewDocument = (document) => {
    setPreviewDocument(document);
    setShowPreviewModal(true);
  };

  const getFileIcon = (fileType) => {
    if (!fileType) return File;
    if (fileType.includes('image')) return ImageIcon;
    if (fileType.includes('pdf')) return FileText;
    if (fileType.includes('doc')) return FileText;
    return File;
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const filteredFolders = folders.filter(folder => {
    const matchesSearch = folder.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesParent = currentFolder 
      ? folder.parent_folder_id === currentFolder.id 
      : !folder.parent_folder_id;
    return matchesSearch && matchesParent;
  });

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFolder = currentFolder 
      ? doc.folder_id === currentFolder.id 
      : !doc.folder_id;
    return matchesSearch && matchesFolder;
  });

  return (
    <div className="p-4 sm:p-6 bg-[#F5F6F8] min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header - Mobile Responsive */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 sm:mb-8"
        >
          {/* Title Section */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4 sm:mb-6">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              {currentFolder && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setCurrentFolder(null)}
                  className="flex-shrink-0 h-9 w-9 sm:h-10 sm:w-10"
                >
                  <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
                </Button>
              )}
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg flex-shrink-0">
                <Folder className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <div className="min-w-0">
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-[#323338] truncate">
                  {currentFolder ? currentFolder.name : "Documentación"}
                </h1>
                <p className="text-xs sm:text-sm text-[#676879] mt-0.5 sm:mt-1 truncate">
                  {currentFolder 
                    ? currentFolder.description || "Gestiona tus documentos" 
                    : "Organiza tus documentos"}
                </p>
              </div>
            </div>

            {/* Action Buttons - Desktop */}
            <div className="hidden sm:flex gap-2 lg:gap-3 flex-shrink-0">
              <Button
                onClick={() => setShowCreateFolderModal(true)}
                variant="outline"
                className="border-2 border-[#E1E5F3] hover:border-[#0073EA] h-10"
                size="sm"
              >
                <FolderPlus className="w-4 h-4 mr-2" />
                <span className="hidden lg:inline">Nueva Carpeta</span>
                <span className="lg:hidden">Carpeta</span>
              </Button>
              <Button
                onClick={() => setShowUploadModal(true)}
                className="bg-[#0073EA] hover:bg-[#0056B3] h-10"
                size="sm"
              >
                <Upload className="w-4 h-4 mr-2" />
                <span className="hidden lg:inline">Subir Archivo</span>
                <span className="lg:hidden">Subir</span>
              </Button>
            </div>

            {/* Action Buttons - Mobile (Dropdown) */}
            <div className="sm:hidden">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button className="w-full bg-[#0073EA] hover:bg-[#0056B3]">
                    <Menu className="w-4 h-4 mr-2" />
                    Acciones
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={() => setShowCreateFolderModal(true)}>
                    <FolderPlus className="w-4 h-4 mr-2" />
                    Nueva Carpeta
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setShowUploadModal(true)}>
                    <Upload className="w-4 h-4 mr-2" />
                    Subir Archivo
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          {/* Search and View Controls - Mobile Responsive */}
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-[#676879]" />
              <Input
                placeholder="Buscar..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 bg-white border-[#E1E5F3] h-10 text-sm"
              />
            </div>
            <div className="flex gap-2 justify-center sm:justify-start">
              <Button
                variant={viewMode === "grid" ? "default" : "outline"}
                size="icon"
                onClick={() => setViewMode("grid")}
                className="h-10 w-10"
              >
                <Grid3x3 className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "outline"}
                size="icon"
                onClick={() => setViewMode("list")}
                className="h-10 w-10"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Content */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
          </div>
        ) : (
          <div className="space-y-6 sm:space-y-8">
            {/* Folders */}
            {filteredFolders.length > 0 && (
              <div>
                <h2 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4 px-1">Carpetas</h2>
                <div className={viewMode === "grid" 
                  ? "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4" 
                  : "space-y-2"
                }>
                  {filteredFolders.map((folder) => (
                    <FolderCard
                      key={folder.id}
                      folder={folder}
                      viewMode={viewMode}
                      onClick={() => setCurrentFolder(folder)}
                      onDelete={() => handleDeleteFolder(folder.id)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Documents */}
            {filteredDocuments.length > 0 && (
              <div>
                <h2 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4 px-1">Documentos</h2>
                <div className={viewMode === "grid" 
                  ? "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4" 
                  : "space-y-2"
                }>
                  {filteredDocuments.map((doc) => (
                    <DocumentCard
                      key={doc.id}
                      document={doc}
                      viewMode={viewMode}
                      onDelete={() => handleDeleteDocument(doc.id)}
                      onEditPermissions={() => handleEditPermissions(doc)}
                      onPreview={() => handlePreviewDocument(doc)}
                      getFileIcon={getFileIcon}
                      formatFileSize={formatFileSize}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Empty State */}
            {filteredFolders.length === 0 && filteredDocuments.length === 0 && (
              <div className="text-center py-12 sm:py-16 px-4">
                <Folder className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2">
                  {searchQuery ? "No se encontraron resultados" : "Esta carpeta está vacía"}
                </h3>
                <p className="text-sm sm:text-base text-gray-500 mb-6">
                  {searchQuery 
                    ? "Intenta con otros términos" 
                    : "Crea carpetas y sube archivos"}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Create Folder Modal */}
        <CreateFolderModal
          isOpen={showCreateFolderModal}
          onClose={() => setShowCreateFolderModal(false)}
          onSubmit={handleCreateFolder}
        />

        {/* Upload Document Modal */}
        <UploadDocumentModal
          isOpen={showUploadModal}
          onClose={() => {
            setShowUploadModal(false);
            setSelectedFiles([]);
            setUploadedFileData({ name: "", description: "", tags: [] });
          }}
          onNext={handleUploadModalNext}
          onFilesSelected={handleFilesSelected}
          selectedFiles={selectedFiles}
          currentFolder={currentFolder}
        />

        {/* Permissions Modal */}
        {currentUser && (
          <PermissionsModal
            isOpen={showPermissionsModal}
            onClose={() => {
              setShowPermissionsModal(false);
              setSelectedFiles([]);
              setUploadedFileData({ name: "", description: "", tags: [] });
              setEditingDocument(null);
              setExistingPermissions([]);
            }}
            onSave={handlePermissionsSave}
            files={editingDocument ? [editingDocument] : selectedFiles}
            currentUser={currentUser}
            existingPermissions={existingPermissions}
            isEditMode={!!editingDocument}
          />
        )}

        {/* Upload Progress Overlay */}
        {isUploading && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
              <div className="text-center">
                <Loader2 className="w-12 h-12 animate-spin text-blue-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Subiendo archivos...</h3>
                <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-500 transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
                <p className="text-sm text-gray-500 mt-2">{uploadProgress}%</p>
              </div>
            </div>
          </div>
        )}

        {/* Document Preview Modal */}
        <DocumentPreviewModal
          isOpen={showPreviewModal}
          onClose={() => {
            setShowPreviewModal(false);
            setPreviewDocument(null);
          }}
          document={previewDocument}
        />
      </div>
    </div>
  );
}

// Folder Card Component - Mobile Responsive
function FolderCard({ folder, viewMode, onClick, onDelete }) {
  const getFolderIconComponent = (iconName) => {
    switch (iconName) {
      case "briefcase":
        return Briefcase;
      case "image":
        return ImageIcon;
      case "file":
        return FileText;
      default:
        return Folder;
    }
  };

  const FolderIcon = getFolderIconComponent(folder.icon);

  if (viewMode === "list") {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex items-center justify-between p-3 sm:p-4 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer"
        onClick={onClick}
      >
        <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: folder.color + '20' }}>
            <FolderIcon className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: folder.color }} />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="font-medium text-sm sm:text-base text-gray-900 truncate">{folder.name}</h3>
            {folder.description && (
              <p className="text-xs sm:text-sm text-gray-500 truncate">{folder.description}</p>
            )}
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
          }}
          className="flex-shrink-0 h-8 w-8 sm:h-9 sm:w-9"
        >
          <Trash2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-red-500" />
        </Button>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className="relative group"
    >
      <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={onClick}>
        <CardContent className="p-4 sm:p-6">
          <div className="flex items-start justify-between mb-3 sm:mb-4">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: folder.color + '20' }}>
              <FolderIcon className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: folder.color }} />
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity h-8 w-8"
              onClick={(e) => {
                e.stopPropagation();
                onDelete();
              }}
            >
              <Trash2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-red-500" />
            </Button>
          </div>
          <h3 className="font-semibold text-sm sm:text-base text-gray-900 truncate">{folder.name}</h3>
          {folder.description && (
            <p className="text-xs sm:text-sm text-gray-500 mt-1 line-clamp-2">{folder.description}</p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Document Card Component - Mobile Responsive
function DocumentCard({ document, viewMode, onDelete, onEditPermissions, onPreview, getFileIcon, formatFileSize }) {
  const Icon = getFileIcon(document.file_type);

  if (viewMode === "list") {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex items-center justify-between p-3 sm:p-4 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer"
        onClick={onPreview}
      >
        <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
          <div className="w-9 h-9 sm:w-10 sm:h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <Icon className="w-4 h-4 sm:w-5 sm:h-5 text-blue-600" />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="font-medium text-sm sm:text-base text-gray-900 truncate">{document.name}</h3>
            <p className="text-xs text-gray-500 truncate">
              {formatFileSize(document.file_size)} • {format(new Date(document.created_date), "dd MMM yyyy", { locale: es })}
            </p>
          </div>
        </div>
        <div className="flex gap-1 sm:gap-2 flex-shrink-0">
          <Button
            variant="ghost"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              onPreview();
            }}
            className="h-8 w-8 sm:h-9 sm:w-9"
            title="Vista Previa"
          >
            <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-green-500" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              window.open(document.file_url, '_blank');
            }}
            className="h-8 w-8 sm:h-9 sm:w-9"
            title="Descargar"
          >
            <Download className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-500" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              onEditPermissions();
            }}
            className="h-8 w-8 sm:h-9 sm:w-9"
            title="Editar Permisos"
          >
            <Lock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-purple-500" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            className="h-8 w-8 sm:h-9 sm:w-9"
            title="Eliminar"
          >
            <Trash2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-red-500" />
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className="relative group"
    >
      <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={onPreview}>
        <CardContent className="p-4 sm:p-6">
          <div className="flex items-start justify-between mb-3 sm:mb-4">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
            </div>
            <div className="flex gap-1 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  onPreview();
                }}
                className="h-8 w-8"
                title="Vista Previa"
              >
                <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-green-500" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  window.open(document.file_url, '_blank');
                }}
                className="h-8 w-8"
                title="Descargar"
              >
                <Download className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-500" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  onEditPermissions();
                }}
                className="h-8 w-8"
                title="Editar Permisos"
              >
                <Lock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-purple-500" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete();
                }}
                className="h-8 w-8"
                title="Eliminar"
              >
                <Trash2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-red-500" />
              </Button>
            </div>
          </div>
          <h3 className="font-semibold text-sm sm:text-base text-gray-900 truncate">{document.name}</h3>
          <p className="text-xs text-gray-500 mt-1">
            {formatFileSize(document.file_size)}
          </p>
          <p className="text-xs text-gray-400 mt-1">
            {format(new Date(document.created_date), "dd MMM yyyy", { locale: es })}
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Create Folder Modal - Mobile Responsive
function CreateFolderModal({ isOpen, onClose, onSubmit }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    color: "#0073EA",
    icon: "folder"
  });

  const colors = [
    { value: "#0073EA", name: "Azul" },
    { value: "#00C875", name: "Verde" },
    { value: "#FFCB00", name: "Amarillo" },
    { value: "#E2445C", name: "Rojo" },
    { value: "#A25DDC", name: "Morado" },
    { value: "#037F4C", name: "Verde Oscuro" },
    { value: "#FF6B6B", name: "Coral" },
    { value: "#4ECDC4", name: "Turquesa" }
  ];

  const icons = [
    { value: "folder", icon: Folder, name: "Carpeta" },
    { value: "briefcase", icon: Briefcase, name: "Trabajo" },
    { value: "image", icon: ImageIcon, name: "Imágenes" },
    { value: "file", icon: FileText, name: "Documentos" }
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
    setFormData({ name: "", description: "", color: "#0073EA", icon: "folder" });
  };

  const resetForm = () => {
    setFormData({ name: "", description: "", color: "#0073EA", icon: "folder" });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={resetForm}>
      <DialogContent className="max-w-[95vw] sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl sm:text-2xl font-bold flex items-center gap-2 sm:gap-3">
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
              <FolderPlus className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
            </div>
            <span className="text-lg sm:text-xl">Crear Nueva Carpeta</span>
          </DialogTitle>
          <p className="text-xs sm:text-sm text-gray-500 mt-2">
            Organiza documentos con colores e iconos
          </p>
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 sm:space-y-6 py-4 sm:py-6">
            {/* Preview */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center justify-center py-6 sm:py-8 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border-2 border-dashed border-gray-300"
            >
              <div className="text-center px-4">
                <motion.div 
                  whileHover={{ scale: 1.05 }}
                  className="w-16 h-16 sm:w-20 sm:h-20 mx-auto rounded-2xl shadow-xl flex items-center justify-center mb-3 sm:mb-4"
                  style={{ backgroundColor: formData.color }}
                >
                  {icons.find(i => i.value === formData.icon)?.icon && 
                    React.createElement(icons.find(i => i.value === formData.icon).icon, {
                      className: "w-8 h-8 sm:w-10 sm:h-10 text-white"
                    })
                  }
                </motion.div>
                <p className="font-semibold text-gray-900 text-base sm:text-lg truncate">
                  {formData.name || "Nombre de la carpeta"}
                </p>
                {formData.description && (
                  <p className="text-xs sm:text-sm text-gray-500 mt-1 line-clamp-2">
                    {formData.description}
                  </p>
                )}
              </div>
            </motion.div>

            {/* Name Input */}
            <div className="space-y-2">
              <Label className="text-xs sm:text-sm font-semibold text-gray-700">
                Nombre de la carpeta *
              </Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Ej: Proyectos 2024..."
                required
                className="h-10 sm:h-12 text-sm sm:text-base"
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label className="text-xs sm:text-sm font-semibold text-gray-700">
                Descripción <span className="text-gray-400 font-normal">(opcional)</span>
              </Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Breve descripción..."
                className="min-h-[60px] sm:min-h-[80px] text-sm sm:text-base resize-none"
              />
            </div>

            {/* Color Picker */}
            <div className="space-y-3">
              <Label className="text-xs sm:text-sm font-semibold text-gray-700">
                Color de la carpeta
              </Label>
              <div className="grid grid-cols-4 gap-2 sm:gap-3">
                {colors.map((color) => (
                  <motion.button
                    key={color.value}
                    type="button"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setFormData({ ...formData, color: color.value })}
                    className={`relative h-12 sm:h-14 rounded-xl transition-all ${
                      formData.color === color.value 
                        ? 'ring-2 sm:ring-4 ring-offset-2 shadow-lg' 
                        : 'hover:shadow-md'
                    }`}
                    style={{ 
                      backgroundColor: color.value,
                      ringColor: color.value
                    }}
                  >
                    <div className="absolute inset-0 flex items-center justify-center">
                      {formData.color === color.value && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="w-5 h-5 sm:w-6 sm:h-6 bg-white rounded-full flex items-center justify-center shadow-lg"
                        >
                          <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full" style={{ backgroundColor: color.value }} />
                        </motion.div>
                      )}
                    </div>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Icon Picker */}
            <div className="space-y-3">
              <Label className="text-xs sm:text-sm font-semibold text-gray-700">
                Icono de la carpeta
              </Label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
                {icons.map((iconOption) => (
                  <motion.button
                    key={iconOption.value}
                    type="button"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setFormData({ ...formData, icon: iconOption.value })}
                    className={`h-16 sm:h-20 rounded-xl border-2 transition-all flex flex-col items-center justify-center gap-1 sm:gap-2 ${
                      formData.icon === iconOption.value
                        ? 'border-blue-500 bg-blue-50 shadow-md'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    {React.createElement(iconOption.icon, {
                      className: `w-5 h-5 sm:w-7 sm:h-7 ${
                        formData.icon === iconOption.value ? 'text-blue-600' : 'text-gray-400'
                      }`
                    })}
                    <span className={`text-xs font-medium ${
                      formData.icon === iconOption.value ? 'text-blue-600' : 'text-gray-500'
                    }`}>
                      {iconOption.name}
                    </span>
                  </motion.button>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 flex-col sm:flex-row">
            <Button type="button" variant="outline" onClick={resetForm} className="h-10 sm:h-11 w-full sm:w-auto">
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="bg-gradient-to-r from-[#0073EA] to-[#0056B3] hover:from-[#0056B3] hover:to-[#0073EA] text-white h-10 sm:h-11 px-4 sm:px-6 shadow-lg w-full sm:w-auto"
            >
              <FolderPlus className="w-4 h-4 mr-2" />
              Crear Carpeta
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Upload Document Modal - Mobile Responsive
function UploadDocumentModal({ isOpen, onClose, onNext, onFilesSelected, selectedFiles, currentFolder }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    tags: []
  });

  useEffect(() => {
    if (selectedFiles && selectedFiles.length > 0) {
      setFormData({ ...formData, name: selectedFiles[0].name });
    }
  }, [selectedFiles]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onNext(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl sm:text-2xl font-bold flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
              <Upload className="w-5 h-5 text-white" />
            </div>
            Subir Documento{selectedFiles.length > 1 ? 's' : ''}
          </DialogTitle>
          {currentFolder && (
            <p className="text-sm text-gray-500">
              Se subirá a: <span className="font-medium">{currentFolder.name}</span>
            </p>
          )}
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div className="space-y-6 py-4">
            {/* Drag & Drop Upload */}
            <DragDropUpload 
              onFilesSelected={onFilesSelected}
              currentFolder={currentFolder}
            />

            {/* File Details */}
            {selectedFiles.length > 0 && (
              <>
                <div>
                  <Label className="text-sm font-semibold">Nombre del documento</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Nombre del documento"
                    className="mt-1.5"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    {selectedFiles.length > 1 && "Este nombre se aplicará al primer archivo"}
                  </p>
                </div>
                <div>
                  <Label className="text-sm font-semibold">Descripción (opcional)</Label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descripción del documento..."
                    className="mt-1.5 min-h-[80px]"
                  />
                </div>
              </>
            )}
          </div>

          <DialogFooter className="gap-2 flex-col sm:flex-row">
            <Button type="button" variant="outline" onClick={onClose} className="h-11 w-full sm:w-auto">
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="bg-gradient-to-r from-[#0073EA] to-[#0056B3] hover:from-[#0056B3] hover:to-[#0073EA] text-white h-11 px-6 shadow-lg w-full sm:w-auto"
              disabled={selectedFiles.length === 0}
            >
              <Upload className="w-4 h-4 mr-2" />
              Continuar a Permisos
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
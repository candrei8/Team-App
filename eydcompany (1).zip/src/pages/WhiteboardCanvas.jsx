import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { WhiteboardProvider } from "@/components/whiteboard/store/WhiteboardContext";
import WhiteboardCanvas from "@/components/whiteboard/WhiteboardCanvas";
import Toolbar from "@/components/whiteboard/Toolbar";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Share2, Download } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function WhiteboardCanvasPage() {
  const { id } = useParams(); // Assuming route is /whiteboard/:id or using query param
  // Base44 usually uses query params if not configured otherwise in routes
  const params = new URLSearchParams(window.location.search);
  const whiteboardId = id || params.get('id') || 'default';
  
  const [user, setUser] = useState(null);
  const [whiteboard, setWhiteboard] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        // Fetch whiteboard data
        // For now we simulate it or create if not exists
        // const wb = await base44.entities.Whiteboard.filter({ id: whiteboardId });
        // setWhiteboard(wb[0]);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    init();
  }, [whiteboardId]);

  if (loading) return <div className="flex h-screen items-center justify-center">Cargando...</div>;

  return (
    <div className="h-screen w-screen flex flex-col bg-gray-50">
      {/* Header Overlay */}
      <div className="absolute top-0 left-0 right-0 h-16 px-4 flex items-center justify-between pointer-events-none z-50">
        <div className="pointer-events-auto flex items-center gap-3 bg-white/90 backdrop-blur-sm p-2 pr-4 rounded-xl shadow-sm border">
          <Link to={createPageUrl("Whiteboards")}>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-sm font-bold text-gray-900">Pizarra de Lluvia de Ideas</h1>
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse"></span>
              <p className="text-[10px] text-gray-500">Guardado hace 2m</p>
            </div>
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          <div className="flex -space-x-2 mr-2">
            {/* Avatars */}
            <div className="h-8 w-8 rounded-full bg-blue-500 border-2 border-white flex items-center justify-center text-xs text-white font-bold">TU</div>
          </div>
          <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700 text-white gap-2 rounded-lg shadow-sm">
            <Share2 className="w-4 h-4" />
            Compartir
          </Button>
          <Button size="icon" variant="secondary" className="bg-white rounded-lg shadow-sm">
             <Download className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <WhiteboardProvider initialData={{ currentUser: user }}>
         <WhiteboardCanvas whiteboardId={whiteboardId} user={user} />
         <Toolbar />
      </WhiteboardProvider>
    </div>
  );
}
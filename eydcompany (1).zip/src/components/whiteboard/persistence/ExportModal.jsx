import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Download, 
  FileJson, 
  Image as ImageIcon, 
  FileText,
  Loader2 
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";

export default function ExportModal({ 
  isOpen, 
  onClose, 
  whiteboardTitle,
  onExport 
}) {
  const [format, setFormat] = useState('json');
  const [imageQuality, setImageQuality] = useState('high');
  const [includeBackground, setIncludeBackground] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleExport = async () => {
    setIsExporting(true);
    setProgress(0);

    try {
      // Simulación de progreso
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);

      await onExport({
        format,
        imageQuality,
        includeBackground
      });

      clearInterval(progressInterval);
      setProgress(100);

      setTimeout(() => {
        onClose();
        setIsExporting(false);
        setProgress(0);
      }, 500);
    } catch (error) {
      console.error('Error al exportar:', error);
      setIsExporting(false);
      setProgress(0);
    }
  };

  const formatOptions = [
    {
      value: 'json',
      label: 'JSON',
      description: 'Estructura completa del whiteboard',
      icon: FileJson
    },
    {
      value: 'png',
      label: 'Imagen PNG',
      description: 'Captura visual del canvas',
      icon: ImageIcon
    },
    {
      value: 'pdf',
      label: 'PDF',
      description: 'Documento PDF del whiteboard',
      icon: FileText
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="w-5 h-5" />
            Exportar whiteboard
          </DialogTitle>
          <DialogDescription>
            Descarga tu whiteboard en diferentes formatos
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Selector de formato */}
          <div className="space-y-3">
            <Label>Formato de exportación</Label>
            <RadioGroup value={format} onValueChange={setFormat}>
              {formatOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <div
                    key={option.value}
                    className={`flex items-start space-x-3 p-3 rounded-lg border-2 transition-all cursor-pointer ${
                      format === option.value
                        ? 'border-[#0073EA] bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setFormat(option.value)}
                  >
                    <RadioGroupItem value={option.value} id={option.value} />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4 text-gray-600" />
                        <Label 
                          htmlFor={option.value}
                          className="font-medium cursor-pointer"
                        >
                          {option.label}
                        </Label>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        {option.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </RadioGroup>
          </div>

          {/* Opciones de imagen */}
          {(format === 'png' || format === 'pdf') && (
            <>
              <div className="space-y-2">
                <Label>Calidad</Label>
                <Select value={imageQuality} onValueChange={setImageQuality}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">Alta (300 DPI)</SelectItem>
                    <SelectItem value="medium">Media (150 DPI)</SelectItem>
                    <SelectItem value="low">Baja (72 DPI)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="background"
                  checked={includeBackground}
                  onCheckedChange={setIncludeBackground}
                />
                <Label 
                  htmlFor="background"
                  className="text-sm font-normal cursor-pointer"
                >
                  Incluir fondo y cuadrícula
                </Label>
              </div>
            </>
          )}

          {/* Progress bar */}
          {isExporting && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Exportando...</span>
                <span className="font-medium text-[#0073EA]">{progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div 
                  className="bg-[#0073EA] h-full transition-all duration-300 ease-out"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            disabled={isExporting}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleExport}
            disabled={isExporting}
            className="bg-[#0073EA] hover:bg-[#0056B3]"
          >
            {isExporting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Exportando...
              </>
            ) : (
              <>
                <Download className="w-4 h-4 mr-2" />
                Descargar {format.toUpperCase()}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronDown, ChevronRight, Plus, Columns, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';

import ItemRow from "./ItemRow";
import ColumnHeader from "./ColumnHeader";
import GroupSummary from "./GroupSummary";
import GroupSummaryRow from "./GroupSummaryRow";

const DRAG_HANDLE_WIDTH = 24; // w-6
const CHECKBOX_WIDTH = 32; // w-8
const TASK_COLUMN_DEFAULT_WIDTH = 250; // Example width for Task column
const PRIORITY_COLUMN_DEFAULT_WIDTH = 120; // Width for Priority column
const ADD_COLUMN_WIDTH = 50; // Add column button width (also used for the right-most sticky action column space)

export default function GroupSection({
  group,
  items, // These are the items for THIS group
  columns, // These are all possible columns from the board
  board, // NEW: added from outline
  onAddItem,
  onUpdateItem,
  onDeleteItem,
  onReorderItems,
  onUpdateColumn,
  onHideColumn, // NEW: Replaces onDeleteColumn from GroupSection's perspective
  onAddColumn, // Retained: used in JSX
  isLoading,
  onDeleteGroup, // Retained: used in JSX
  onHideColumnFromGroup, // Retained: used in handleHideColumn
  allItems, // NEW: added from outline
  onItemsChange // NEW: added from outline
}) {
  const [collapsed, setCollapsed] = useState(group.collapsed || false); // Renamed isCollapsed to collapsed
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [newItemTitle, setNewItemTitle] = useState("");

  const handleAddItemLocal = async () => {
    if (newItemTitle.trim()) {
      await onAddItem(group.id, newItemTitle.trim());
      setNewItemTitle("");
      setIsAddingItem(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleAddItemLocal();
    } else if (e.key === 'Escape') {
      setIsAddingItem(false);
      setNewItemTitle("");
    }
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const sourceIndex = result.source.index;
    const destinationIndex = result.destination.index;

    if (sourceIndex === destinationIndex) return;

    onReorderItems(group.id, sourceIndex, destinationIndex);
  };

  const handleDeleteGroupClick = (e) => {
    e.stopPropagation(); // Prevent group from collapsing/expanding
    if (window.confirm(`Are you sure you want to delete the group "${group.title}" and all its tasks? This cannot be undone.`)) {
      onDeleteGroup(group.id);
    }
  };

  // Get visible columns for this group (board columns filtered by visible_columns + custom columns)
  const getVisibleColumns = () => { // Renamed from getEffectiveColumns
    // If group.visible_columns is defined, filter columns based on it
    // BUT if it's undefined or empty, show ALL board columns by default
    const boardVisibleColumns = (group.visible_columns && group.visible_columns.length > 0)
      ? columns.filter(col => group.visible_columns.includes(col.id))
      : columns; // Show all board columns if visible_columns is not set or empty

    // Merge with group-specific custom columns
    const customColumns = group.custom_columns || [];

    // Combine visible board columns and custom columns, ensuring uniqueness by ID
    const combinedColumns = [...boardVisibleColumns, ...customColumns];
    const uniqueColumnIds = new Set();
    const visibleCols = []; // Renamed from effectiveCols
    for (const col of combinedColumns) {
      if (!uniqueColumnIds.has(col.id)) {
        uniqueColumnIds.add(col.id);
        visibleCols.push(col);
      }
    }
    return visibleCols;
  };

  const visibleColumns = getVisibleColumns(); // Renamed from effectiveColumns
  const taskColumn = visibleColumns.find(col => col.id === 'task');
  const taskColumnWidth = taskColumn?.width || TASK_COLUMN_DEFAULT_WIDTH;

  const priorityColumn = visibleColumns.find(col => col.type === 'priority');
  const priorityColumnWidth = priorityColumn?.width || PRIORITY_COLUMN_DEFAULT_WIDTH;

  // Consistent width variables for sticky calculations
  const dragHandleWidth = DRAG_HANDLE_WIDTH;
  const checkboxWidth = CHECKBOX_WIDTH;
  const actionColumnWidth = ADD_COLUMN_WIDTH; // This is the width for the add column button area.

  // Calculate minimum width needed for all visible columns
  const columnsWidth = visibleColumns.reduce((total, col) => total + (col.width || 150), 0);
  const totalMinWidth = dragHandleWidth + checkboxWidth + columnsWidth + actionColumnWidth;

  const handleHideColumn = (columnId) => {
    // Hide column from this specific group
    onHideColumnFromGroup(group.id, columnId);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg shadow-sm border border-[#E1E5F3] overflow-hidden mb-6"
    >
      {/* Group Header */}
      <div
        className="flex items-center justify-between p-4 cursor-pointer hover:bg-[#F5F6F8] transition-colors relative"
        onClick={() => setCollapsed(!collapsed)} // Changed from isCollapsed
        style={{ borderLeft: `4px solid ${group.color}` }}
      >
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-[#E1E5F3]">
            {collapsed ? ( // Changed from isCollapsed
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </Button>
          <h3 className="font-bold text-[#323338] text-lg">{group.title}</h3>
          <span className="text-sm text-[#676879]">({items.length})</span>
        </div>

        <div className="flex items-center gap-2">
          <GroupSummary items={items} columns={columns} />
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 hover:bg-red-100 text-red-500 hover:text-red-600 opacity-50 hover:opacity-100 transition-opacity"
            onClick={handleDeleteGroupClick}
            title="Delete group"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Table Area */}
      <AnimatePresence>
        {!collapsed && ( // Changed from isCollapsed
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="overflow-x-auto relative"> {/* Horizontal scroll container */}
              {/* Column Headers */}
              <div
                className="flex bg-[#F5F6F8] border-b border-[#E1E5F3] sticky top-0 z-10"
                style={{ minWidth: `${totalMinWidth}px` }}
              >
                {/* Sticky Left: Drag Handle */}
                <div
                  className="flex-shrink-0 bg-[#F5F6F8]"
                  style={{ width: dragHandleWidth, position: 'sticky', left: 0, zIndex: 2 }}
                />

                {/* Sticky Left: Checkbox */}
                <div
                  className="flex-shrink-0 bg-[#F5F6F8]"
                  style={{ width: checkboxWidth, position: 'sticky', left: dragHandleWidth, zIndex: 2 }}
                />

                {/* Column Headers */}
                {visibleColumns.map((column) => { // Renamed from effectiveColumns
                  let stickyProps = {};
                  if (column.id === 'task') {
                    stickyProps = {
                      position: 'sticky',
                      left: dragHandleWidth + checkboxWidth,
                      zIndex: 2,
                      backgroundColor: '#F5F6F8',
                      width: taskColumnWidth,
                      minWidth: taskColumnWidth
                    };
                  } else if (column.type === 'priority') {
                    stickyProps = {
                      position: 'sticky',
                      left: dragHandleWidth + checkboxWidth + taskColumnWidth,
                      zIndex: 2,
                      backgroundColor: '#F5F6F8',
                      width: priorityColumnWidth,
                      minWidth: priorityColumnWidth
                    };
                  }
                  return (
                    <ColumnHeader
                      key={column.id}
                      column={column}
                      onUpdateColumn={onUpdateColumn}
                      onDeleteColumn={handleHideColumn} // Still calls handleHideColumn, which uses onHideColumnFromGroup
                      style={stickyProps}
                      groupId={group.id}
                    />
                  );
                })}

                {/* Flexible spacer to push add column and delete button to edges */}
                <div className="flex-1 min-w-0 bg-[#F5F6F8]" />

                {/* Add Column Button / Delete Header Space - This div will be sticky right */}
                <div
                  className="flex items-center justify-center px-3 py-3 border-l border-[#E1F3] hover:bg-white transition-colors cursor-pointer bg-[#F5F6F8] flex-shrink-0"
                  style={{
                    width: actionColumnWidth,
                    position: 'sticky',
                    right: 0,
                    zIndex: 2
                  }}
                  onClick={onAddColumn}
                  title="Add new column"
                >
                  <Plus className="w-4 h-4 text-[#0073EA]" />
                </div>
              </div>

              {/* Items Area */}
              <div className="relative">
                <DragDropContext onDragEnd={handleDragEnd}>
                  <Droppable droppableId={group.id}>
                    {(provided) => (
                      <div
                        {...provided.droppableProps}
                        ref={provided.innerRef}
                        className="min-h-[100px]"
                      >
                        {isLoading ? (
                          <div className="p-8 text-center">
                            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-[#0073EA]"></div>
                          </div>
                        ) : items.length === 0 ? ( // items here refers to the prop, which are the group's items
                          <div className="p-8 text-center text-[#676879]">
                            <p className="text-sm">No hay tareas en este grupo</p>
                          </div>
                        ) : (
                          items.map((item, index) => ( // items here refers to the prop, which are the group's items
                            <Draggable key={item.id} draggableId={item.id} index={index}>
                              {(providedDraggable, snapshot) => (
                                <ItemRow
                                  key={item.id}
                                  item={item}
                                  columns={visibleColumns} // Changed from effectiveColumns
                                  onUpdate={onUpdateItem}
                                  onDelete={onDeleteItem}
                                  index={index}
                                  isDragging={snapshot.isDragging}
                                  draggableProvided={providedDraggable}
                                  dragHandleWidth={dragHandleWidth}
                                  checkboxWidth={checkboxWidth}
                                  taskColumnWidth={taskColumnWidth}
                                  priorityColumnWidth={priorityColumnWidth}
                                  totalMinWidth={totalMinWidth}
                                  actionColumnWidth={actionColumnWidth}
                                  allItems={allItems} // NEW: from outline
                                  onItemsChange={onItemsChange} // NEW: from outline
                                  board={board} // NEW: from outline
                                />
                              )}
                            </Draggable>
                          ))
                        )}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                </DragDropContext>

                {/* Add Item Row */}
                {isAddingItem ? (
                  <div
                    className="flex items-center border-b border-[#E1E5F3] hover:bg-[#F5F6F8] min-h-[48px]"
                    style={{ minWidth: `${totalMinWidth}px` }}
                  >
                    {/* Sticky Left: Drag Handle */}
                    <div className="flex-shrink-0" style={{ width: dragHandleWidth, position: 'sticky', left: 0, zIndex: 1, background: 'white' }}></div>

                    {/* Sticky Left: Checkbox */}
                    <div className="flex-shrink-0" style={{ width: checkboxWidth, position: 'sticky', left: dragHandleWidth, zIndex: 1, background: 'white' }}></div>

                    {/* Sticky Left: Task Column */}
                    <div
                      className="flex-1 px-3 py-2"
                      style={{
                        width: taskColumnWidth,
                        minWidth: taskColumnWidth,
                        position: 'sticky',
                        left: dragHandleWidth + checkboxWidth,
                        zIndex: 1,
                        background: 'white'
                      }}
                    >
                      <Input
                        value={newItemTitle}
                        onChange={(e) => setNewItemTitle(e.target.value)}
                        onKeyDown={handleKeyPress}
                        onBlur={() => {
                          if (!newItemTitle.trim()) {
                            setIsAddingItem(false);
                          }
                        }}
                        placeholder="Enter item name..."
                        className="border-none bg-transparent p-0 h-auto focus:ring-0 text-[#323338] font-medium"
                        autoFocus
                      />
                    </div>

                    {/* Regular Columns */}
                    {visibleColumns.filter(c => c.id !== 'task').map((column) => ( // Renamed from effectiveColumns
                      <div
                        key={column.id}
                        className="px-3 py-2 border-l border-[#E1E5F3]"
                        style={{ width: column.width || 150, minWidth: column.width || 150 }}
                      />
                    ))}

                    {/* Flexible spacer */}
                    <div className="flex-1 min-w-0" />

                    {/* Sticky Right: Action Column Space (for alignment) */}
                    <div
                      className="flex-shrink-0"
                      style={{
                        width: actionColumnWidth,
                        position: 'sticky',
                        right: 0,
                        zIndex: 1,
                        background: 'white'
                      }}
                    ></div>
                  </div>
                ) : (
                  <div
                    className="flex items-center border-b border-[#E1E5F3] hover:bg-[#F5F6F8] min-h-[48px] group"
                    style={{ minWidth: `${totalMinWidth}px` }}
                  >
                    {/* Sticky Left: Drag Handle */}
                    <div className="flex-shrink-0" style={{ width: dragHandleWidth, position: 'sticky', left: 0, zIndex: 1, background: 'white' }}></div>

                    {/* Sticky Left: Checkbox */}
                    <div className="flex-shrink-0" style={{ width: checkboxWidth, position: 'sticky', left: dragHandleWidth, zIndex: 1, background: 'white' }}></div>

                    {/* Sticky Left: Task Column */}
                    <div
                      className="flex-1 px-3 py-2"
                      style={{
                        width: taskColumnWidth,
                        minWidth: taskColumnWidth,
                        position: 'sticky',
                        left: dragHandleWidth + checkboxWidth,
                        zIndex: 1,
                        background: 'white'
                      }}
                    >
                      <Button
                        onClick={() => setIsAddingItem(true)}
                        variant="ghost"
                        className="text-[#676879] hover:text-[#0073EA] h-auto p-0 font-normal opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add task
                      </Button>
                    </div>

                    {/* Regular Columns */}
                    {visibleColumns.filter(c => c.id !== 'task').map((column) => ( // Renamed from effectiveColumns
                      <div
                        key={column.id}
                        className="px-3 py-2 border-l border-[#E1E5F3]"
                        style={{ width: column.width || 150, minWidth: column.width || 150 }}
                      />
                    ))}

                    {/* Flexible spacer */}
                    <div className="flex-1 min-w-0" />

                    {/* Sticky Right: Action Column Space (for alignment) */}
                    <div
                      className="flex-shrink-0"
                      style={{
                        width: actionColumnWidth,
                        position: 'sticky',
                        right: 0,
                        zIndex: 1,
                        background: 'white'
                      }}
                    ></div>
                  </div>
                )}

                {/* Summary Row */}
                <GroupSummaryRow
                  items={items}
                  columns={visibleColumns} // Changed from effectiveColumns
                  groupId={group.id}
                  dragHandleWidth={dragHandleWidth}
                  checkboxWidth={checkboxWidth}
                  taskColumnWidth={taskColumnWidth}
                  priorityColumnWidth={priorityColumnWidth}
                  actionColumnWidth={actionColumnWidth}
                  totalMinWidth={totalMinWidth}
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

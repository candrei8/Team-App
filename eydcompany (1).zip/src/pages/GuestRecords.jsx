import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  FileText, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Eye, 
  CheckCircle, 
  XCircle, 
  Clock,
  User,
  Briefcase,
  Phone,
  Download,
  DollarSign,
  Package,
  AlertCircle
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import GuestDetailModal from "../components/guest-records/GuestDetailModal";
import { useToast } from "@/components/ui/use-toast";

export default function GuestRecordsPage() {
  const [profiles, setProfiles] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [profilesData, submissionsData, invoicesData] = await Promise.all([
        base44.entities.GuestProfile.list("-created_date"),
        base44.entities.GuestSubmission.list("-created_date"),
        base44.entities.GuestInvoice.list("-date")
      ]);
      
      setProfiles(profilesData);
      setSubmissions(submissionsData);
      setInvoices(invoicesData);
    } catch (error) {
      console.error("Error loading data:", error);
      toast({
        title: "Error",
        description: "No se pudieron cargar los datos.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // --- Helpers ---

  const handleSubmissionStatus = async (id, newStatus) => {
    try {
      await base44.entities.GuestSubmission.update(id, { status: newStatus });
      setSubmissions(prev => prev.map(s => s.id === id ? { ...s, status: newStatus } : s));
      toast({ title: "Estado actualizado" });
    } catch (error) {
      toast({ title: "Error al actualizar", variant: "destructive" });
    }
  };

  const handleInvoiceStatus = async (id, newStatus) => {
    try {
      await base44.entities.GuestInvoice.update(id, { status: newStatus });
      setInvoices(prev => prev.map(i => i.id === id ? { ...i, status: newStatus } : i));
      toast({ title: "Factura actualizada" });
    } catch (error) {
      toast({ title: "Error al actualizar", variant: "destructive" });
    }
  };

  const getPendingCounts = (email) => {
    const pendingSubs = submissions.filter(s => s.user_email === email && s.status === 'reviewing').length;
    const pendingInvs = invoices.filter(i => i.user_email === email && i.status === 'pending').length;
    return { pendingSubs, pendingInvs };
  };

  const filteredProfiles = profiles.filter(profile => {
    const term = searchQuery.toLowerCase();
    return (profile.user_email || "").toLowerCase().includes(term) ||
           (profile.specialty || "").toLowerCase().includes(term) ||
           (profile.company || "").toLowerCase().includes(term);
  });

  // --- Renderers ---

  const StatusBadge = ({ status, type = 'default' }) => {
    const config = {
      // Profile
      aprobado: { color: "bg-green-100 text-green-700 border-green-200", text: "Activo" },
      rechazado: { color: "bg-red-100 text-red-700 border-red-200", text: "Rechazado" },
      en_revision: { color: "bg-blue-100 text-blue-700 border-blue-200", text: "En Revisión" },
      pendiente: { color: "bg-amber-100 text-amber-700 border-amber-200", text: "Pendiente" },
      // Submission
      approved: { color: "bg-green-100 text-green-700 border-green-200", text: "Aprobada" },
      rejected: { color: "bg-red-100 text-red-700 border-red-200", text: "Rechazada" },
      reviewing: { color: "bg-amber-100 text-amber-700 border-amber-200", text: "En Revisión" },
      // Invoice
      paid: { color: "bg-green-100 text-green-700 border-green-200", text: "Pagada" },
      pending: { color: "bg-amber-100 text-amber-700 border-amber-200", text: "Pendiente" }
    };
    
    const style = config[status] || { color: "bg-gray-100 text-gray-700", text: status };
    return <Badge className={style.color}>{style.text}</Badge>;
  };

  return (
    <div className="p-6 bg-[#F5F6F8] min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-[#323338] flex items-center gap-3">
              <FileText className="w-8 h-8 text-indigo-600" />
              Expedientes de Invitados
            </h1>
            <p className="text-[#676879] mt-1">
              Gestión integral de colaboradores, entregas y facturación.
            </p>
          </div>
          <div className="relative w-full md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input 
              placeholder="Buscar..." 
              className="pl-9 bg-white"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <Tabs defaultValue="guests" className="w-full">
          <TabsList className="grid w-full grid-cols-3 lg:w-[400px]">
            <TabsTrigger value="guests">Invitados</TabsTrigger>
            <TabsTrigger value="submissions">Entregas</TabsTrigger>
            <TabsTrigger value="invoices">Facturas</TabsTrigger>
          </TabsList>

          {/* TAB: GUESTS */}
          <TabsContent value="guests" className="mt-4">
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Usuario</TableHead>
                      <TableHead>Perfil</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Pendientes</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredProfiles.map((profile) => {
                      const counts = getPendingCounts(profile.user_email);
                      return (
                        <TableRow key={profile.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              {profile.profile_photo ? (
                                <img src={profile.profile_photo} className="w-10 h-10 rounded-full object-cover" alt="" />
                              ) : (
                                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600">
                                  <User className="w-5 h-5" />
                                </div>
                              )}
                              <div>
                                <div className="font-medium">{profile.user_email}</div>
                                <div className="text-xs text-gray-500">{profile.phone || "-"}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-col text-sm">
                              <span className="font-medium">{profile.specialty || "Sin especialidad"}</span>
                              <span className="text-gray-500 text-xs">{profile.company}</span>
                            </div>
                          </TableCell>
                          <TableCell><StatusBadge status={profile.status} /></TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              {counts.pendingSubs > 0 && (
                                <Badge variant="outline" className="text-amber-600 border-amber-200 bg-amber-50 gap-1">
                                  <Package className="w-3 h-3" /> {counts.pendingSubs} Entregas
                                </Badge>
                              )}
                              {counts.pendingInvs > 0 && (
                                <Badge variant="outline" className="text-indigo-600 border-indigo-200 bg-indigo-50 gap-1">
                                  <DollarSign className="w-3 h-3" /> {counts.pendingInvs} Facturas
                                </Badge>
                              )}
                              {counts.pendingSubs === 0 && counts.pendingInvs === 0 && (
                                <span className="text-xs text-gray-400 flex items-center gap-1"><CheckCircle className="w-3 h-3"/> Al día</span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm" onClick={() => {
                              setSelectedProfile(profile);
                              setIsDetailOpen(true);
                            }}>
                              <Eye className="w-4 h-4 text-gray-500" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* TAB: SUBMISSIONS */}
          <TabsContent value="submissions" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Entregas de Trabajo Globales</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Entrega</TableHead>
                      <TableHead>Usuario</TableHead>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Archivos</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {submissions.length === 0 ? (
                      <TableRow><TableCell colSpan={6} className="text-center text-gray-500 py-8">No hay entregas</TableCell></TableRow>
                    ) : submissions.map((sub) => (
                      <TableRow key={sub.id}>
                        <TableCell>
                          <div className="font-medium">{sub.title}</div>
                          <div className="text-xs text-gray-500 truncate max-w-[200px]">{sub.description}</div>
                        </TableCell>
                        <TableCell className="text-sm text-gray-600">{sub.user_email}</TableCell>
                        <TableCell className="text-sm text-gray-500">{format(new Date(sub.created_date), "d MMM", {locale: es})}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {sub.files?.map((f, i) => (
                              <a key={i} href={f.url} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">
                                <Download className="w-4 h-4" />
                              </a>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell><StatusBadge status={sub.status} /></TableCell>
                        <TableCell className="text-right">
                          {sub.status === 'reviewing' && (
                            <div className="flex justify-end gap-1">
                              <Button size="icon" variant="ghost" className="h-8 w-8 text-green-600 hover:bg-green-50" onClick={() => handleSubmissionStatus(sub.id, 'approved')} title="Aprobar">
                                <CheckCircle className="w-4 h-4" />
                              </Button>
                              <Button size="icon" variant="ghost" className="h-8 w-8 text-red-600 hover:bg-red-50" onClick={() => handleSubmissionStatus(sub.id, 'rejected')} title="Rechazar">
                                <XCircle className="w-4 h-4" />
                              </Button>
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* TAB: INVOICES */}
          <TabsContent value="invoices" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Facturas Globales</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Factura</TableHead>
                      <TableHead>Usuario</TableHead>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Importe</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {invoices.length === 0 ? (
                      <TableRow><TableCell colSpan={6} className="text-center text-gray-500 py-8">No hay facturas</TableCell></TableRow>
                    ) : invoices.map((inv) => (
                      <TableRow key={inv.id}>
                        <TableCell className="font-medium">
                          {inv.invoice_number}
                          {inv.pdf_url && (
                            <a href={inv.pdf_url} target="_blank" rel="noreferrer" className="ml-2 inline-flex align-middle text-gray-400 hover:text-blue-600">
                              <Download className="w-3 h-3" />
                            </a>
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-gray-600">{inv.user_email}</TableCell>
                        <TableCell className="text-sm text-gray-500">{format(new Date(inv.date), "d MMM yyyy", {locale: es})}</TableCell>
                        <TableCell className="font-mono text-gray-900">${inv.amount?.toLocaleString()}</TableCell>
                        <TableCell><StatusBadge status={inv.status} /></TableCell>
                        <TableCell className="text-right">
                          {inv.status === 'pending' && (
                            <Button size="sm" className="h-8 bg-green-600 hover:bg-green-700 text-white" onClick={() => handleInvoiceStatus(inv.id, 'paid')}>
                              <DollarSign className="w-3 h-3 mr-1" /> Pagar
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

        </Tabs>
      </div>

      <GuestDetailModal 
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
        profile={selectedProfile}
        onStatusChange={async (id, status) => {
          try {
            await base44.entities.GuestProfile.update(id, { status });
            setProfiles(prev => prev.map(p => p.id === id ? { ...p, status } : p));
            if (selectedProfile) setSelectedProfile({ ...selectedProfile, status });
            toast({ title: "Perfil actualizado" });
          } catch (e) { toast({ title: "Error", variant: "destructive" }); }
        }}
      />
    </div>
  );
}
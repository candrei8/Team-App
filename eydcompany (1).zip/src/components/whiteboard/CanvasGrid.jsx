import React from 'react';

export default function CanvasGrid({ zoom, pan, type, containerWidth, containerHeight }) {
  const gridSize = 20; // Tamaño de la cuadrícula base
  const scaledGridSize = gridSize * zoom;

  // Calcular cuántos puntos/líneas necesitamos
  const startX = Math.floor(-pan.x / scaledGridSize) * gridSize;
  const startY = Math.floor(-pan.y / scaledGridSize) * gridSize;
  const endX = startX + Math.ceil(containerWidth / scaledGridSize + 2) * gridSize;
  const endY = startY + Math.ceil(containerHeight / scaledGridSize + 2) * gridSize;

  if (type === 'dots') {
    // Grid de puntos
    const dots = [];
    for (let x = startX; x <= endX; x += gridSize) {
      for (let y = startY; y <= endY; y += gridSize) {
        dots.push(
          <circle
            key={`${x}-${y}`}
            cx={x}
            cy={y}
            r={1 / zoom}
            fill="#CBD5E1"
            opacity="0.6"
          />
        );
      }
    }

    return (
      <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
        {dots}
      </g>
    );
  } else {
    // Grid de líneas
    const lines = [];

    // Líneas verticales
    for (let x = startX; x <= endX; x += gridSize) {
      lines.push(
        <line
          key={`v-${x}`}
          x1={x}
          y1={startY}
          x2={x}
          y2={endY}
          stroke="#E2E8F0"
          strokeWidth={1 / zoom}
          opacity="0.5"
        />
      );
    }

    // Líneas horizontales
    for (let y = startY; y <= endY; y += gridSize) {
      lines.push(
        <line
          key={`h-${y}`}
          x1={startX}
          y1={y}
          x2={endX}
          y2={y}
          stroke="#E2E8F0"
          strokeWidth={1 / zoom}
          opacity="0.5"
        />
      );
    }

    return (
      <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
        {lines}
      </g>
    );
  }
}
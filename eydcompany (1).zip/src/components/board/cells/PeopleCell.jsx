import React, { useState, useEffect } from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { User, X } from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { base44 } from "@/api/base44Client";

export default function PeopleCell({ value, onUpdate }) {
  const [isOpen, setIsOpen] = useState(false);
  const [users, setUsers] = useState([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (isOpen && users.length === 0) {
      loadUsers();
    }
  }, [isOpen]);

  const loadUsers = async () => {
    setIsLoadingUsers(true);
    try {
      const allUsers = await base44.entities.User.list("full_name");
      // Filtrar solo usuarios activos
      const activeUsers = allUsers.filter(u => u.status === "active" || u.role === "admin");
      setUsers(activeUsers);
    } catch (error) {
      console.error("Error al cargar usuarios:", error);
    }
    setIsLoadingUsers(false);
  };

  const handleSelectUser = (user) => {
    onUpdate(user.email);
    setIsOpen(false);
    setSearchQuery('');
  };

  const handleClearAssignment = (e) => {
    e.stopPropagation();
    onUpdate('');
  };

  const getUserInitials = (name) => {
    if (!name) return "U";
    const names = name.split(" ");
    if (names.length >= 2) {
      return `${names[0][0]}${names[1][0]}`.toUpperCase();
    }
    return names[0][0].toUpperCase();
  };

  const getAssignedUser = () => {
    if (!value) return null;
    return users.find(u => u.email === value);
  };

  const filteredUsers = users.filter(user =>
    user.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const assignedUser = getAssignedUser();

  if (!value) {
    return (
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <div
            className="cursor-pointer text-[#676879] hover:bg-[#E1E5F3] hover:rounded px-2 py-1 -mx-2 -my-1 transition-colors flex items-center gap-2"
          >
            <User className="w-4 h-4" />
            <span>Asignar</span>
          </div>
        </PopoverTrigger>
        <PopoverContent className="w-80 p-0" align="start">
          <div className="flex flex-col max-h-[400px]">
            {/* Header */}
            <div className="p-3 border-b">
              <input
                type="text"
                placeholder="Buscar usuario..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                autoFocus
              />
            </div>

            {/* User List */}
            <div className="overflow-y-auto flex-1">
              {isLoadingUsers ? (
                <div className="p-8 text-center text-gray-500">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-2"></div>
                  <p className="text-sm">Cargando usuarios...</p>
                </div>
              ) : filteredUsers.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  <User className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                  <p className="text-sm">No se encontraron usuarios</p>
                </div>
              ) : (
                <div className="py-2">
                  {filteredUsers.map((user) => (
                    <button
                      key={user.id}
                      onClick={() => handleSelectUser(user)}
                      className="w-full px-3 py-2 flex items-center gap-3 hover:bg-gray-100 transition-colors text-left"
                    >
                      {user.avatar_url ? (
                        <img 
                          src={user.avatar_url} 
                          alt={user.full_name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-8 h-8 bg-gradient-to-br from-[#0073EA] to-[#00C875] rounded-full flex items-center justify-center">
                          <span className="text-white text-xs font-semibold">
                            {getUserInitials(user.full_name)}
                          </span>
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {user.full_name || 'Sin nombre'}
                        </p>
                        <p className="text-xs text-gray-500 truncate">{user.email}</p>
                      </div>
                      {user.role === "admin" && (
                        <Badge className="bg-purple-100 text-purple-700 text-xs">Admin</Badge>
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </PopoverContent>
      </Popover>
    );
  }

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <div
          className="cursor-pointer hover:opacity-80 transition-opacity group relative"
        >
          <div className="flex items-center gap-2">
            {assignedUser?.avatar_url ? (
              <img 
                src={assignedUser.avatar_url} 
                alt={assignedUser.full_name}
                className="w-6 h-6 rounded-full object-cover"
              />
            ) : (
              <div className="w-6 h-6 bg-[#0073EA] rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-medium">
                  {getUserInitials(assignedUser?.full_name || value)}
                </span>
              </div>
            )}
            <span className="text-[#323338] text-sm truncate">
              {assignedUser?.full_name || value}
            </span>
            <button
              onClick={handleClearAssignment}
              className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-gray-200 rounded"
              title="Quitar asignación"
            >
              <X className="w-3 h-3 text-gray-500" />
            </button>
          </div>
        </div>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="start">
        <div className="flex flex-col max-h-[400px]">
          {/* Header */}
          <div className="p-3 border-b">
            <input
              type="text"
              placeholder="Buscar usuario..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              autoFocus
            />
          </div>

          {/* User List */}
          <div className="overflow-y-auto flex-1">
            {isLoadingUsers ? (
              <div className="p-8 text-center text-gray-500">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-2"></div>
                <p className="text-sm">Cargando usuarios...</p>
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <User className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                <p className="text-sm">No se encontraron usuarios</p>
              </div>
            ) : (
              <div className="py-2">
                {filteredUsers.map((user) => (
                  <button
                    key={user.id}
                    onClick={() => handleSelectUser(user)}
                    className={`w-full px-3 py-2 flex items-center gap-3 hover:bg-gray-100 transition-colors text-left ${
                      user.email === value ? 'bg-blue-50' : ''
                    }`}
                  >
                    {user.avatar_url ? (
                      <img 
                        src={user.avatar_url} 
                        alt={user.full_name}
                        className="w-8 h-8 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-8 h-8 bg-gradient-to-br from-[#0073EA] to-[#00C875] rounded-full flex items-center justify-center">
                        <span className="text-white text-xs font-semibold">
                          {getUserInitials(user.full_name)}
                        </span>
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {user.full_name || 'Sin nombre'}
                      </p>
                      <p className="text-xs text-gray-500 truncate">{user.email}</p>
                    </div>
                    {user.role === "admin" && (
                      <Badge className="bg-purple-100 text-purple-700 text-xs">Admin</Badge>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {value && (
            <div className="p-2 border-t">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClearAssignment}
                className="w-full text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <X className="w-4 h-4 mr-2" />
                Quitar Asignación
              </Button>
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}